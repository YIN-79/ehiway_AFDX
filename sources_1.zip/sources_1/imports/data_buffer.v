//==============================================================================
// 文件名   : data_buffer.v
// 所属层次 : rtl/host_if —— 615A 主机接口的加载/卸载缓存
// 功能描述 : 单时钟、字节宽、首字直出(first-word fall-through)的同步缓存。
//            在 host_if_top 里被例化两次：加载方向(主机->端系统)与卸载方向
//            (端系统->主机)各一个，用来解耦主机侧与 AFDX 载荷流之间的速率
//            差异：既吸收主机突发，也把下游反压原样传回上游，从而做到
//            "不丢字节、不重复、不乱序"。
//              写侧：wr_en 且 full=0 的时钟上升沿写入 wr_data；
//              读侧：rd_data 始终为队首字节(组合输出)，rd_en 且 empty=0 的
//                    时钟上升沿弹出队首。
// 空/满判定 : count 记录有效数据数量；count=0 判空，count=DEPTH 判满。
//            同时读写保持 count，读写指针各自按 DEPTH 回卷。
// 接口约定 : full / empty 为组合输出，随指针实时变化；reset 高电平有效、
//            异步复位，复位后指针清零(缓存内容被丢弃)。
// 备注     : DEPTH 建议取 2 的整数次幂(默认 256 = 2^8)；AW 默认由 $clog2(DEPTH)
//            给出，父模块只覆盖 DEPTH 即可。DEPTH=1 时 AW=0 会使位选非法，
//            本模块不支持 DEPTH < 2。
//==============================================================================
`timescale 1ns / 1ns
module data_buffer #(
    parameter integer DATA_W = 8,
    parameter  integer        DEPTH = 256,
    // 缓存深度(字节)
    parameter  integer        AW    = $clog2(DEPTH)
    // 地址位宽(默认按深度自动计算)
) (
    input  wire       clk,
    // 时钟信号
    input  wire       reset,
    // 复位信号(高电平有效)
    //---- 写侧 ----
    input  wire [DATA_W-1:0] wr_data,
    // 写入数据
    input  wire       wr_en,
    // 写使能(单拍脉冲)
    output wire       full,
    // 缓存已满(写侧需等待)
    //---- 读侧 ----
    output wire [DATA_W-1:0] rd_data,
    // 队首数据(FWFT，组合输出)
    input  wire       rd_en,
    // 读使能(单拍脉冲，弹出队首)
    output wire       empty
    // 缓存为空
);
    // Synchronous block RAM plus head bypass provides FWFT semantics.
    // No reset of memory contents: resetting pointers/count discards old bytes.
    // Classic Flow otherwise maps the short, wide descriptor FIFO into LEs.
    // Keep its synchronous read and collision bypass, but select block RAM.
    (* ramstyle = "M4K, no_rw_check" *) reg [DATA_W-1:0] mem[0:DEPTH-1];
    reg [AW-1:0] wr_ptr, rd_ptr;
    reg [AW:0] count;
    reg [DATA_W-1:0] ram_q, bypass_data;
    reg bypass;
    wire push = wr_en && !full && !reset;
    wire pop = rd_en && !empty && !reset;
    wire [AW-1:0] rd_next = rd_ptr == DEPTH-1 ? 0 : rd_ptr + 1'b1;
    wire [AW-1:0] fetch_addr = pop ? rd_next : rd_ptr;
    assign empty = count == 0;
    assign full = count == DEPTH;
    assign rd_data = bypass ? bypass_data : ram_q;
    always @(posedge clk) begin
        if(push)mem[wr_ptr]<=wr_data;
        ram_q<=mem[fetch_addr];
    end
    always @(posedge clk or posedge reset) begin
        if(reset)begin wr_ptr<=0;rd_ptr<=0;count<=0;bypass<=0;bypass_data<=0;end
        else begin
            bypass<=push && (empty || (pop && count==1));
            if(push && (empty || (pop && count==1)))bypass_data<=wr_data;
            if(push)wr_ptr<=wr_ptr==DEPTH-1?0:wr_ptr+1'b1;
            if(pop)rd_ptr<=rd_next;
            case({push,pop})
                2'b10:count<=count+1'b1;
                2'b01:count<=count-1'b1;
                default:begin end
            endcase
        end
    end
endmodule
