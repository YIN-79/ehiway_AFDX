//==============================================================================
// 文件名   : snmp_agent.v
// 所属层次 : rtl/mib —— SNMP 代理(包装 mib_reg 寄存器组)
// 功能描述 : AFDX 端系统的 SNMP 代理层。对外提供 mib_addr / mib_wr_en /
//            mib_wr_data / mib_rd_data 寄存器接口(Testbench 模拟网管读写)，
//            内部例化 mib_reg 完成寄存器存储与地址译码。当前为直通包装，
//            后续可在此层加入 SNMP 协议解析(Get/Set 请求)逻辑。
// 寄存器映射 : 见 mib_reg.v（本层不改变地址映射，全部直通）。
// 接口约定 : mib_wr_en=1 为写，=0 为读；reset 高电平有效、异步复位。
// 备注     : (1) 端口命名与 AFDX_top.v 中 SNMP 模块的例化完全一致；
//            (2) 本模块与 mib_reg 接口相同，作为"代理层"包装寄存器组。
//==============================================================================
`timescale 1ns / 1ns
module snmp_agent #(
    parameter                 VL_NUM = 2,
    parameter TX_VL_NUM = VL_NUM,
    parameter RX_VL_NUM = VL_NUM,
    // 虚拟链路数量，和顶层保持一致
    parameter RAM_RX_TABLE = 0,
    parameter SCHED_CYCLES_PER_MS=12500,
    parameter SCHED_START_SPREAD=0,
    parameter                 ADDR_W = 8
    // MIB 寄存器地址位宽
) (
    input  wire                     clk,
    // 时钟信号
    input  wire                     reset,
    // 复位信号(高电平有效)
    //---- SNMP MIB 寄存器配置接口(Testbench 模拟网管读写) ----
    input  wire [ADDR_W - 1:0]      mib_addr,
    // 寄存器地址
    input  wire                     mib_wr_en,
    // 1=写操作 0=读操作
    input  wire [31:0]              mib_wr_data,
    // 寄存器写数据
    output wire [31:0]              mib_rd_data,
    // 寄存器读数据
    //---- 配置输出(送给发送调度器) ----
    output wire [32 * TX_VL_NUM - 1:0] vl_cfg_bag,
    // 每条 VL 的 BAG 配置(ms)
    output wire [32 * TX_VL_NUM - 1:0] vl_cfg_lmax,
    // Independent receive frame-length configuration table.
    output wire [32 * (RAM_RX_TABLE ? 1 : RX_VL_NUM) - 1:0] vl_cfg_rx_lmax,
    // 每条 VL 的 Lmax 配置(字节)
    //---- 统计输入(来自 TX/RX 核心) ----
    input  wire [31:0]              stat_tx_frame_cnt,
    // 发送帧计数
    input  wire [31:0]              stat_rx_frame_cnt,
    // 接收帧计数
    input  wire [31:0]              stat_err_crc,
    // CRC 错误帧计数
    input  wire [31:0]              stat_err_sn,
    // SN 错误帧计数
    input wire [15:0] rx_lookup_index,
    output wire [15:0] rx_lookup_lmax,
    output wire [TX_VL_NUM-1:0] sched_enable,
    output wire [32*TX_VL_NUM-1:0] sched_period,sched_phase
);
    //--------------------------------------------------------------------------
    // 例化 mib_reg 寄存器组：全部端口直通
    //--------------------------------------------------------------------------
        mib_reg #(
        .VL_NUM(VL_NUM),
        .TX_VL_NUM(TX_VL_NUM),
        .RX_VL_NUM(RX_VL_NUM),
        .ADDR_W(ADDR_W),
        .RAM_RX_TABLE(RAM_RX_TABLE),
        .SCHED_CYCLES_PER_MS(SCHED_CYCLES_PER_MS),
        .SCHED_START_SPREAD(SCHED_START_SPREAD)
    ) u_mib_reg(
        .clk(clk),
        .reset(reset),
        .mib_addr(mib_addr),
        .mib_wr_en(mib_wr_en),
        .mib_wr_data(mib_wr_data),
        .mib_rd_data(mib_rd_data),
        .vl_cfg_bag(vl_cfg_bag),
        .vl_cfg_lmax(vl_cfg_lmax),
        .vl_cfg_rx_lmax(vl_cfg_rx_lmax),
        .stat_tx_frame_cnt(stat_tx_frame_cnt),
        .stat_rx_frame_cnt(stat_rx_frame_cnt),
        .stat_err_crc(stat_err_crc),
        .stat_err_sn(stat_err_sn),
        .rx_lookup_index(rx_lookup_index),
        .rx_lookup_lmax(rx_lookup_lmax),
        .sched_enable(sched_enable),
        .sched_period(sched_period),
        .sched_phase(sched_phase)
    );
endmodule
