`timescale 1ns/1ns
// Independent TX/RX tables. Legacy addresses cover only the first 16 TX VLs.
// 00+2*i: TX BAG; 01+2*i: compatibility TX/RX LMAX; 20..23: read-only statistics.
// 40: TX index; 41: indexed TX BAG; 42: indexed TX LMAX.
// 43: RX index; 44: indexed RX LMAX. Indexed writes affect only the selected table.
module mib_reg #(
    parameter VL_NUM    = 2,
    parameter TX_VL_NUM = VL_NUM,
    parameter RX_VL_NUM = VL_NUM,
    parameter ADDR_W    = 8,
    parameter RAM_RX_TABLE = 0,
    parameter SCHED_CYCLES_PER_MS=12500,
    parameter SCHED_START_SPREAD=0
) (
    input  wire                         clk,
    input  wire                         reset,
    input  wire [ADDR_W-1:0]             mib_addr,
    input  wire                         mib_wr_en,
    input  wire [31:0]                   mib_wr_data,
    output reg  [31:0]                   mib_rd_data,
    output wire [32*TX_VL_NUM-1:0]        vl_cfg_bag,
    output wire [32*TX_VL_NUM-1:0]        vl_cfg_lmax,
    output wire [32*(RAM_RX_TABLE ? 1 : RX_VL_NUM)-1:0] vl_cfg_rx_lmax,
    input  wire [31:0]                   stat_tx_frame_cnt,
    input  wire [31:0]                   stat_rx_frame_cnt,
    input  wire [31:0]                   stat_err_crc,
    input  wire [31:0]                   stat_err_sn,
    input wire [15:0] rx_lookup_index,
    output wire [15:0] rx_lookup_lmax,
    output reg [TX_VL_NUM-1:0] sched_enable,
    output wire [32*TX_VL_NUM-1:0] sched_period,sched_phase
);
    reg [7:0] tx_bag[0:TX_VL_NUM-1];
    reg [10:0] tx_lmax[0:TX_VL_NUM-1];
    wire [15:0] rx_read_lmax;
    localparam TX_AW=TX_VL_NUM<2 ? 1 : $clog2(TX_VL_NUM);
    localparam RX_AW=RX_VL_NUM<2 ? 1 : $clog2(RX_VL_NUM);
    reg [TX_AW-1:0] tx_index;
    reg [RX_AW-1:0] rx_index;
    reg [31:0] schedule_config_errors;
    reg [31:0] periods[0:TX_VL_NUM-1],phases[0:TX_VL_NUM-1];
    wire [31:0] legacy_index = mib_addr >> 1;
    wire bag_valid = mib_wr_data >= 1 && mib_wr_data <= 128 &&
                     (mib_wr_data & (mib_wr_data-1)) == 0;
    wire lmax_valid = mib_wr_data >= 64 && mib_wr_data <= 1518;
    integer i;
    genvar g;
    generate
        for(g=0;g<TX_VL_NUM;g=g+1)begin:g_tx
            assign vl_cfg_bag[g*32+:32] = tx_bag[g];
            assign vl_cfg_lmax[g*32+:32] = tx_lmax[g];
            assign sched_period[g*32+:32]=periods[g];
            assign sched_phase[g*32+:32]=phases[g];
        end

    endgenerate
    // Freeze the admitted TX parameters while a calendar is enabled. A legacy
    // LMAX write updates both tables, so reject both halves of a blocked write.
    wire legacy_locked = legacy_index<TX_VL_NUM && sched_enable[legacy_index];
    wire legacy_change = legacy_index<TX_VL_NUM ?
        (mib_addr[0] ? mib_wr_data!=tx_lmax[legacy_index] : mib_wr_data!=tx_bag[legacy_index]) : 1'b0;
    wire legacy_rx_write = mib_wr_en && mib_addr<8'h20 && mib_addr[0] &&
        legacy_index<TX_VL_NUM && legacy_index<RX_VL_NUM && lmax_valid &&
        !(legacy_locked && legacy_change);
    wire indexed_rx_write = mib_wr_en && mib_addr==8'h44 && lmax_valid;
    wire rx_write = legacy_rx_write || indexed_rx_write;
    wire [RX_AW-1:0] rx_write_index = legacy_rx_write ? legacy_index : rx_index;
    generate if(RAM_RX_TABLE)begin:g_rx_ram
        // Two copies provide configuration and packet lookup read ports.
        // Only validity bits reset; unwritten entries logically contain 1518.
        (* ramstyle = "M4K, no_rw_check" *) reg [10:0] config_mem[0:RX_VL_NUM-1];
        (* ramstyle = "M4K, no_rw_check" *) reg [10:0] lookup_mem[0:RX_VL_NUM-1];
        reg [RX_VL_NUM-1:0] initialized;
        reg [10:0] config_q,lookup_q;
        reg config_valid,lookup_valid;
        always @(posedge clk)begin
            if(!reset && rx_write && rx_write_index<RX_VL_NUM)begin
                config_mem[rx_write_index]<=mib_wr_data[10:0];
                lookup_mem[rx_write_index]<=mib_wr_data[10:0];
            end
            config_q<=config_mem[rx_index];
            if(rx_lookup_index<RX_VL_NUM)lookup_q<=lookup_mem[rx_lookup_index[RX_AW-1:0]];
        end
        always @(posedge clk or posedge reset)begin
            if(reset)begin initialized<=0;config_valid<=0;lookup_valid<=0;end
            else begin
                if(rx_write && rx_write_index<RX_VL_NUM)initialized[rx_write_index]<=1;
                config_valid<=initialized[rx_index];
                lookup_valid<=rx_lookup_index<RX_VL_NUM && initialized[rx_lookup_index[RX_AW-1:0]];

            end
        end
        // The readback settles one clock after index/table changes.
        assign rx_read_lmax=config_valid?{5'd0,config_q}:16'd1518;
        assign rx_lookup_lmax=lookup_valid?{5'd0,lookup_q}:16'd1518;
        // The wide legacy view is unavailable in RAM mode; packet consumers
        // use rx_lookup_index/rx_lookup_lmax instead.
        assign vl_cfg_rx_lmax=32'd1518;
    end else begin:g_rx_legacy
        reg [10:0] rx_lmax[0:RX_VL_NUM-1];
        integer k;
        always @(posedge clk or posedge reset)begin
            if(reset)for(k=0;k<RX_VL_NUM;k=k+1)rx_lmax[k]<=1518;
            else if(rx_write && rx_write_index<RX_VL_NUM)rx_lmax[rx_write_index]<=mib_wr_data[10:0];
        end
        assign rx_read_lmax=rx_lmax[rx_index];
        assign rx_lookup_lmax=rx_lookup_index<RX_VL_NUM?{5'd0,rx_lmax[rx_lookup_index]}:16'd1518;
        for(g=0;g<RX_VL_NUM;g=g+1)begin:g_view
            assign vl_cfg_rx_lmax[g*32+:32]={21'd0,rx_lmax[g]};
        end
    end endgenerate
    always @(posedge clk or posedge reset)begin
        if(reset)begin
            sched_enable<=0;schedule_config_errors<=0;
            tx_index <= 0;
            rx_index <= 0;
            for(i=0;i<TX_VL_NUM;i=i+1)begin tx_bag[i]<=1;tx_lmax[i]<=1518;periods[i]<=0;phases[i]<=0;end

        end else if(mib_wr_en)begin
            // Bound the legacy window before decoding: statistics cannot alias a VL.
            if(mib_addr < 8'h20 && legacy_index < TX_VL_NUM)begin
                if(legacy_locked && legacy_change)
                    schedule_config_errors<=schedule_config_errors+1'b1;
                else if(!mib_addr[0] && bag_valid)tx_bag[legacy_index]<=mib_wr_data;
                else if(mib_addr[0] && lmax_valid)begin
                    tx_lmax[legacy_index]<=mib_wr_data;

                end
            end
            case(mib_addr)
                8'h40: if(mib_wr_data<TX_VL_NUM)tx_index<=mib_wr_data;
                8'h41: begin
                    if(sched_enable[tx_index] && mib_wr_data!=tx_bag[tx_index])
                        schedule_config_errors<=schedule_config_errors+1'b1;
                    else if(bag_valid)tx_bag[tx_index]<=mib_wr_data;
                end
                8'h42: begin
                    if(sched_enable[tx_index] && mib_wr_data!=tx_lmax[tx_index])
                        schedule_config_errors<=schedule_config_errors+1'b1;
                    else if(lmax_valid)tx_lmax[tx_index]<=mib_wr_data;
                end
                8'h45: begin
                    if(sched_enable[tx_index] && mib_wr_data!=periods[tx_index])
                        schedule_config_errors<=schedule_config_errors+1'b1;
                    else if(mib_wr_data==0 || (!mib_wr_data[31] && mib_wr_data>=tx_bag[tx_index]*SCHED_CYCLES_PER_MS+SCHED_START_SPREAD))
                        periods[tx_index]<=mib_wr_data;
                    else schedule_config_errors<=schedule_config_errors+1'b1;
                end
                8'h46: begin
                    if(sched_enable[tx_index] && mib_wr_data!=phases[tx_index])
                        schedule_config_errors<=schedule_config_errors+1'b1;
                    else phases[tx_index]<=mib_wr_data;
                end
                8'h47: begin
                    if(!mib_wr_data[0])sched_enable[tx_index]<=0;
                    else if(periods[tx_index]>=tx_bag[tx_index]*SCHED_CYCLES_PER_MS+SCHED_START_SPREAD && !periods[tx_index][31])sched_enable[tx_index]<=1;
                    else schedule_config_errors<=schedule_config_errors+1'b1;
                end
                8'h43: if(mib_wr_data<RX_VL_NUM)rx_index<=mib_wr_data;

                default: begin end
            endcase
        end
    end
    always @(*)begin
        mib_rd_data=0;
        if(mib_addr < 8'h20 && legacy_index < TX_VL_NUM)begin
            if(!mib_addr[0])mib_rd_data=tx_bag[legacy_index];
            else mib_rd_data=tx_lmax[legacy_index];
        end
        case(mib_addr)
            8'h20: mib_rd_data=stat_tx_frame_cnt;
            8'h21: mib_rd_data=stat_rx_frame_cnt;
            8'h22: mib_rd_data=stat_err_crc;
            8'h23: mib_rd_data=stat_err_sn;
            8'h40: mib_rd_data=tx_index;
            8'h41: mib_rd_data=tx_bag[tx_index];
            8'h42: mib_rd_data=tx_lmax[tx_index];
            8'h49: mib_rd_data=schedule_config_errors;
            8'h45: mib_rd_data=periods[tx_index];
            8'h46: mib_rd_data=phases[tx_index];
            8'h47: mib_rd_data={31'd0,sched_enable[tx_index]};
            8'h43: mib_rd_data=rx_index;
            8'h44: mib_rd_data=rx_read_lmax;
            default: begin end
        endcase
    end
endmodule
