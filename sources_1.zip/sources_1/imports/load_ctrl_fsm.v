//==============================================================================
// 文件名   : load_ctrl_fsm.v
// 所属层次 : rtl/host_if —— 615A 主机加载控制状态机(主机 -> 端系统)
// 功能描述 : 加载方向(host_load_* -> tx_payload_*)的控制状态机：
//              1) 把主机字节写入加载缓存(写侧握手与反压)；
//              2) 从缓存读数，按固定长度 CFG_FRAME_LEN 分帧后交给 AFDX 发送
//                 核心(tx_payload_*)。
//            数据逐字节透明搬运，不修改数据内容、不插入任何字段(AFDX 序列号
//            SN 由下游 tx_redundant 插入)。
// 缓存接口 : 本模块不含缓存元件；缓存由顶层 host_if_top 例化 data_buffer 后
//            通过 buf_* 端口接入(见 data_buffer.v)：
//              bin_wr_en && !buf_full -> 写入 buf_wr_data
//              buf_rd_data 恒为队首字节；buf_rd_en && !buf_empty -> 弹出队首
// 流控     : 缓存满 -> host_ready=0，把反压原样传回主机；缓存空 -> tx_valid=0，
//            不向发送核心送无效数据。
// 帧边界约定: 每帧恰好 CFG_FRAME_LEN 个握手字节；帧与帧之间 tx_payload_valid
//            至少拉低 1 拍(本模块强制插入 1 拍空闲)，因此下游"按固定长度
//            计数分帧"不会把相邻两帧误判成一帧；帧内 FIFO 非空时，valid 才
//            为 1，反压只表现为 ready=0，数据不会丢失。
// 复位约定 : reset 期间两侧均不握手(host_ready=0、tx_valid=0)；缓存指针由
//            data_buffer 自身清零，因此发送中途被复位时未发完的半帧会被丢弃
//            (下游最多收到一帧不完整数据，由 AFDX 长度/CRC 校验层兜底)。
// 备注     : CFG_FRAME_LEN 应与 udp_ip_wrapper 的 CFG_PAYLOAD_LEN 配套：
//            CFG_FRAME_LEN(业务数据) + 2 字节 SN = CFG_PAYLOAD_LEN。
//            模块内的 stat_* 计数器仅供波形核对/文档锚点使用，不参与功能，
//            也不出现在任何端口上。
//==============================================================================
`timescale 1ns / 1ns
module load_ctrl_fsm #(
    parameter          [15:0] CFG_FRAME_LEN = 16'd62
    // 每帧业务数据字节数(1~1471)
) (
    input  wire       clk,
    // 时钟信号
    input  wire       reset,
    // 复位信号(高电平有效)
    //---- 主机侧(加载：主机 -> 端系统) ----
    input  wire [7:0] host_data,
    // 主机数据
    input  wire       host_valid,
    // 主机数据有效
    output wire       host_ready,
    // 允许主机继续送数
    //---- 加载缓存(顶层例化的 data_buffer) ----
    output wire [7:0] buf_wr_data,
    // 写入缓存的数据
    output wire       buf_wr_en,
    // 写使能(单拍脉冲)
    input  wire       buf_full,
    // 缓存已满(写侧需等待)
    input  wire [7:0] buf_rd_data,
    // 缓存队首数据(FWFT)
    output wire       buf_rd_en,
    // 读使能(单拍脉冲，弹出队首)
    input  wire       buf_empty,
    // 缓存为空
    //---- 端系统侧(送往 AFDX_TX 核心的业务载荷流) ----
    output wire [7:0] tx_data,
    // 业务载荷数据
    output wire       tx_valid,
    // 业务载荷数据有效
    input  wire       tx_ready
    // 发送核心允许接收
);
    //--------------------------------------------------------------------------
    // 常量与状态编码
    //--------------------------------------------------------------------------
    localparam                ST_IDLE       = 1'b0,
    // 空闲(帧间间隔，valid=0)
    ST_FRAME = 1'b1;
    // 正在发送一帧数据
    reg  [15:0] frame_cnt;
    // 本帧已发出的字节数
    reg         state;
    // 当前状态
    wire        host_xfer = host_valid && host_ready;
    // 主机侧握手
    wire        tx_xfer = tx_valid && tx_ready;
    // 发送侧握手
    //--------------------------------------------------------------------------
    // 输出(组合)
    //--------------------------------------------------------------------------
    assign host_ready = !reset && !buf_full;
    // 复位或缓存满则反压
    assign buf_wr_data = host_data;
    // 直接落缓存
    assign buf_wr_en = host_xfer;
    // 握手成功才写
    assign buf_rd_en = tx_xfer;
    // 送出一拍才弹出
    assign tx_valid = !reset && (state == ST_FRAME) && !buf_empty;
    // 只在帧内有效
    assign tx_data = buf_rd_data;
    // FWFT 直出
    //--------------------------------------------------------------------------
    // 统计(内部观测，供波形核对；不影响功能)
    //--------------------------------------------------------------------------
    reg  [31:0] stat_in_bytes;
    // 主机侧接收字节数
    reg  [31:0] stat_out_bytes;
    // 发往 TX 核心字节数
    reg  [31:0] stat_out_frames;
    // 发往 TX 核心帧数
    reg  [31:0] stat_stall_beats;
    // host_valid=1 且 host_ready=0 的等待拍
    //--------------------------------------------------------------------------
    // 主状态机：从缓存取数并按 CFG_FRAME_LEN 分帧
    //--------------------------------------------------------------------------
    always @ (posedge clk or posedge reset) begin
        if (reset) begin
            state <= ST_IDLE;
            frame_cnt <= 16'd0;
            stat_in_bytes <= 32'd0;
            stat_out_bytes <= 32'd0;
            stat_out_frames <= 32'd0;
            stat_stall_beats <= 32'd0;
        end
        else begin
            //---- 统计 ----
            if (host_xfer) stat_in_bytes <= stat_in_bytes + 32'd1;
            if (tx_xfer) stat_out_bytes <= stat_out_bytes + 32'd1;
            if (host_valid && !host_ready)
            stat_stall_beats <= stat_stall_beats + 32'd1;
            //---- 分帧状态机 ----
            case (state)
                //---- 帧间间隔：缓存里有数据即开始新的一帧 ----
                ST_IDLE : begin
                    if (!buf_empty) begin
                        frame_cnt <= 16'd0;
                        state <= ST_FRAME;
                    end
                end
                //---- 发送当前帧：恰好 CFG_FRAME_LEN 个握手字节 ----
                ST_FRAME : begin
                    if (tx_xfer) begin
                        if (frame_cnt == (CFG_FRAME_LEN - 16'd1)) begin
                            // 帧尾：强制回到 ST_IDLE 一拍，保证帧间 valid 有间隔
                            frame_cnt <= 16'd0;
                            state <= ST_IDLE;
                            stat_out_frames <= stat_out_frames + 32'd1;
                        end
                        else begin
                            frame_cnt <= frame_cnt + 16'd1;
                        end
                    end
                end
                default : state <= ST_IDLE;
            endcase
        end
    end
endmodule
