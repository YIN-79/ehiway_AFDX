//==============================================================================
// 文件名   : ip_decap.v
// 所属层次 : rtl/ip_udp —— IP 解封装(接收侧)
// 功能描述 : AFDX 端系统 IP 解封装器。从 IP 数据包中剥离 20 字节 IPv4 首部
//            (不支持选项/分片)，输出 UDP 数据报，并给出源/目的 IP、标识、
//            总长度、TTL、协议号等首部信息，供上层做 VL 查找与错误统计。
//            完整性检查(不通过则整包丢弃并给出对应错误脉冲)：
//              - 版本/IHL 必须为 0x45(IPv4，无选项)          -> err_ver
//              - 协议号必须为 17(UDP)                        -> err_proto
//              - 标志/片偏移必须为 0x0000(AFDX 不使用分片)    -> err_frag
//              - TTL 不得为 0                               -> err_ttl
//              - 首部校验和必须正确                          -> err_csum
//              - 总长度字段须 ≥28 且与实际帧字节数一致        -> err_len
//              - 帧在 IP 首部内结束                          -> err_short
// 接口约定 : 8bit 流式 valid-ready 总线，sop/eop 标记帧首/帧尾。
// 备注     : 以太网首部(含 VLID)由 MAC 层模块处理，本模块只处理 IP 层。
//==============================================================================
`timescale 1ns / 1ns
module ip_decap(
    input  wire        clk,
    // 时钟信号
    input  wire        reset,
    // 复位信号(高电平有效)
    //---- IP 数据包输入(来自 MAC 层) ----
    input  wire [7:0]  s_data,
    // 输入数据
    input  wire        s_valid,
    // 输入数据有效
    input  wire        s_sop,
    // 输入帧首字节
    input  wire        s_eop,
    // 输入帧尾字节
    output reg         s_ready,
    // 允许接收输入数据
    //---- UDP 数据报输出(至 udp_decap) ----
    output reg  [7:0]  m_data,
    // 输出数据
    output reg         m_valid,
    // 输出数据有效
    output reg         m_sop,
    // 输出帧首字节
    output reg         m_eop,
    // 输出帧尾字节
    input  wire        m_ready,
    // 下游允许接收
    //---- 首部字段输出(首部解析完成时更新) ----
    output reg  [31:0] o_src_ip,
    // 源 IP 地址
    output reg  [31:0] o_dst_ip,
    // 目的 IP 地址
    output reg  [15:0] o_total_len,
    // IP 总长度字段
    output reg  [15:0] o_id,
    // IP 标识字段
    output reg  [7:0]  o_ttl,
    // TTL
    output reg  [7:0]  o_proto,
    // 协议号
    output reg         o_hdr_valid,
    // 首部解析完成(单拍脉冲)
    //---- 错误指示(单拍脉冲) ----
    output reg         err_ver,
    // 版本/IHL 非法
    output reg         err_proto,
    // 协议号非 UDP
    output reg         err_frag,
    // 出现分片
    output reg         err_ttl,
    // TTL 为 0
    output reg         err_csum,
    // 首部校验和错误
    output reg         err_len,
    // 总长度字段非法或与实际帧长不符
    output reg         err_short
    // 帧在 IP 首部内结束
);
    localparam         [1:0]  ST_IDLE      = 2'd0,
    // 空闲
    ST_HDR = 2'd1,
    // 接收 20 字节 IP 首部
    ST_DATA = 2'd2,
    // 转发 UDP 数据报
    ST_DROP = 2'd3;
    // 丢弃非法包
    localparam         [7:0]  IP_PROTO_UDP = 8'd17;
    // UDP 协议号
    reg  [1:0]   state;
    // 当前状态
    reg  [159:0] hdr_sh;
    // 首部移位寄存器(20 字节)
    reg  [4:0]   hdr_cnt;
    // 已接收首部字节计数
    reg  [15:0]  frame_cnt;
    // 本包已接收字节计数
    reg  [15:0]  total_len_r;
    // 总长度字段锁存(帧尾比较用)
    reg          first_payload;
    // 数据报首字节标志
    //--------------------------------------------------------------------------
    // 首部字段解析(20 字节全部到齐时有效：hdr_sh 低 152bit + 当前字节)
    //--------------------------------------------------------------------------
    wire [159:0] hdr_full = {hdr_sh[151:0], s_data};
    wire [7:0]   hdr_ver_ihl = hdr_full[159:152];
    // 版本/IHL
    wire [15:0]  hdr_tot_len = hdr_full[143:128];
    // 总长度
    wire [15:0]  hdr_flags = hdr_full[111:96];
    // 标志 + 片偏移
    wire [7:0]   hdr_ttl = hdr_full[95:88];
    // TTL
    wire [7:0]   hdr_proto = hdr_full[87:80];
    // 协议号
    //---- 首部校验和(16bit 反码和，正确时结果为 0xffff) ----
    wire [31:0]  hdr_sum = {16'h0000, hdr_full[159:144]} + {16'h0000, hdr_full[143:128]}
    + {16'h0000, hdr_full[127:112]} + {16'h0000, hdr_full[111:96]}
    + {16'h0000, hdr_full[95:80]} + {16'h0000, hdr_full[79:64]}
    + {16'h0000, hdr_full[63:48]} + {16'h0000, hdr_full[47:32]}
    + {16'h0000, hdr_full[31:16]} + {16'h0000, hdr_full[15:0]};
    wire [16:0]  hdr_fold = {1'b0, hdr_sum[15:0]} + {1'b0, hdr_sum[31:16]};
    wire [15:0]  hdr_csum = hdr_fold[15:0] + {15'b0, hdr_fold[16]};
    //---- 首部合法性判断 ----
    wire         bad_ver = (hdr_ver_ihl != 8'h45);
    // 非 IPv4/IHL=5
    wire         bad_proto = (hdr_proto != IP_PROTO_UDP);
    // 非 UDP
    wire         bad_frag = (hdr_flags != 16'h0000);
    // 分片或标志位非 0
    wire         bad_ttl = (hdr_ttl == 8'd0);
    // TTL 为 0
    wire         bad_csum = (hdr_csum != 16'hffff);
    // 校验和错误
    wire         bad_len = (hdr_tot_len < 16'd28);
    // 总长度不足 IP+UDP 首部
    //--------------------------------------------------------------------------
    // 输入握手与输出数据通路
    //--------------------------------------------------------------------------
    always @ (*) begin
        case (state)
            ST_DATA : s_ready = m_ready;
            // 载荷需下游接收
            default : s_ready = 1'b1;
            // 首部/丢弃阶段始终接收
        endcase
    end
    always @ (*) begin
        m_valid = (state == ST_DATA) && s_valid;
        m_data = s_data;
        m_sop = (state == ST_DATA) && first_payload;
        // 数据报首字节(首部后第 1 字节)
        m_eop = (state == ST_DATA) && s_eop;
        // 数据报尾字节
    end
    //--------------------------------------------------------------------------
    // 主状态机
    //--------------------------------------------------------------------------
    always @ (posedge clk or posedge reset) begin
        if (reset) begin
            state <= ST_IDLE;
            hdr_sh <= 160'd0;
            hdr_cnt <= 5'd0;
            frame_cnt <= 16'd0;
            total_len_r <= 16'd0;
            first_payload <= 1'b1;
            o_src_ip <= 32'd0;
            o_dst_ip <= 32'd0;
            o_total_len <= 16'd0;
            o_id <= 16'd0;
            o_ttl <= 8'd0;
            o_proto <= 8'd0;
            o_hdr_valid <= 1'b0;
            err_ver <= 1'b0;
            err_proto <= 1'b0;
            err_frag <= 1'b0;
            err_ttl <= 1'b0;
            err_csum <= 1'b0;
            err_len <= 1'b0;
            err_short <= 1'b0;
        end
        else begin
            // 默认输出单拍脉冲
            o_hdr_valid <= 1'b0;
            err_ver <= 1'b0;
            err_proto <= 1'b0;
            err_frag <= 1'b0;
            err_ttl <= 1'b0;
            err_csum <= 1'b0;
            err_len <= 1'b0;
            err_short <= 1'b0;
            case (state)
                //---- 等待数据包：帧首字节为首部第 0 字节 ----
                ST_IDLE : begin
                    if (s_valid && s_sop) begin
                        hdr_sh <= {152'd0, s_data};
                        hdr_cnt <= 5'd1;
                        frame_cnt <= 16'd1;
                        state <= ST_HDR;
                    end
                end
                //---- 接收 20 字节 IP 首部 ----
                ST_HDR : begin
                    if (s_valid) begin
                        hdr_sh <= {hdr_sh[151:0], s_data};
                        frame_cnt <= frame_cnt + 16'd1;
                        if (hdr_cnt == 5'd19) begin
                            // 首部接收完毕，输出首部字段并给出解析完成脉冲
                            o_src_ip <= hdr_full[63:32];
                            o_dst_ip <= hdr_full[31:0];
                            o_total_len <= hdr_full[143:128];
                            o_id <= hdr_full[127:112];
                            o_ttl <= hdr_full[95:88];
                            o_proto <= hdr_full[87:80];
                            o_hdr_valid <= 1'b1;
                            total_len_r <= hdr_full[143:128];
                            hdr_cnt <= 5'd0;
                            first_payload <= 1'b1;
                            if (s_eop) begin
                                err_short <= 1'b1;
                                // 帧在 IP 首部内结束
                                frame_cnt <= 16'd0;
                                state <= ST_IDLE;
                            end
                            else if (bad_ver || bad_proto || bad_frag ||
                            bad_ttl || bad_csum || bad_len) begin
                                // 首部非法：整包丢弃
                                err_ver <= bad_ver;
                                err_proto <= bad_proto;
                                err_frag <= bad_frag;
                                err_ttl <= bad_ttl;
                                err_csum <= bad_csum;
                                err_len <= bad_len;
                                state <= ST_DROP;
                            end
                            else begin
                                state <= ST_DATA;
                            end
                        end
                        else if (s_eop) begin
                            err_short <= 1'b1;
                            // 首部不完整
                            hdr_cnt <= 5'd0;
                            frame_cnt <= 16'd0;
                            state <= ST_IDLE;
                        end
                        else begin
                            hdr_cnt <= hdr_cnt + 5'd1;
                        end
                    end
                end
                //---- 转发 UDP 数据报 ----
                ST_DATA : begin
                    if (s_valid && m_ready) begin
                        frame_cnt <= frame_cnt + 16'd1;
                        first_payload <= 1'b0;
                        if (s_eop) begin
                            // 总长度字段须与实际字节数一致
                            err_len <= ((frame_cnt + 16'd1) != total_len_r);
                            frame_cnt <= 16'd0;
                            state <= ST_IDLE;
                        end
                    end
                end
                //---- 丢弃非法包(仅接收不输出) ----
                ST_DROP : begin
                    if (s_valid) begin
                        if (s_eop) begin
                            frame_cnt <= 16'd0;
                            state <= ST_IDLE;
                        end
                        else begin
                            frame_cnt <= frame_cnt + 16'd1;
                        end
                    end
                end
                default : state <= ST_IDLE;
            endcase
        end
    end
endmodule
