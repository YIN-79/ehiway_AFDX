//==============================================================================
// 文件名   : udp_ip_wrapper.v
// 所属层次 : rtl/ip_udp —— UDP/IP 协议层双向封装(发送 + 接收)
// 功能描述 : AFDX 端系统 UDP/IP 协议层顶层。对外端口与 AFDX_top.v 中
//            udp_ip_wrapper u_udp_ip_a / u_udp_ip_b 的例化完全一致，
//            内部把已验证的四个模块连成双向数据通路：
//              发送方向：tx_sd_*  -> udp_encap -> ip_encap -> mac_tx_*
//              接收方向：mac_rx_* -> ip_decap  -> udp_decap -> rx_payload_*
// 接口约定 : 8bit 流式 valid-ready 总线，在 valid 与 ready 同时为 1 的时钟
//            上升沿完成一次字节传输；reset 高电平有效、异步复位。
// 分帧约定 : 顶层端口没有 sop/eop 帧边界信号，也没有 VL 配置信号，因此本模块
//            内部自行分帧：
//              (1) 发送方向：按固定载荷长度 CFG_PAYLOAD_LEN 计数分帧。udp_encap
//                  与 ip_encap 在帧首(SOP)即需要准确的载荷长度以填充 UDP 长度
//                  字段与 IP 总长度字段，故上层每帧必须恰好压入
//                  CFG_PAYLOAD_LEN 字节；帧间可无间隔(支持背靠背连续发送)。
//              (2) 接收方向：以 IP 首部的总长度字段(帧内第 2、3 字节)自动分帧，
//                  与本地配置无关，因此允许接收 valid 出现间隙、允许接收的
//                  载荷长度与 CFG_PAYLOAD_LEN 不同(只要 ≤1471 且长度字段自洽，
//                  udp_decap 会校验)。若首部非法(版本非 0x45 或总长度越界)，
//                  以以太网最大净荷 IP_MAX_LEN 兜底结束该帧，保证最多错一帧后
//                  自动重新同步。
// 备注     : (1) AFDX 序列号 SN 位于 UDP 载荷首字节，由上层 tx_redundant 插入，
//                因此 CFG_PAYLOAD_LEN 应等于“业务数据 + 2 字节 SN”的长度；
//            (2) 建议后续为多 VL/变长帧扩展顶层接口：为 MAC 侧补充
//                mac_tx_sop/mac_tx_eop，并增加每 VL 配置总线(源/目的端口、
//                源/目的 IP、载荷长度)。本模块已把相关信号保留为内部信号
//                (u_ip_encap 的 m_sop/m_eop、各模块首部字段与错误脉冲)，
//                扩展时直接引出即可。
//==============================================================================
`timescale 1ns / 1ns
module udp_ip_wrapper #(
    parameter          [15:0] CFG_SRC_PORT    = 16'h0bb8,
    // 源 UDP 端口号
    parameter          [15:0] CFG_DST_PORT    = 16'h0bba,
    // 目的 UDP 端口号
    parameter          [31:0] CFG_SRC_IP      = 32'h0a000001,
    // 源 IP 地址
    parameter          [31:0] CFG_DST_IP      = 32'h0a000002,
    // 目的 IP 地址(VL 多播)
    parameter          [15:0] CFG_PAYLOAD_LEN = 16'd64
    // 每帧业务载荷字节数(TX 分帧)
) (
    input  wire       clk,
    // 时钟信号
    input  wire       reset,
    // 复位信号(高电平有效)
    //---- 发送侧：来自 AFDX_TX 核心的业务载荷(字节流，无帧边界) ----
    input  wire [7:0] tx_sd_data,
    // 业务载荷数据
    input  wire       tx_sd_valid,
    // 数据有效
    output wire       tx_sd_ready,
    // 允许接收
    //---- 发送侧：送往 MAC 的以太网帧净荷(UDP/IP 报文) ----
    output wire [7:0] mac_tx_data,
    // 发送数据
    output wire       mac_tx_valid,
    // 发送数据有效
    input  wire       mac_tx_ready,
    // MAC 允许接收
    output wire       mac_tx_sop,
    // 发送报文帧首(IP 报文第 1 字节)
    output wire       mac_tx_eop,
    // 发送报文帧尾(IP 报文最后 1 字节)
    //---- 接收侧：来自 MAC 的以太网帧净荷 ----
    input  wire [7:0] mac_rx_data,
    // 接收数据
    input  wire       mac_rx_valid,
    // 接收数据有效
    output wire       mac_rx_ready,
    // 允许接收
    //---- 接收侧：上交 AFDX_RX 核心的服务层载荷 ----
    output wire [7:0] rx_payload_data,
    // 载荷数据(含序列号 SN)
    output wire       rx_payload_valid,
    // 载荷数据有效
    input  wire       rx_payload_ready,
    // 上层允许接收
    output wire       rx_payload_sop,
    // 载荷帧首(UDP 载荷第 1 字节，即 SN)
    output wire       rx_payload_eop
    // 载荷帧尾(UDP 载荷最后 1 字节)
);
    //--------------------------------------------------------------------------
    // 常量
    //--------------------------------------------------------------------------
    localparam         [15:0] P_LEN_M1        = CFG_PAYLOAD_LEN - 16'd1;
    // 帧内末字节序号
    localparam         [15:0] IP_MIN_LEN      = 16'd28;
    // IP 首部20+UDP首部8
    localparam         [15:0] IP_MAX_LEN      = 16'd1518;
    // 以太网最大净荷(兜底分帧)
    //==========================================================================
    // 发送方向：分帧 + UDP/IP 封装
    //==========================================================================
    reg  [15:0] tx_frm_cnt;
    // 本帧已发送的载荷字节数
    wire        tx_sop_gen = (tx_frm_cnt == 16'd0);
    // 帧首(该字节为帧内第 0 字节)
    wire        tx_eop_gen = (tx_frm_cnt == P_LEN_M1);
    // 帧尾(该字节为帧内末字节)
    wire        tx_byte_xfer = tx_sd_valid && tx_sd_ready;
    // 本次握手
    always @ (posedge clk or posedge reset) begin
        if (reset) begin
            tx_frm_cnt <= 16'd0;
        end
        else if (tx_byte_xfer) begin
            if (tx_frm_cnt == P_LEN_M1) tx_frm_cnt <= 16'd0;
            // 一帧结束，下一字节即新帧首
            else tx_frm_cnt <= tx_frm_cnt + 16'd1;
        end
    end
    //---- udp_encap 与 ip_encap 之间 ----
    wire [7:0]  ue_data;
    wire        ue_valid, ue_sop, ue_eop, ue_ready, ue_len_err;
    //---- 发送侧帧边界(预留：如 MAC 层需要帧首/帧尾标记，可引出到顶层) ----
    wire [7:0]  ie_data;
    wire        ie_valid, ie_sop, ie_eop, ie_ready, ie_len_err;
    
        udp_encap u_udp_encap(
        .clk(clk),
        .reset(reset),
        .cfg_src_port(CFG_SRC_PORT),
        .cfg_dst_port(CFG_DST_PORT),
        .cfg_payload_len(CFG_PAYLOAD_LEN),
        .s_data(tx_sd_data),
        .s_valid(tx_sd_valid),
        .s_sop(tx_sop_gen),
        .s_eop(tx_eop_gen),
        .s_ready(tx_sd_ready),
        .m_data(ue_data),
        .m_valid(ue_valid),
        .m_sop(ue_sop),
        .m_eop(ue_eop),
        .m_ready(ue_ready),
        .len_err(ue_len_err)
    );
        ip_encap u_ip_encap(
        .clk(clk),
        .reset(reset),
        .cfg_src_ip(CFG_SRC_IP),
        .cfg_dst_ip(CFG_DST_IP),
        .cfg_payload_len(CFG_PAYLOAD_LEN),
        .s_data(ue_data),
        .s_valid(ue_valid),
        .s_sop(ue_sop),
        .s_eop(ue_eop),
        .s_ready(ue_ready),
        .m_data(mac_tx_data),
        .m_valid(mac_tx_valid),
        .m_sop(ie_sop),
        .m_eop(ie_eop),
        .m_ready(mac_tx_ready),
        .len_err(ie_len_err)
    );
    //---- 发送帧边界引出(供顶层以太网首部插入级识别帧首/帧尾) ----
    assign mac_tx_sop = ie_sop;
    assign mac_tx_eop = ie_eop;
    //==========================================================================
    // 接收方向：按 IP 总长度字段分帧 + IP/UDP 解封装
    //==========================================================================
    reg  [15:0] rx_frm_cnt;
    // 本帧已接收字节数
    reg  [7:0]  rx_len_hi;
    // 捕获的总长度高字节(帧内第 2 字节)
    reg  [7:0]  rx_len_lo;
    // 捕获的总长度低字节(帧内第 3 字节)
    reg  [15:0] rx_len_r;
    // 上一帧解析出的总长度(本帧第 4 字节起有效)
    reg         rx_ver_ok;
    // 帧首字节是否为 0x45
    wire        rx_byte_xfer = mac_rx_valid && mac_rx_ready;
    wire        rx_sop_gen = (rx_frm_cnt == 16'd0);
    // 分帧长度：首部合法时用总长度字段，否则用最大帧长兜底(最多错一帧后重新同步)
        wire [15:0] rx_len_use = (rx_ver_ok &&
        (rx_len_r >= IP_MIN_LEN) &&
    (rx_len_r <= IP_MAX_LEN)) ? rx_len_r : IP_MAX_LEN;
    wire        rx_eop_gen = (rx_frm_cnt == (IP_MAX_LEN - 16'd1)) ||
    ((rx_frm_cnt >= 16'd4) && (rx_frm_cnt == (rx_len_use - 16'd1)));
    always @ (posedge clk or posedge reset) begin
        if (reset) begin
            rx_frm_cnt <= 16'd0;
            rx_len_hi <= 8'h00;
            rx_len_lo <= 8'h00;
            rx_len_r <= 16'd0;
            rx_ver_ok <= 1'b0;
        end
        else if (rx_byte_xfer) begin
            if (rx_frm_cnt == 16'd0) begin
                rx_ver_ok <= (mac_rx_data == 8'h45);
                // 版本=4, IHL=5
            end
            else if (rx_frm_cnt == 16'd2) begin
                rx_len_hi <= mac_rx_data;
                // IP 总长度 高字节
            end
            else if (rx_frm_cnt == 16'd3) begin
                rx_len_lo <= mac_rx_data;
                // IP 总长度 低字节
                rx_len_r <= {rx_len_hi, mac_rx_data};
                // 第 4 字节起可用于分帧
            end
            if (rx_eop_gen) rx_frm_cnt <= 16'd0;
            else rx_frm_cnt <= rx_frm_cnt + 16'd1;
        end
    end
    //---- ip_decap 与 udp_decap 之间 ----
    wire [7:0]  id_data;
    wire        id_valid, id_sop, id_eop, id_ready;
    //---- ip_decap 首部字段与错误脉冲(预留：可引出到顶层供 VL 查找/统计) ----
    wire [31:0] id_src_ip, id_dst_ip;
    wire [15:0] id_total_len, id_id;
    wire [7:0]  id_ttl, id_proto;
    wire        id_hdr_valid;
    wire        id_err_ver, id_err_proto, id_err_frag, id_err_ttl;
    wire        id_err_csum, id_err_len, id_err_short;
        ip_decap u_ip_decap(
        .clk(clk),
        .reset(reset),
        .s_data(mac_rx_data),
        .s_valid(mac_rx_valid),
        .s_sop(rx_sop_gen),
        .s_eop(rx_eop_gen),
        .s_ready(mac_rx_ready),
        .m_data(id_data),
        .m_valid(id_valid),
        .m_sop(id_sop),
        .m_eop(id_eop),
        .m_ready(id_ready),
        .o_src_ip(id_src_ip),
        .o_dst_ip(id_dst_ip),
        .o_total_len(id_total_len),
        .o_id(id_id),
        .o_ttl(id_ttl),
        .o_proto(id_proto),
        .o_hdr_valid(id_hdr_valid),
        .err_ver(id_err_ver),
        .err_proto(id_err_proto),
        .err_frag(id_err_frag),
        .err_ttl(id_err_ttl),
        .err_csum(id_err_csum),
        .err_len(id_err_len),
        .err_short(id_err_short)
    );
    //---- udp_decap 首部字段与错误脉冲(预留) ----
    wire [15:0] ud_src_port, ud_dst_port, ud_udp_len, ud_udp_chksum;
    wire        ud_hdr_valid, ud_err_len, ud_err_short;
        udp_decap u_udp_decap(
        .clk(clk),
        .reset(reset),
        .s_data(id_data),
        .s_valid(id_valid),
        .s_sop(id_sop),
        .s_eop(id_eop),
        .s_ready(id_ready),
        .m_data(rx_payload_data),
        .m_valid(rx_payload_valid),
        .m_sop(rx_payload_sop),
        .m_eop(rx_payload_eop),
        .m_ready(rx_payload_ready),
        .o_src_port(ud_src_port),
        .o_dst_port(ud_dst_port),
        .o_udp_len(ud_udp_len),
        .o_udp_chksum(ud_udp_chksum),
        .o_hdr_valid(ud_hdr_valid),
        .err_udp_len(ud_err_len),
        .err_short(ud_err_short)
    );
endmodule
