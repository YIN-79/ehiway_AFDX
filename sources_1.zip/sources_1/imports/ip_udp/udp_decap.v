//==============================================================================
// 文件名   : udp_decap.v
// 所属层次 : rtl/ip_udp —— UDP 解封装(接收侧)
// 功能描述 : AFDX 端系统 UDP 解封装器。从 UDP 数据报中剥离 8 字节 UDP 首部，
//            输出服务层载荷(AFDX 载荷，首字节为序列号 SN)，同时给出源端口、
//            目的端口、UDP 长度字段，供上层进行 VL 查找(VLID 由目的端口 +
//            以太网首部共同确定)。
//            首部校验内容：
//              - UDP 长度字段必须 ≥ 8 且与数据报实际字节数一致，否则整帧丢弃
//                并给出 err_udp_len 脉冲；
//              - 数据报在首部内即结束(不足 8 字节)给出 err_short 脉冲并丢弃。
// 接口约定 : 8bit 流式 valid-ready 总线，sop/eop 标记帧首/帧尾。
// 备注     : UDP 校验和字段原样输出(o_udp_chksum)，AFDX 中该字段固定为 0，
//            本模块不做校验和运算（由上层冗余管理/完整性检查负责）。
//==============================================================================
`timescale 1ns / 1ns
module udp_decap(
    input  wire        clk,
    // 时钟信号
    input  wire        reset,
    // 复位信号(高电平有效)
    //---- UDP 数据报输入(来自 ip_decap) ----
    input  wire [7:0]  s_data,
    // 输入数据
    input  wire        s_valid,
    // 输入数据有效
    input  wire        s_sop,
    // 输入帧首字节
    input  wire        s_eop,
    // 输入帧尾字节
    output reg         s_ready,
    // 允许接收输入数据
    //---- 服务层载荷输出 ----
    output reg  [7:0]  m_data,
    // 输出数据(载荷，含序列号 SN)
    output reg         m_valid,
    // 输出数据有效
    output reg         m_sop,
    // 输出帧首字节
    output reg         m_eop,
    // 输出帧尾字节
    input  wire        m_ready,
    // 下游允许接收
    //---- 首部字段输出(首部解析完成时更新) ----
    output reg  [15:0] o_src_port,
    // 源端口号
    output reg  [15:0] o_dst_port,
    // 目的端口号
    output reg  [15:0] o_udp_len,
    // UDP 长度字段
    output reg  [15:0] o_udp_chksum,
    // UDP 校验和字段(未校验)
    output reg         o_hdr_valid,
    // 首部解析完成(单拍脉冲)
    //---- 错误指示(单拍脉冲) ----
    output reg         err_udp_len,
    // 长度字段非法或与实际帧长不符
    output reg         err_short
    // 帧在 UDP 首部内结束
);
    localparam         [1:0]  ST_IDLE = 2'd0,
    // 空闲
    ST_HDR = 2'd1,
    // 接收 8 字节 UDP 首部
    ST_DATA = 2'd2,
    // 转发载荷
    ST_DROP = 2'd3;
    // 丢弃非法帧
    reg  [1:0]  state;
    // 当前状态
    reg  [63:0] hdr_sh;
    // 首部移位寄存器(8 字节)
    reg  [3:0]  hdr_cnt;
    // 已接收首部字节计数
    reg  [15:0] frame_cnt;
    // 本数据报已接收字节计数
    reg         first_payload;
    // 载荷首字节标志
    //--------------------------------------------------------------------------
    // 首部字段解析(8 字节全部到齐时有效：hdr_sh 低 56bit + 当前字节)
    //--------------------------------------------------------------------------
    wire [63:0] hdr_full = {hdr_sh[55:0], s_data};
    //--------------------------------------------------------------------------
    // 输入握手(组合)
    //--------------------------------------------------------------------------
    always @ (*) begin
        case (state)
            ST_DATA : s_ready = m_ready;
            // 载荷需下游接收
            default : s_ready = 1'b1;
            // 首部/丢弃阶段始终接收
        endcase
    end
    //--------------------------------------------------------------------------
    // 输出数据通路(组合)
    //--------------------------------------------------------------------------
    always @ (*) begin
        m_valid = (state == ST_DATA) && s_valid;
        m_data = s_data;
        m_sop = (state == ST_DATA) && first_payload;
        // 载荷首字节
        m_eop = (state == ST_DATA) && s_eop;
        // 载荷尾字节
    end
    //--------------------------------------------------------------------------
    // 主状态机
    //--------------------------------------------------------------------------
    always @ (posedge clk or posedge reset) begin
        if (reset) begin
            state <= ST_IDLE;
            hdr_sh <= 64'd0;
            hdr_cnt <= 4'd0;
            frame_cnt <= 16'd0;
            first_payload <= 1'b1;
            o_src_port <= 16'd0;
            o_dst_port <= 16'd0;
            o_udp_len <= 16'd0;
            o_udp_chksum <= 16'd0;
            o_hdr_valid <= 1'b0;
            err_udp_len <= 1'b0;
            err_short <= 1'b0;
        end
        else begin
            o_hdr_valid <= 1'b0;
            // 默认输出单拍脉冲
            err_udp_len <= 1'b0;
            err_short <= 1'b0;
            case (state)
                //---- 等待数据报：帧首字节为首部第 0 字节 ----
                ST_IDLE : begin
                    if (s_valid && s_sop) begin
                        hdr_sh <= {56'd0, s_data};
                        hdr_cnt <= 4'd1;
                        frame_cnt <= 16'd1;
                        state <= ST_HDR;
                    end
                end
                //---- 接收 8 字节 UDP 首部 ----
                ST_HDR : begin
                    if (s_valid) begin
                        hdr_sh <= {hdr_sh[55:0], s_data};
                        frame_cnt <= frame_cnt + 16'd1;
                        if (hdr_cnt == 4'd7) begin
                            // 首部接收完毕，输出端口/长度信息
                            o_src_port <= hdr_full[63:48];
                            o_dst_port <= hdr_full[47:32];
                            o_udp_len <= hdr_full[31:16];
                            o_udp_chksum <= hdr_full[15:0];
                            o_hdr_valid <= 1'b1;
                            hdr_cnt <= 4'd0;
                            first_payload <= 1'b1;
                            if (s_eop) begin
                                err_short <= 1'b1;
                                // 帧在首部内结束
                                frame_cnt <= 16'd0;
                                state <= ST_IDLE;
                            end
                            else if (hdr_full[31:16] < 16'd8) begin
                                err_udp_len <= 1'b1;
                                // 长度字段非法
                                state <= ST_DROP;
                            end
                            else begin
                                state <= ST_DATA;
                            end
                        end
                        else if (s_eop) begin
                            err_short <= 1'b1;
                            // 首部不完整
                            hdr_cnt <= 4'd0;
                            frame_cnt <= 16'd0;
                            state <= ST_IDLE;
                        end
                        else begin
                            hdr_cnt <= hdr_cnt + 4'd1;
                        end
                    end
                end
                //---- 转发载荷 ----
                ST_DATA : begin
                    if (s_valid && m_ready) begin
                        frame_cnt <= frame_cnt + 16'd1;
                        first_payload <= 1'b0;
                        if (s_eop) begin
                            // 长度字段须与实际字节数一致
                            err_udp_len <= ((frame_cnt + 16'd1) != o_udp_len);
                            frame_cnt <= 16'd0;
                            state <= ST_IDLE;
                        end
                    end
                end
                //---- 丢弃非法帧的剩余字节 ----
                ST_DROP : begin
                    if (s_valid) begin
                        if (s_eop) begin
                            frame_cnt <= 16'd0;
                            state <= ST_IDLE;
                        end
                        else begin
                            frame_cnt <= frame_cnt + 16'd1;
                        end
                    end
                end
                default : state <= ST_IDLE;
            endcase
        end
    end
endmodule
