`timescale 1ns/1ns
// Bounded IPv4/UDP reassembly after per-frame IC and A/B redundancy removal.
// Context key: VL, IPv4 Identification, source/destination IP (UDP protocol is
// checked at MAC). Out-of-order fragments are supported; ANY overlap aborts
// the context. No bytes are published until length and UDP checksum validate.
module afdx_ip_reassembly #(
    parameter MAX_MESSAGE=8192,CONTEXTS=2,TIMEOUT_TICKS=1000
)(
    input wire clk,reset,input wire [31:0] now_ms,
    input wire [7:0] s_data,input wire s_valid,output wire s_ready,
    input wire s_sop,s_eop,s_fragment,
    input wire [15:0] s_vlid,s_length,s_sport,s_dport,
    input wire [31:0] s_sip,s_dip,
    output wire [7:0] m_data,output wire m_valid,input wire m_ready,
    output wire m_sop,m_eop,output wire [15:0] m_vlid,m_length,m_sport,m_dport,
    output wire [31:0] m_sip,m_dip,
    output reg [31:0] stat_completed,stat_rejected,stat_timeout
);
    localparam CAPACITY=MAX_MESSAGE+8,BLOCKS=(CAPACITY+7)/8;
    localparam IDLE=0,INGEST=1,DROP=2,CHECK_REQ=3,CHECK_USE=4,OUT_WAIT=5,OUTPUT=6;
    reg [2:0] state;
    (* ramstyle="M4K, no_rw_check" *) reg [7:0] mem[0:CONTEXTS*CAPACITY-1];
    reg [CONTEXTS-1:0] active,have_first,have_last;
    reg [BLOCKS-1:0] seen[0:CONTEXTS-1];
    reg [15:0] vl[0:CONTEXTS-1],ident[0:CONTEXTS-1],bytes_received[0:CONTEXTS-1];
    reg [15:0] last_end[0:CONTEXTS-1],udp_size[0:CONTEXTS-1],high_end[0:CONTEXTS-1];
    reg [31:0] sip[0:CONTEXTS-1],dip[0:CONTEXTS-1],started[0:CONTEXTS-1];
    reg [63:0] udp_header[0:CONTEXTS-1];
    integer selected,match_slot,free_slot,k,j,expired_count;
    reg [15:0] offset,pos,piece,check_pos,out_pos;
    reg more,bad;
    reg [31:0] check_sum;
    reg [7:0] high_byte,data_q;
    reg [15:0] out_size;
    reg [63:0] out_header;
    wire [16:0] incoming_offset={1'b0,s_dport[12:0],3'b000};
    wire [17:0] incoming_end={1'b0,incoming_offset}+s_length;
    wire [16:0] absolute={1'b0,offset}+pos;
    wire bypass=state==IDLE && !s_fragment;
    wire expired_selected=active[selected] && (now_ms-started[selected]>=TIMEOUT_TICKS);
    always @*begin
        match_slot=-1;free_slot=-1;expired_count=0;
        for(j=0;j<CONTEXTS;j=j+1)begin
            if(active[j] && now_ms-started[j]<TIMEOUT_TICKS && vl[j]==s_vlid &&
               ident[j]==s_sport && sip[j]==s_sip && dip[j]==s_dip)match_slot=j;
            if(!active[j] || now_ms-started[j]>=TIMEOUT_TICKS)free_slot=j;
            if(active[j] && now_ms-started[j]>=TIMEOUT_TICKS && !(state!=IDLE && j==selected))expired_count=expired_count+1;
        end
    end
    wire [15:0] read_index=(state==OUTPUT)?
        (out_pos+8+((m_valid && m_ready && !m_eop)?1:0)):check_pos;
    always @(posedge clk)begin
        data_q<=mem[selected*CAPACITY+read_index];
        if(!reset && s_valid && s_ready)begin
            if(state==IDLE && s_fragment && s_sop && s_length>0 && incoming_end<=CAPACITY &&
               (match_slot>=0 || free_slot>=0))
                mem[(match_slot>=0?match_slot:free_slot)*CAPACITY+incoming_offset]<=s_data;
            else if(state==INGEST && absolute<CAPACITY)mem[selected*CAPACITY+absolute]<=s_data;
        end
    end
    assign s_ready=!reset && (bypass?m_ready:(state==IDLE || (state==INGEST && pos<piece) || state==DROP));
    assign m_valid=!reset && (bypass?s_valid:state==OUTPUT);
    assign m_data=bypass?s_data:data_q;
    assign m_sop=bypass?s_sop:out_pos==0;
    assign m_eop=bypass?s_eop:out_pos+1==out_size;
    assign m_length=bypass?s_length:out_size;
    assign m_vlid=bypass?s_vlid:vl[selected];
    assign m_sport=bypass?s_sport:out_header[63:48];
    assign m_dport=bypass?s_dport:out_header[47:32];
    assign m_sip=bypass?s_sip:sip[selected];
    assign m_dip=bypass?s_dip:dip[selected];
    function checksum_valid;
        input [31:0] v;reg [31:0] f;
        begin f=(v&32'hffff)+(v>>16);f=(f&32'hffff)+(f>>16);checksum_valid=f[15:0]==16'hffff;end
    endfunction
    reg [31:0] final_sum;
    always @*begin
        final_sum=check_sum+sip[selected][31:16]+sip[selected][15:0]+
            dip[selected][31:16]+dip[selected][15:0]+17+udp_size[selected];
        if(check_pos[0])final_sum=final_sum+{high_byte,data_q};
        else final_sum=final_sum+{data_q,8'd0};
    end
    always @(posedge clk or posedge reset)begin
        if(reset)begin
            state<=IDLE;active<=0;have_first<=0;have_last<=0;selected<=0;
            offset<=0;pos<=0;piece<=0;more<=0;bad<=0;check_pos<=0;out_pos<=0;
            check_sum<=0;high_byte<=0;out_size<=0;out_header<=0;
            stat_completed<=0;stat_rejected<=0;stat_timeout<=0;
            for(k=0;k<CONTEXTS;k=k+1)begin seen[k]<=0;vl[k]<=0;ident[k]<=0;
                bytes_received[k]<=0;last_end[k]<=0;udp_size[k]<=0;high_end[k]<=0;
                sip[k]<=0;dip[k]<=0;started[k]<=0;udp_header[k]<=0;end
        end else begin
            // Retire one expired context per cycle, including while idle.
            // A context currently being drained/verified is pinned.
            for(k=0;k<CONTEXTS;k=k+1)begin
                if(active[k] && now_ms-started[k]>=TIMEOUT_TICKS &&
                   !(state!=IDLE && k==selected))begin
                    active[k]<=0;seen[k]<=0;have_first[k]<=0;have_last[k]<=0;
                end
            end
            case(state)
            IDLE:if(s_valid && s_ready && s_fragment)begin
                if(!s_sop || s_length==0 || s_eop!=(s_length==1) || incoming_end>CAPACITY || s_dport[15:14]!=0 ||
                   (s_dport[13] && s_length[2:0]!=0) || (match_slot<0 && free_slot<0))begin
                    stat_rejected<=stat_rejected+1'b1;state<=s_eop?IDLE:DROP;
                    if(match_slot>=0)active[match_slot]<=0;
                end else begin
                    selected<=match_slot>=0?match_slot:free_slot;
                    offset<=incoming_offset[15:0];pos<=1;piece<=s_length;more<=s_dport[13];bad<=s_eop!=(s_length==1);
                    state<=INGEST;
                    if(match_slot<0)begin
                        active[free_slot]<=1;seen[free_slot]<=0;have_first[free_slot]<=0;have_last[free_slot]<=0;
                        bytes_received[free_slot]<=0;last_end[free_slot]<=0;udp_size[free_slot]<=0;high_end[free_slot]<=0;
                        vl[free_slot]<=s_vlid;ident[free_slot]<=s_sport;sip[free_slot]<=s_sip;dip[free_slot]<=s_dip;
                        started[free_slot]<=now_ms;udp_header[free_slot]<=0;
                    end else if(seen[match_slot][incoming_offset>>3] ||
                        (have_last[match_slot] && incoming_end>last_end[match_slot]))bad<=1;
                    if(incoming_offset==0)udp_header[match_slot>=0?match_slot:free_slot][63:56]<=s_data;
                    // A legal fragmented last piece can contain one byte.
                end
            end
            INGEST:if((s_valid && s_ready) || pos==piece)begin
                if(pos<piece)begin
                    if(s_sop || s_eop!=(pos+1==piece))bad<=1;
                    if(pos[2:0]==0 && seen[selected][absolute>>3])bad<=1;
                    if(absolute<8)udp_header[selected][63-absolute*8 -:8]<=s_data;
                    if(absolute==5)udp_size[selected]<={udp_header[selected][31:24],s_data};
                    if(pos[2:0]==7)seen[selected][absolute>>3]<=1;
                    pos<=pos+1'b1;
                    if(s_eop && pos+1!=piece)begin
                        active[selected]<=0;state<=IDLE;stat_rejected<=stat_rejected+1'b1;
                    end else if(!s_eop && pos+1==piece)begin
                        active[selected]<=0;state<=DROP;stat_rejected<=stat_rejected+1'b1;
                    end
                end else begin
                    state<=IDLE;
                    if(bad || expired_selected ||
                       (!more && have_last[selected] && last_end[selected]!=offset+piece) ||
                       (have_first[selected] && offset+piece>udp_size[selected]))begin
                        active[selected]<=0;stat_rejected<=stat_rejected+1'b1;
                    end else begin
                        seen[selected][(offset+piece-1)>>3]<=1;
                        bytes_received[selected]<=bytes_received[selected]+piece;
                        if(offset+piece>high_end[selected])high_end[selected]<=offset+piece;
                        if(offset==0)have_first[selected]<=1;
                        if(!more)begin have_last[selected]<=1;last_end[selected]<=offset+piece;end
                        // Completion is checked in CHECK_REQ on the following
                        // cycle, after first-fragment UDP fields have settled.
                        state<=CHECK_REQ;check_pos<=0;check_sum<=0;
                    end
                end
            end
            DROP:if(s_valid && s_ready && s_eop)state<=IDLE;
            CHECK_REQ:begin
                if(!have_first[selected] || !have_last[selected])state<=IDLE;
                else if(udp_size[selected]<9 || udp_size[selected]>CAPACITY ||
                    last_end[selected]!=udp_size[selected] || high_end[selected]>udp_size[selected] || bytes_received[selected]>udp_size[selected])begin
                    active[selected]<=0;state<=IDLE;stat_rejected<=stat_rejected+1'b1;
                end else if(bytes_received[selected]!=udp_size[selected])state<=IDLE;
                else state<=CHECK_USE;
            end
            CHECK_USE:begin
                if(check_pos[0])check_sum<=check_sum+{high_byte,data_q};else high_byte<=data_q;
                if(check_pos+1==udp_size[selected])begin
                    if((udp_header[selected][15:0]!=0 && !checksum_valid(final_sum)) ||
                       !((udp_header[selected][63:48]==3000 && udp_header[selected][47:32]==3002) ||
                         udp_header[selected][47:32]==161 || udp_header[selected][47:32]==69 ||
                         udp_header[selected][47:32]>=49152))begin
                        active[selected]<=0;state<=IDLE;stat_rejected<=stat_rejected+1'b1;
                    end else begin
                        out_size<=udp_size[selected]-8;out_header<=udp_header[selected];out_pos<=0;
                        check_pos<=8;state<=OUT_WAIT;
                    end
                end else begin check_pos<=check_pos+1'b1;state<=CHECK_REQ;end
            end
            OUT_WAIT:state<=OUTPUT;
            OUTPUT:if(m_valid && m_ready)begin
                if(m_eop)begin active[selected]<=0;state<=IDLE;stat_completed<=stat_completed+1'b1;end
                else out_pos<=out_pos+1'b1;
            end
            default:state<=IDLE;
            endcase
            if(expired_count!=0)stat_timeout<=stat_timeout+expired_count;
        end
    end
endmodule
