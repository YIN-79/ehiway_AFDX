//==============================================================================
// 文件名   : ip_encap.v
// 所属层次 : rtl/ip_udp —— IP 封装(发送侧)
// 功能描述 : AFDX 端系统 IP 封装器。在 UDP 数据报前添加 20 字节 IPv4 首部
//            (无选项，IHL=5)，构成完整的 IP 数据包，送 MAC 层添加以太网首部。
//              IPv4 首部 = 版本/IHL、TOS、总长度、标识、标志/片偏移、TTL、
//                          协议、首部校验和、源 IP、目的 IP
//            符合 ARINC 664 P7 的约定：
//              - 不使用 IP 分片：标识=0x0000，标志/片偏移=0x0000；
//              - 协议号固定为 17(UDP)；
//              - TTL 默认 1（同一 AFDX 网络内不跨路由）；
//              - 目的 IP 为 VL 多播地址(由 cfg_dst_ip 给出)。
// 接口约定 : 8bit 流式 valid-ready 总线，sop/eop 标记帧首/帧尾。
// 备注     : cfg_payload_len 必须与 udp_encap 的 cfg_payload_len 完全一致，
//            本模块据此计算 IP 总长度 = 20 + 8 + 载荷长度。
//==============================================================================
`timescale 1ns / 1ns
module ip_encap #(
    parameter          [31:0] SRC_IP_DEFAULT = 32'h0a000001,
    // 默认源 IP(10.0.0.1)
    parameter          [7:0]  TTL_DEFAULT    = 8'd1,
    // 默认 TTL
    parameter          [15:0] MAX_PAYLOAD    = 16'd1471
    // AFDX 最大载荷字节数
) (
    input  wire        clk,
    // 时钟信号
    input  wire        reset,
    // 复位信号(高电平有效)
    //---- VL 配置(发送前写入，一帧内保持不变) ----
    input  wire [31:0] cfg_src_ip,
    // 源 IP 地址
    input  wire [31:0] cfg_dst_ip,
    // 目的 IP 地址(VL 多播地址)
    input  wire [15:0] cfg_payload_len,
    // 服务层载荷字节数(与 udp_encap 一致)
    //---- UDP 数据报输入(来自 udp_encap) ----
    input  wire [7:0]  s_data,
    // 输入数据
    input  wire        s_valid,
    // 输入数据有效
    input  wire        s_sop,
    // 输入帧首字节
    input  wire        s_eop,
    // 输入帧尾字节
    output wire        s_ready,
    // 允许接收输入数据
    //---- IP 数据包输出(送至 MAC 层) ----
    output reg  [7:0]  m_data,
    // 输出数据
    output reg         m_valid,
    // 输出数据有效
    output reg         m_sop,
    // 输出帧首字节
    output reg         m_eop,
    // 输出帧尾字节
    input  wire        m_ready,
    // 下游允许接收
    //---- 状态指示 ----
    output reg         len_err
    // 载荷长度与配置不符(帧尾单拍脉冲)
);
    localparam         [1:0]  ST_IDLE        = 2'd0,
    // 空闲
    ST_HDR = 2'd1,
    // 发送 20 字节 IP 首部
    ST_DATA = 2'd2;
    // 转发 UDP 数据报
    localparam         [7:0]  IP_PROTO_UDP   = 8'd17;
    // UDP 协议号
    reg  [1:0]  state;
    // 当前状态
    reg  [4:0]  hdr_cnt;
    // 首部已发送字节计数
    reg  [15:0] datagram_cnt;
    // 已转发数据报字节计数
    reg  [31:0] src_ip_r;
    // 源 IP 锁存
    reg  [31:0] dst_ip_r;
    // 目的 IP 锁存
    reg  [15:0] payload_len_r;
    // 载荷长度锁存
    reg  [7:0]  ttl_r;
    // TTL 锁存
    //---- 帧首字节暂存：ST_IDLE 拍与上游完成一次真实握手，该字节不能丢 ----
    reg         sop_hold_v;
    // 1=已暂存 UDP 首部第 1 字节，待 IP 首部发完后补发
    reg  [7:0]  sop_hold_d;
    // 暂存的帧首字节内容
    reg         sop_hold_eop;
    // 暂存字节同时是帧尾(数据报仅 1 字节)
    // IP 总长度 = IP 首部(20) + UDP 首部(8) + 载荷
    wire [15:0] ip_len = 16'd28 + payload_len_r;
    //--------------------------------------------------------------------------
    // IPv4 首部校验和(16bit 反码和取反，组合逻辑)
    //   sum_raw 为 10 个 16bit 字(校验和字段按 0 参与)之和
    //--------------------------------------------------------------------------
    // 按 IPv4 首部顺序累加十个 16 位字段；零扩展到 32 位以保留进位。
    wire [31:0] sum_raw =
          {16'h0000, 16'h4500}          // 版本、首部长度、服务类型
        + {16'h0000, ip_len}            // IP 总长度
        + 32'h0000_0000                 // 标识：固定为 0
        + 32'h0000_0000                 // 标志和分片偏移：固定为 0
        + {16'h0000, ttl_r, IP_PROTO_UDP} // TTL 和协议号
        + 32'h0000_0000                 // 计算时校验和字段置 0
        + {16'h0000, src_ip_r[31:16]}    // 源 IP 高 16 位
        + {16'h0000, src_ip_r[15:0]}     // 源 IP 低 16 位
        + {16'h0000, dst_ip_r[31:16]}    // 目的 IP 高 16 位
        + {16'h0000, dst_ip_r[15:0]};    // 目的 IP 低 16 位

    wire [16:0] sum_fold = {1'b0, sum_raw[15:0]} + {1'b0, sum_raw[31:16]};
    wire [15:0] ip_chksum = ~(sum_fold[15:0] + {15'b0, sum_fold[16]});
    //--------------------------------------------------------------------------
    // 首部字节选择(组合)
    //--------------------------------------------------------------------------
    reg  [7:0]  hdr_byte;
    always @ (*) begin
        case (hdr_cnt)
            5'd0 : hdr_byte = 8'h45;
            // 版本=4, IHL=5
            5'd1 : hdr_byte = 8'h00;
            // TOS
            5'd2 : hdr_byte = ip_len[15:8];
            // 总长度 高字节
            5'd3 : hdr_byte = ip_len[7:0];
            // 总长度 低字节
            5'd4 : hdr_byte = 8'h00;
            // 标识 高字节(AFDX 置 0)
            5'd5 : hdr_byte = 8'h00;
            // 标识 低字节
            5'd6 : hdr_byte = 8'h00;
            // 标志/片偏移 高字节(不分片)
            5'd7 : hdr_byte = 8'h00;
            // 标志/片偏移 低字节
            5'd8 : hdr_byte = ttl_r;
            // TTL
            5'd9 : hdr_byte = IP_PROTO_UDP;
            // 协议号 = 17
            5'd10 : hdr_byte = ip_chksum[15:8];
            // 首部校验和 高字节
            5'd11 : hdr_byte = ip_chksum[7:0];
            // 首部校验和 低字节
            5'd12 : hdr_byte = src_ip_r[31:24];
            // 源 IP
            5'd13 : hdr_byte = src_ip_r[23:16];
            5'd14 : hdr_byte = src_ip_r[15:8];
            5'd15 : hdr_byte = src_ip_r[7:0];
            5'd16 : hdr_byte = dst_ip_r[31:24];
            // 目的 IP
            5'd17 : hdr_byte = dst_ip_r[23:16];
            5'd18 : hdr_byte = dst_ip_r[15:8];
            default : hdr_byte = dst_ip_r[7:0];
        endcase
    end
    //--------------------------------------------------------------------------
    // 输入握手(ST_IDLE 时就绪，接收 UDP 首部第 1 字节) 与输出数据通路
    //--------------------------------------------------------------------------
    //   本模块接口约定"valid 与 ready 同时为 1 的上升沿完成一次字节传输"，
    //   故 ST_IDLE 拍(s_ready=1)上游给出的帧首字节是一次真实传输，必须暂存到
    //   sop_hold_* 并在 IP 首部发完后补发，否则会丢掉 UDP 首部第 1 字节
    //   (源端口高字节)，导致 UDP 首部整体前移 1 字节、长度字段与实际不符。
    //   暂存字节未补发前不接受新的输入字节，避免再次丢字节。
    assign s_ready = (state == ST_IDLE) ? 1'b1 :
    ((state == ST_DATA) && m_ready && !sop_hold_v);
    always @ (*) begin
        m_valid = 1'b0;
        m_sop = 1'b0;
        m_eop = 1'b0;
        m_data = 8'h00;
        case (state)
            ST_HDR : begin
                m_valid = 1'b1;
                m_data = hdr_byte;
                m_sop = (hdr_cnt == 5'd0);
                // 首部第 1 字节即帧首
                m_eop = 1'b0;
            end
            ST_DATA : begin
                if (sop_hold_v) begin
                    // 先补发 ST_IDLE 拍接收到的 UDP 首部第 1 字节
                    m_valid = 1'b1;
                    m_data = sop_hold_d;
                    m_sop = 1'b0;
                    // 帧首只在本模块首部第 1 字节
                    m_eop = sop_hold_eop;
                    // 数据报仅 1 字节时该字节即帧尾
                end
                else begin
                    m_valid = s_valid;
                    m_data = s_data;
                    m_sop = 1'b0;
                    // 帧首只在本模块首部第 1 字节
                    m_eop = s_eop;
                    // 数据报尾字节即帧尾
                end
            end
            default :;
        endcase
    end
    //--------------------------------------------------------------------------
    // 主状态机
    //--------------------------------------------------------------------------
    always @ (posedge clk or posedge reset) begin
        if (reset) begin
            state <= ST_IDLE;
            hdr_cnt <= 5'd0;
            datagram_cnt <= 16'd0;
            src_ip_r <= SRC_IP_DEFAULT;
            dst_ip_r <= 32'h00000000;
            payload_len_r <= 16'd0;
            ttl_r <= TTL_DEFAULT;
            sop_hold_v <= 1'b0;
            sop_hold_d <= 8'h00;
            sop_hold_eop <= 1'b0;
            len_err <= 1'b0;
        end
        else begin
            len_err <= 1'b0;
            // 默认无长度错误
            case (state)
                //---- 等待 UDP 数据报：出现帧首即开始封装 ----
                ST_IDLE : begin
                    if (s_valid && s_sop) begin
                        // 本次握手完成了一次真实字节传输：暂存帧首字节，稍后补发
                        sop_hold_v <= 1'b1;
                        sop_hold_d <= s_data;
                        sop_hold_eop <= s_eop;
                        src_ip_r <= cfg_src_ip;
                        dst_ip_r <= cfg_dst_ip;
                        payload_len_r <= cfg_payload_len;
                        ttl_r <= TTL_DEFAULT;
                        hdr_cnt <= 5'd0;
                        datagram_cnt <= 16'd0;
                        state <= ST_HDR;
                    end
                end
                //---- 发送 20 字节 IP 首部 ----
                ST_HDR : begin
                    if (m_ready) begin
                        if (hdr_cnt == 5'd19) begin
                            hdr_cnt <= 5'd0;
                            state <= ST_DATA;
                        end
                        else begin
                            hdr_cnt <= hdr_cnt + 5'd1;
                        end
                    end
                end
                //---- 转发 UDP 数据报 ----
                ST_DATA : begin
                    if (sop_hold_v) begin
                        // 先补发 ST_IDLE 拍接收的 UDP 首部第 1 字节(计入数据报长度)
                        if (m_ready) begin
                            sop_hold_v <= 1'b0;
                            if (sop_hold_eop) begin
                                // 数据报仅 1 字节(帧首即帧尾)：发完立即回到空闲
                                len_err <= ((datagram_cnt + 16'd1) != (16'd8 + payload_len_r)) ||
                                (payload_len_r > MAX_PAYLOAD) ||
                                (payload_len_r == 16'd0);
                                datagram_cnt <= 16'd0;
                                state <= ST_IDLE;
                            end
                            else begin
                                datagram_cnt <= datagram_cnt + 16'd1;
                            end
                        end
                    end
                    else if (s_valid && m_ready) begin
                        datagram_cnt <= datagram_cnt + 16'd1;
                        if (s_eop) begin
                            // UDP 数据报长度应等于 8 + 载荷长度
                            len_err <= ((datagram_cnt + 16'd1) != (16'd8 + payload_len_r)) ||
                            (payload_len_r > MAX_PAYLOAD) ||
                            (payload_len_r == 16'd0);
                            datagram_cnt <= 16'd0;
                            state <= ST_IDLE;
                        end
                    end
                end
                default : state <= ST_IDLE;
            endcase
        end
    end
endmodule
