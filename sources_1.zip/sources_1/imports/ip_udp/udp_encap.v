//==============================================================================
// 文件名   : udp_encap.v
// 所属层次 : rtl/ip_udp —— UDP 封装(发送侧)
// 功能描述 : AFDX 端系统 UDP 封装器。在服务层载荷(AFDX 数据)前添加 8 字节 UDP
//            首部，构成 UDP 数据报，输出给 ip_encap 继续封装 IP 首部。
//              UDP 首部 = 源端口(2) + 目的端口(2) + UDP 长度(2) + UDP 校验和(2)
//            依据 ARINC 664 P7，AFDX 不使用 UDP 校验和，该字段固定填 0x0000，
//            数据完整性由以太网 FCS + VL 级冗余管理保证。
// 接口约定 : 8bit 流式 valid-ready 总线。sop 标记帧首字节、eop 标记帧尾字节；
//            在 valid 与 ready 同时为 1 的时钟上升沿完成一次字节传输。
// 备注     : (1) UDP 长度字段 = 8 + cfg_payload_len，因此发送前必须给出准确的
//                载荷长度；若实际载荷字节数与配置不符，len_err 输出单拍脉冲。
//            (2) AFDX 序列号(SN)位于 UDP 载荷首字节，由上层(tx_redundant /
//                vl_scheduler)插入，本模块只添加 UDP 首部，不改变载荷内容。
//==============================================================================
`timescale 1ns / 1ns
module udp_encap #(
    parameter          [15:0] SRC_PORT_DEFAULT = 16'h0bb8,
    // 默认源端口号(49152)
    parameter          [15:0] DST_PORT_DEFAULT = 16'h0bba,
    // 默认目的端口号(49210)
    parameter          [15:0] MAX_PAYLOAD      = 16'd1471
    // AFDX 最大载荷字节数
) (
    input  wire        clk,
    // 时钟信号
    input  wire        reset,
    // 复位信号(高电平有效)
    //---- VL 配置(发送前写入，一帧内保持不变) ----
    input  wire [15:0] cfg_src_port,
    // 源 UDP 端口号
    input  wire [15:0] cfg_dst_port,
    // 目的 UDP 端口号
    input  wire [15:0] cfg_payload_len,
    // 服务层载荷字节数(1~1471)
    //---- 服务层数据输入 ----
    input  wire [7:0]  s_data,
    // 输入数据
    input  wire        s_valid,
    // 输入数据有效
    input  wire        s_sop,
    // 输入帧首字节
    input  wire        s_eop,
    // 输入帧尾字节
    output wire        s_ready,
    // 允许接收输入数据
    //---- UDP 数据报输出(至 ip_encap) ----
    output reg  [7:0]  m_data,
    // 输出数据
    output reg         m_valid,
    // 输出数据有效
    output reg         m_sop,
    // 输出帧首字节
    output reg         m_eop,
    // 输出帧尾字节
    input  wire        m_ready,
    // 下游允许接收
    //---- 状态指示 ----
    output reg         len_err
    // 载荷长度与配置不符(帧尾单拍脉冲)
);
    //--------------------------------------------------------------------------
    // 状态编码
    //--------------------------------------------------------------------------
    localparam         [1:0]  ST_IDLE          = 2'd0,
    // 空闲，等待新帧
    ST_HDR = 2'd1,
    // 发送 8 字节 UDP 首部
    ST_DATA = 2'd2;
    // 转发服务层载荷
    reg  [1:0]  state;
    // 当前状态
    reg  [2:0]  hdr_cnt;
    // 首部已发送字节计数
    reg  [15:0] payload_cnt;
    // 已转发载荷字节计数
    reg  [15:0] src_port_r;
    // 源端口锁存
    reg  [15:0] dst_port_r;
    // 目的端口锁存
    reg  [15:0] payload_len_r;
    // 载荷长度锁存
    //---- 帧首字节暂存：ST_IDLE 拍与上游完成一次真实握手，该字节不能丢 ----
    reg         sop_hold_v;
    // 1=已暂存帧首字节，待首部发完后补发
    reg  [7:0]  sop_hold_d;
    // 暂存的帧首字节内容
    reg         sop_hold_eop;
    // 暂存字节同时是帧尾(载荷仅 1 字节)
    wire [15:0] udp_len = 16'd8 + payload_len_r;
    // UDP 长度字段
    //--------------------------------------------------------------------------
    // 首部字节选择(组合)
    //--------------------------------------------------------------------------
    reg  [7:0]  hdr_byte;
    always @ (*) begin
        case (hdr_cnt)
            3'd0 : hdr_byte = src_port_r[15:8];
            // 源端口 高字节
            3'd1 : hdr_byte = src_port_r[7:0];
            // 源端口 低字节
            3'd2 : hdr_byte = dst_port_r[15:8];
            // 目的端口 高字节
            3'd3 : hdr_byte = dst_port_r[7:0];
            // 目的端口 低字节
            3'd4 : hdr_byte = udp_len[15:8];
            // UDP 长度 高字节
            3'd5 : hdr_byte = udp_len[7:0];
            // UDP 长度 低字节
            3'd6 : hdr_byte = 8'h00;
            // UDP 校验和 高字节
            default : hdr_byte = 8'h00;
            // UDP 校验和 低字节
        endcase
    end
    //--------------------------------------------------------------------------
    // 输入握手：ST_IDLE 时就绪(接收新帧首字节) / 载荷转发阶段受下游 m_ready 反压
    //   —— 与 udp_decap/ip_decap 的约定一致：空闲态必须给出 ready，否则上游
    //      "valid 由 ready 门控"的实现会与本模块形成互锁(双方都等对方)。
    //--------------------------------------------------------------------------
    //   本模块接口约定"valid 与 ready 同时为 1 的上升沿完成一次字节传输"，
    //   故 ST_IDLE 拍(s_ready=1)上游给出的帧首字节是一次真实传输，必须暂存到
    //   sop_hold_* 并在首部发完后作为载荷第 1 字节补发，否则会丢掉载荷首字节
    //   (即 SN 高字节)。暂存字节未补发前不接受新的输入字节，避免再次丢字节。
    assign s_ready = (state == ST_IDLE) ? 1'b1 :
    ((state == ST_DATA) && m_ready && !sop_hold_v);
    //--------------------------------------------------------------------------
    // 输出数据通路(组合输出)
    //--------------------------------------------------------------------------
    always @ (*) begin
        m_valid = 1'b0;
        m_sop = 1'b0;
        m_eop = 1'b0;
        m_data = 8'h00;
        case (state)
            ST_HDR : begin
                m_valid = 1'b1;
                m_data = hdr_byte;
                m_sop = (hdr_cnt == 3'd0);
                // 首部第 1 字节即帧首
                m_eop = 1'b0;
            end
            ST_DATA : begin
                if (sop_hold_v) begin
                    // 先补发 ST_IDLE 拍接收到的载荷首字节
                    m_valid = 1'b1;
                    m_data = sop_hold_d;
                    m_sop = 1'b0;
                    // 帧首只在本模块首部第 1 字节
                    m_eop = sop_hold_eop;
                    // 载荷仅 1 字节时该字节即帧尾
                end
                else begin
                    m_valid = s_valid;
                    m_data = s_data;
                    m_sop = 1'b0;
                    // 帧首只在本模块首部第 1 字节
                    m_eop = s_eop;
                    // 载荷尾字节即帧尾
                end
            end
            default :;
        endcase
    end
    //--------------------------------------------------------------------------
    // 主状态机
    //--------------------------------------------------------------------------
    always @ (posedge clk or posedge reset) begin
        if (reset) begin
            state <= ST_IDLE;
            hdr_cnt <= 3'd0;
            payload_cnt <= 16'd0;
            src_port_r <= SRC_PORT_DEFAULT;
            dst_port_r <= DST_PORT_DEFAULT;
            payload_len_r <= 16'd0;
            sop_hold_v <= 1'b0;
            sop_hold_d <= 8'h00;
            sop_hold_eop <= 1'b0;
            len_err <= 1'b0;
        end
        else begin
            len_err <= 1'b0;
            // 默认无长度错误
            case (state)
                //---- 等待新帧：出现帧首即开始封装 ----
                ST_IDLE : begin
                    if (s_valid && s_sop) begin
                        // 本次握手完成了一次真实字节传输：暂存帧首字节，稍后补发
                        sop_hold_v <= 1'b1;
                        sop_hold_d <= s_data;
                        sop_hold_eop <= s_eop;
                        src_port_r <= cfg_src_port;
                        dst_port_r <= cfg_dst_port;
                        payload_len_r <= cfg_payload_len;
                        hdr_cnt <= 3'd0;
                        payload_cnt <= 16'd0;
                        state <= ST_HDR;
                    end
                end
                //---- 发送 8 字节 UDP 首部 ----
                ST_HDR : begin
                    if (m_ready) begin
                        if (hdr_cnt == 3'd7) begin
                            hdr_cnt <= 3'd0;
                            state <= ST_DATA;
                        end
                        else begin
                            hdr_cnt <= hdr_cnt + 3'd1;
                        end
                    end
                end
                //---- 转发服务层载荷 ----
                ST_DATA : begin
                    if (sop_hold_v) begin
                        // 先补发 ST_IDLE 拍接收的载荷首字节(计入载荷长度)
                        if (m_ready) begin
                            sop_hold_v <= 1'b0;
                            if (sop_hold_eop) begin
                                // 载荷仅 1 字节(帧首即帧尾)：发完立即回到空闲
                                len_err <= ((payload_cnt + 16'd1) != payload_len_r) ||
                                (payload_len_r > MAX_PAYLOAD) ||
                                (payload_len_r == 16'd0);
                                payload_cnt <= 16'd0;
                                state <= ST_IDLE;
                            end
                            else begin
                                payload_cnt <= payload_cnt + 16'd1;
                            end
                        end
                    end
                    else if (s_valid && m_ready) begin
                        payload_cnt <= payload_cnt + 16'd1;
                        if (s_eop) begin
                            // 校验实际载荷长度是否与配置一致
                            len_err <= ((payload_cnt + 16'd1) != payload_len_r) ||
                            (payload_len_r > MAX_PAYLOAD) ||
                            (payload_len_r == 16'd0);
                            payload_cnt <= 16'd0;
                            state <= ST_IDLE;
                        end
                    end
                end
                default : state <= ST_IDLE;
            endcase
        end
    end
endmodule
