`timescale 1ns/1ns
// Long application datagrams are buffered atomically, then emitted as IPv4
// payload fragments. Ordinary <=1471-byte messages retain the old fast path.
// Raw fragment metadata: sport=Identification, dport={flags,offset}; no private
// bytes are added. The first fragment contains the real eight-byte UDP header.
module afdx_ip_fragment_tx #(parameter MAX_MESSAGE=8192, FRAGMENT_BYTES=1464)(
    input wire clk,reset,
    input wire [7:0] s_data,input wire s_valid,output wire s_ready,
    input wire s_sop,s_eop,input wire [15:0] s_vlid,s_length,
    input wire s_header_valid,input wire [15:0] s_sport,s_dport,
    input wire [31:0] s_sip,s_dip,
    output wire [7:0] m_data,output wire m_valid,input wire m_ready,
    output wire m_sop,m_eop,m_fragment,m_header_valid,
    output wire [15:0] m_vlid,m_length,m_sport,m_dport,
    output wire [31:0] m_sip,m_dip,
    output reg [31:0] stat_bad_message
);
    localparam IDLE=0,CAPTURE=1,EMIT=2,DRAIN=3;
    reg [1:0] state;
    (* ramstyle="M4K, no_rw_check" *) reg [7:0] mem[0:MAX_MESSAGE-1];
    reg [15:0] count,total,vl,ident,next_ident,base,pos;
    reg [95:0] headers;
    reg bad;
    wire long_start=state==IDLE && s_length>1471;
    wire bypass=state==IDLE && !long_start;
    wire [15:0] datagram_length=total+16'd8;
    wire [15:0] remaining=datagram_length-base;
    wire [15:0] piece=remaining>FRAGMENT_BYTES?FRAGMENT_BYTES:remaining;
    wire [15:0] absolute=base+pos;
    wire [15:0] flags_offset=(remaining>FRAGMENT_BYTES?16'h2000:16'h0000)|(base>>3);
    // Synchronous read-ahead; base/pos stay unchanged under downstream stalls.
    reg [7:0] data_q;
    wire [15:0] next_absolute=(state==EMIT && m_ready)?absolute+1:absolute;
    always @(posedge clk)begin
        data_q<=mem[next_absolute<8?0:next_absolute-8];
        if(!reset && s_valid && s_ready && (long_start || (state==CAPTURE && count<MAX_MESSAGE)))
            mem[state==IDLE?0:count]<=s_data;
    end
    reg [7:0] emit_data;
    always @*begin
        emit_data=data_q;
        if(absolute<8)case(absolute)
            0:emit_data=headers[95:88];1:emit_data=headers[87:80];
            2:emit_data=headers[79:72];3:emit_data=headers[71:64];
            4:emit_data=datagram_length[15:8];5:emit_data=datagram_length[7:0];
            default:emit_data=0; // IPv4 permits disabled UDP checksum.
        endcase
    end
    assign s_ready=!reset && (bypass?m_ready:state!=EMIT);
    assign m_valid=!reset && (bypass?s_valid:state==EMIT);
    assign m_data=bypass?s_data:emit_data;
    assign m_sop=bypass?s_sop:pos==0;
    assign m_eop=bypass?s_eop:pos+1==piece;
    assign m_fragment=!bypass;
    assign m_header_valid=bypass?s_header_valid:1'b1;
    assign m_vlid=bypass?s_vlid:vl;
    assign m_length=bypass?s_length:piece;
    assign m_sport=bypass?s_sport:ident;
    assign m_dport=bypass?s_dport:flags_offset;
    assign m_sip=bypass?s_sip:headers[63:32];
    assign m_dip=bypass?s_dip:headers[31:0];
    always @(posedge clk or posedge reset)begin
        if(reset)begin state<=IDLE;count<=0;total<=0;vl<=0;ident<=0;next_ident<=0;
            base<=0;pos<=0;headers<=0;bad<=0;stat_bad_message<=0;end
        else begin
            if(s_valid && s_ready)begin
                if(long_start)begin
                    count<=1;total<=s_length;vl<=s_vlid;bad<=!s_sop;
                    headers<=s_header_valid?{s_sport,s_dport,s_sip,s_dip}:
                        {16'd3000,16'd3002,32'h0a000001,32'h0a000002};
                    ident<=next_ident;next_ident<=next_ident+1'b1;
                    if(s_length>MAX_MESSAGE || !s_sop || s_eop)begin
                        stat_bad_message<=stat_bad_message+1'b1;state<=s_eop?IDLE:DRAIN;
                    end else state<=CAPTURE;
                end else if(state==CAPTURE)begin
                    count<=count+1'b1;
                    if(s_sop)bad<=1;
                    if(s_eop)begin
                        if(bad || s_sop || count+1!=total)begin
                            stat_bad_message<=stat_bad_message+1'b1;state<=IDLE;
                        end else begin state<=EMIT;base<=0;pos<=0;end
                    end else if(count+1>=total)begin
                        stat_bad_message<=stat_bad_message+1'b1;state<=DRAIN;
                    end
                end else if(state==DRAIN && s_eop)state<=IDLE;
            end
            if(state==EMIT && m_valid && m_ready)begin
                if(m_eop)begin
                    pos<=0;
                    if(base+piece==datagram_length)state<=IDLE;
                    else base<=base+piece;
                end else pos<=pos+1'b1;
            end
        end
    end
endmodule
