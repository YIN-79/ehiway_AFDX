`timescale 1ns/1ns
//=============================================================================
// vl_scheduler.v  —— AFDX 端系统虚拟链路调度器：每VL队列 + 按帧SN
//
//  功能：
//   1) 615A 业务载荷按 payload_vl_id 写入对应 VL 的 FIFO，帧由 payload_sop/eop 界定；
//   2) 只有"整帧收齐"（FIFO 中出现过 EOP）后 vl_has_data 才置位，避免把半帧发出去；
//   3) 每发完一帧 SN = SN + 1，255 回卷到 1，复位为 0；
//   4) 超长帧处理（AFDX 规则：超过 LMAX 的帧不可发送）：
//        帧内字节序号 > LMAX（LMAX=0 表示不限）→ 整帧丢弃并回滚；
//        帧内 FIFO 已满（帧比 FIFO 容量还大）→ 同样整帧丢弃，避免死锁；
//   5) 下游 vl_tx_ready 反压：未就绪时保持数据与 vl_tx_valid 不变。
//
//  相比骨架版本新增的端口（需在 afdx_tx_core 里把 615A 侧信息接进来）：
//    payload_vl_id / payload_sop / payload_eop / vl_tx_last / vl_over_len
//=============================================================================
module vl_scheduler
    #(
    parameter                 VL_NUM     = 2,
    //虚拟链路数量，和顶层保持一致
    parameter                 FIFO_DEPTH = 32,
    //每个VL的FIFO深度（字节）
    parameter                 DATA_W     = 8,
    //业务载荷位宽
    //VL号位宽：按 VL_NUM 自动推导（最多支持16条VL）
    parameter                 VL_ID_W    = (VL_NUM <= 2) ? 1 : (VL_NUM <= 4) ? 2 :
    (VL_NUM <= 8) ? 3 : 4,
    //FIFO指针位宽：按 FIFO_DEPTH 自动推导
    parameter                 PTR_W      = (FIFO_DEPTH <= 2) ? 1 : (FIFO_DEPTH <= 4) ? 2 :
    (FIFO_DEPTH <= 8) ? 3 : (FIFO_DEPTH <= 16) ? 4 :
    (FIFO_DEPTH <= 32) ? 5 : (FIFO_DEPTH <= 64) ? 6 :
    (FIFO_DEPTH <= 128) ? 7 : 8,
    parameter                 CNT_W      = PTR_W + 1
    //计数 0..FIFO_DEPTH
) (
    input  wire                     clk,
    //时钟信号
    input  wire                     reset,
    //复位信号，高电平复位
    //来自SNMP-MIB的VL配置参数
    input  wire [32 * VL_NUM - 1:0] vl_cfg_bag,
    //每条VL的bag配置（ms）
    input  wire [32 * VL_NUM - 1:0] vl_cfg_lmax,
    //每条VL的lmax最大帧长度（字节，0=不限）
    //来自615A的业务载荷输入
    input  wire [DATA_W - 1:0]      payload_data,
    //业务载荷字节输入
    input  wire [VL_ID_W - 1:0]     payload_vl_id,
    //本字节所属的VL号
    input  wire                     payload_sop,
    //帧首字节指示
    input  wire                     payload_eop,
    //帧尾字节指示
    input  wire                     payload_valid,
    //输入数据有效标志
    output wire                     payload_ready,
    //可接收本字节（该VL FIFO 未满）
    //输出给bag_regulator的调度结果
    output wire [VL_NUM - 1:0]      vl_has_data,
    //每bit代表对应的VL是否有整帧可发送
    output wire [8 * VL_NUM - 1:0]  vl_sn_out,
    //每条VL当前SN（下一个待发帧的SN）
    output wire [32 * VL_NUM - 1:0] vl_lmax_out,
    //每条VL的LMAX参数输出
    //握手反馈：bag_regulator选中某VL并允许发送一帧
    input  wire [VL_NUM - 1:0]      vl_grant,
    //授权：允许该VL发送一帧
    output wire [DATA_W - 1:0]      vl_tx_data,
    //被选中VL读出的载荷字节
    output wire                     vl_tx_valid,
    //被选中VL读出的载荷字节有效
    output wire                     vl_tx_last,
    //本字节为该帧的最后一个字节
    input  wire                     vl_tx_ready,
    //下游接收就绪
    //状态指示
    output wire [VL_NUM - 1:0]      vl_over_len
    //刚丢弃一个超长/放不下的整帧（单拍脉冲）
);
    //------------------------------------------------------------------------
    // 内部信号：所有VL的FIFO共用一块RAM，按 VL_ID*FIFO_DEPTH 分段
    //------------------------------------------------------------------------
    localparam                FIFO_SZ    = VL_NUM * FIFO_DEPTH;
    reg     [DATA_W - 1:0]  fifo_mem[0:FIFO_SZ - 1];
    //业务载荷数据
    reg                     fifo_eop[0:FIFO_SZ - 1];
    //该字节是否为帧尾
    reg     [PTR_W - 1:0]   wr_ptr[0:VL_NUM - 1];
    //写指针
    reg     [PTR_W - 1:0]   rd_ptr[0:VL_NUM - 1];
    //读指针
    reg     [CNT_W - 1:0]   fifo_cnt[0:VL_NUM - 1];
    //FIFO内字节数
    reg     [CNT_W - 1:0]   frame_cnt[0:VL_NUM - 1];
    //FIFO内已收齐的整帧数
    reg     [7:0]           sn_reg[0:VL_NUM - 1];
    //SN序列号，0-255循环
    reg     [15:0]          frame_len[0:VL_NUM - 1];
    //当前正在接收的帧已收到的字节数
    reg     [CNT_W - 1:0]   frame_wr[0:VL_NUM - 1];
    //当前帧已写入FIFO的字节数（用于回滚）
    reg                     frame_drop[0:VL_NUM - 1];
    //当前帧已判定丢弃
    wire    [VL_NUM - 1:0]  fifo_empty;
    //FIFO空标志（供调试观察）
    wire    [VL_NUM - 1:0]  fifo_full;
    //FIFO满标志
    genvar                  gi;
    generate
            for (gi = 0; gi < VL_NUM; gi = gi + 1) begin : g_flag
            assign fifo_empty[gi] = (fifo_cnt[gi] == {CNT_W {1'b0}});
            assign fifo_full[gi] = (fifo_cnt[gi] == FIFO_DEPTH);
            assign vl_has_data[gi] = (frame_cnt[gi] != {CNT_W {1'b0}});
            //有"整帧"待发才置位
            assign vl_sn_out[gi * 8 +: 8] = sn_reg[gi];
        end
    endgenerate
    assign vl_lmax_out = vl_cfg_lmax;
    //------------------------------------------------------------------------
    // 写侧（615A业务载荷入队）：按VL号分流、按 sop/eop 组帧
    //   payload_ready 规则：
    //     - 帧首字节：该VL的FIFO 有空间才接收（无空间则反压等待，不丢数据）
    //     - 帧内字节：恒为1；此时若FIFO已满，本帧被判定"放不下"→整帧丢弃，
    //                 既不会死锁，也不会把半帧留在FIFO里
    //------------------------------------------------------------------------
    wire    [VL_ID_W - 1:0] wr_vl = payload_vl_id;
    wire                    wr_vl_ok = (payload_vl_id < VL_NUM);
    //VL号合法性
    wire                    vl_full_now = fifo_full[wr_vl];
    assign payload_ready = wr_vl_ok & (payload_sop ? ~vl_full_now : 1'b1);
    wire                    wr_en = payload_valid & payload_ready;
    wire    [31:0]          wr_lmax = vl_cfg_lmax[wr_vl * 32 +: 32];
    wire    [15:0]          wr_index = payload_sop ? 16'd1 : (frame_len[wr_vl] + 16'd1);
    wire                    wr_over_len = (wr_lmax != 32'd0) && (wr_index > wr_lmax[15:0]);
    wire                    wr_over_fifo = vl_full_now && ~payload_sop;
    wire                    wr_drop = payload_sop ? wr_over_len
    : (frame_drop[wr_vl] | wr_over_len | wr_over_fifo);
    wire                    wr_store = wr_en & ~wr_drop;
    //本字节写入FIFO
    //帧结束且被丢弃、或新帧首字节到达而上一帧未收完 → 回滚该帧已写入的字节
        wire    [CNT_W - 1:0]   wr_roll = (wr_en && (frame_wr[wr_vl] != {CNT_W {1'b0}}) &&
    (payload_eop ? wr_drop : payload_sop))
    ? frame_wr[wr_vl] : {CNT_W {1'b0}};
    //FIFO 数据存储：每拍最多写入一个字节
    always @ (posedge clk) begin
        if (wr_store) begin
            fifo_mem[wr_vl * FIFO_DEPTH + wr_ptr[wr_vl]] <= payload_data;
            fifo_eop[wr_vl * FIFO_DEPTH + wr_ptr[wr_vl]] <= payload_eop;
        end
    end
    //------------------------------------------------------------------------
    // 发送侧：从"被授权且已有整帧"的VL中选最低编号者，把该帧连续读出
    //   - 帧一旦开始就发到帧尾(vl_tx_last=1)，与 vl_grant 是否保持无关（授权一帧）
    //   - 下游未就绪时保持 vl_tx_data / vl_tx_valid 不变（反压）
    //------------------------------------------------------------------------
    reg     [VL_NUM - 1:0]  vl_over_len_r;
    //超长帧丢弃事件（寄存器输出）
    reg                     tx_state;
    //0=空闲, 1=正在发送一帧
    reg     [VL_ID_W - 1:0] tx_vl;
    //当前发送的VL号
    reg                     tx_start;
    //存在可发送的VL
    reg     [VL_ID_W - 1:0] tx_start_vl;
    //被选中的VL号
    integer                 k;
    always @ * begin
        tx_start = 1'b0;
        tx_start_vl = {VL_ID_W {1'b0}};
        for (k = VL_NUM - 1; k >= 0; k = k - 1) begin
            if (vl_grant[k] && (frame_cnt[k] != {CNT_W {1'b0}})) begin
                //降序循环→最低编号优先
                tx_start = 1'b1;
                tx_start_vl = k[VL_ID_W - 1:0];
            end
        end
    end
    wire    [DATA_W - 1:0]  tx_byte_cur = fifo_mem[tx_vl * FIFO_DEPTH + rd_ptr[tx_vl]];
    wire                    tx_eop_cur = fifo_eop[tx_vl * FIFO_DEPTH + rd_ptr[tx_vl]];
    wire                    tx_active = (tx_state == 1'b1);
    assign vl_tx_valid = tx_active;
    assign vl_tx_data = tx_active ? tx_byte_cur : {DATA_W {1'b0}};
    assign vl_tx_last = tx_active & tx_eop_cur;
    wire                    tx_pop = tx_active & vl_tx_ready;
    //下游接收一拍
    wire                    tx_frame_done = tx_pop & tx_eop_cur;
    //整帧发送完成
    assign vl_over_len = vl_over_len_r;
    //------------------------------------------------------------------------
    // 指针/计数/SN 更新（单一always块避免多驱动；同拍读写同一VL时计数合并计算）
    //------------------------------------------------------------------------
    integer                 i;
    always @ (posedge clk or posedge reset) begin
        if (reset) begin
            for (i = 0; i < VL_NUM; i = i + 1) begin
                wr_ptr[i] <= {PTR_W {1'b0}};
                rd_ptr[i] <= {PTR_W {1'b0}};
                fifo_cnt[i] <= {CNT_W {1'b0}};
                frame_cnt[i] <= {CNT_W {1'b0}};
                sn_reg[i] <= 8'd0;
                //复位时SN置0
                frame_len[i] <= 16'd0;
                frame_wr[i] <= {CNT_W {1'b0}};
                frame_drop[i] <= 1'b0;
            end
            vl_over_len_r <= {VL_NUM {1'b0}};
            tx_state <= 1'b0;
            tx_vl <= {VL_ID_W {1'b0}};
        end else begin
            //---- 发送状态机 ----
            if (tx_active) begin
                if (tx_frame_done) tx_state <= 1'b0;
                //一帧结束，回空闲
            end else if (tx_start) begin
                tx_state <= 1'b1;
                tx_vl <= tx_start_vl;
                //本帧发完后需重新授权
            end
            //---- 超长/放不下的整帧被丢弃 → 单拍脉冲 ----
            vl_over_len_r <= {VL_NUM {1'b0}};
            if (wr_roll != {CNT_W {1'b0}}) vl_over_len_r[wr_vl] <= 1'b1;
            for (i = 0; i < VL_NUM; i = i + 1) begin
                //---- 写侧：写指针与帧状态 ----
                if (wr_en && (wr_vl == i[VL_ID_W - 1:0])) begin
                    wr_ptr[i] <= wr_ptr[i] - wr_roll + (wr_store ? 1'b1 : 1'b0);
                    if (payload_eop) begin
                        frame_wr[i] <= {CNT_W {1'b0}};
                        //帧结束：无残留可回滚
                        frame_len[i] <= 16'd0;
                        frame_drop[i] <= 1'b0;
                    end else begin
                        frame_wr[i] <= payload_sop ? {{(CNT_W - 1) {1'b0}}, 1'b1}
                        : (wr_store ? (frame_wr[i] + 1'b1) : frame_wr[i]);
                        frame_len[i] <= wr_index;
                        //本字节在帧内的序号
                        frame_drop[i] <= wr_drop;
                    end
                end
                //---- 读侧：读指针 ----
                if (tx_pop && (tx_vl == i[VL_ID_W - 1:0])) begin
                    rd_ptr[i] <= rd_ptr[i] + 1'b1;
                end
                //---- 字节数：合并本拍 写入(+1) / 读出(-1) / 回滚(-N) ----
                fifo_cnt[i] <= fifo_cnt[i]
                    + ((wr_store && (wr_vl == i[VL_ID_W - 1:0]))
                ? {{(CNT_W - 1) {1'b0}}, 1'b1} : {CNT_W {1'b0}})
                    - ((tx_pop && (tx_vl == i[VL_ID_W - 1:0]))
                ? {{(CNT_W - 1) {1'b0}}, 1'b1} : {CNT_W {1'b0}})
                    - (((wr_roll != {CNT_W {1'b0}}) && (wr_vl == i[VL_ID_W - 1:0]))
                ? wr_roll : {CNT_W {1'b0}});
                //---- 整帧数：收齐一帧(+1) / 发完一帧(-1) ----
                frame_cnt[i] <= frame_cnt[i]
                    + ((wr_store && payload_eop && (wr_vl == i[VL_ID_W - 1:0]))
                ? {{(CNT_W - 1) {1'b0}}, 1'b1} : {CNT_W {1'b0}})
                    - ((tx_frame_done && (tx_vl == i[VL_ID_W - 1:0]))
                ? {{(CNT_W - 1) {1'b0}}, 1'b1} : {CNT_W {1'b0}});
                //---- SN：每发完一帧 +1，到255回卷到1 ----
                if (tx_frame_done && (tx_vl == i[VL_ID_W - 1:0])) begin
                    sn_reg[i] <= (sn_reg[i] == 8'd255) ? 8'd1 : (sn_reg[i] + 8'd1);
                end
            end
        end
    end
endmodule
