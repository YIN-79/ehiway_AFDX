//==============================================================================
// 文件名   : tx_redundant.v
// 所属层次 : rtl/tx_core —— AFDX 发送冗余管理(SN 插入 + A/B 双网复制)
// 功能描述 : 位于 afdx_tx_core 内部，介于 vl_scheduler / bag_regulator 与两条
//            udp_ip_wrapper 之间，实现 ARINC 664 P7 的发送冗余功能：
//              (1) SN 插入：每个被调度帧在业务数据前插入 SN 字段（默认 2 字节：
//                  第 1 字节为 8bit 序列号，取自 vl_scheduler 的 vl_sn_out；
//                  第 2 字节为保留字节 0x00，便于日后扩展 16bit SN）。
//              (2) 双网复制：把插入 SN 后的完整帧逐字节原样复制到 A、B 两路，
//                  A/B 两路字节内容完全一致（含相同 SN）。
//              (3) 反压：只有 A、B 两路都 ready 时才推进，保证两路严格同步、
//                  不丢字节、不乱序；并把反压经 vl_tx_ready 传回 vl_scheduler。
// 接口约定 : 8bit 流式 valid-ready 总线，在 valid 与 ready 同时为 1 的时钟上升沿
//            完成一次字节传输；reset 高电平有效、异步复位。
// 分帧约定 : 由 vl_tx_last 判定帧尾；vl_scheduler 保证帧间 vl_tx_valid 至少拉低
//            1 拍，本模块据此(上升沿)识别新帧起点并锁存当前帧 SN。
// 备注     : (1) SN_BYTES 需与 load_ctrl_fsm 的 CFG_FRAME_LEN、udp_ip_wrapper 的
//                CFG_PAYLOAD_LEN 配套：CFG_FRAME_LEN + SN_BYTES = CFG_PAYLOAD_LEN
//                (当前工程为 62 + 2 = 64)。
//            (2) 当前帧所属 VL 号来自 bag_regulator 的 vl_grant / vl_grant_id：
//                授权单拍发生在帧开始前 1 拍(发送通道空闲)，故在授权拍锁存
//                vl_grant_id，帧开始拍据此从 vl_sn_out 取出对应 VL 的 SN。
//==============================================================================
`timescale 1ns / 1ns
module tx_redundant #(
    parameter                 VL_NUM   = 2,
    // 虚拟链路数量，和顶层保持一致
    // VL 号位宽：按 VL_NUM 自动推导(最多 16 条 VL)
    parameter                 VL_ID_W  = (VL_NUM <= 2) ? 1 : (VL_NUM <= 4) ? 2 :
    (VL_NUM <= 8) ? 3 : 4,
    parameter                 SN_BYTES = 2
    // 插入的 SN 字段字节数(业务数据 + SN_BYTES = 载荷长度)
) (
    input  wire                    clk,
    // 时钟信号
    input  wire                    reset,
    // 复位信号(高电平有效)
    //---- 来自 vl_scheduler 的已调度帧(业务数据，不含 SN) ----
    input  wire [7:0]              vl_tx_data,
    // 被调度 VL 读出的载荷字节
    input  wire                    vl_tx_valid,
    // 载荷字节有效
    input  wire                    vl_tx_last,
    // 本字节为该帧最后一字节
    output wire                    vl_tx_ready,
    // 本模块可接收(反压回 vl_scheduler)
    input  wire [8 * VL_NUM - 1:0] vl_sn_out,
    // 各 VL 当前帧 SN(每 VL 8bit)
    input  wire [VL_NUM - 1:0]     vl_grant,
    // bag_regulator 授权(单拍 one-hot)
    input  wire [VL_ID_W - 1:0]    vl_grant_id,
    // 本拍被授权的 VL 号(与 vl_grant 同拍)
    //---- 当前发送帧所属 VL 号(引出到顶层，用于生成以太网首部 DA 的 VL 字段) ----
    output wire [VL_ID_W - 1:0]    vl_id_out,
    //---- 冗余复制输出 A(直连 afdx_tx_core 的 a_out_*) ----
    output wire [7:0]              a_out_data,
    // A 通道发送数据
    output wire                    a_out_valid,
    // A 通道发送数据有效
    input  wire                    a_out_ready,
    // A 通道接收就绪
    //---- 冗余复制输出 B(直连 afdx_tx_core 的 b_out_*) ----
    output wire [7:0]              b_out_data,
    // B 通道发送数据
    output wire                    b_out_valid,
    // B 通道发送数据有效
    input  wire                    b_out_ready,
    // B 通道接收就绪
    //---- 统计 ----
    output reg  [31:0]             stat_tx_frame_cnt
    // 已发送帧计数(上报 MIB)
);
    //--------------------------------------------------------------------------
    // 状态编码
    //--------------------------------------------------------------------------
    localparam         [1:0]  S_IDLE   = 2'd0,
    // 帧间空闲，等待新帧
    S_SN = 2'd1,
    // 输出 SN 字段
    S_DATA = 2'd2;
    // 转发业务数据
    localparam         [3:0]  SN_LAST  = SN_BYTES - 1;
    // SN 字段末字节序号
    reg  [1:0]           state;
    // 当前状态
    reg  [3:0]           sn_cnt;
    // SN 字段已输出字节数(0..SN_BYTES-1)
    reg  [7:0]           sn_cur;
    // 当前帧锁存的 8bit SN
    reg  [VL_ID_W - 1:0] cur_vl;
    // 当前帧所属 VL 号
    reg                  vl_tx_valid_r;
    // vl_tx_valid 的 1 拍延迟(用于识别帧首)
    //--------------------------------------------------------------------------
    // 当前 VL 锁存：授权(单拍)发生在帧开始前 1 拍(发送通道空闲)，故在授权拍
    // 锁存 vl_grant_id，供下一拍帧首时取出对应 VL 的 SN。
    //--------------------------------------------------------------------------
    always @ (posedge clk or posedge reset) begin
        if (reset)
        cur_vl <= {VL_ID_W {1'b0}};
        else if (| vl_grant)
        cur_vl <= vl_grant_id;
    end
    //--------------------------------------------------------------------------
    // 帧首识别：vl_tx_valid 上升沿(帧间至少 1 拍为低，由 vl_scheduler 保证)
    //--------------------------------------------------------------------------
    always @ (posedge clk or posedge reset) begin
        if (reset)
        vl_tx_valid_r <= 1'b0;
        else
        vl_tx_valid_r <= vl_tx_valid;
    end
    wire                 frame_start = vl_tx_valid && !vl_tx_valid_r;
    // 当前帧 VL 号引出：顶层以太网首部插入级据此拼 DA 的低 16 位
    assign vl_id_out = cur_vl;
    //--------------------------------------------------------------------------
    // 当前帧 SN 锁存：帧首拍从 vl_sn_out 取对应 VL 的 SN
    // (vl_sn_out 在帧发送期间保持本帧 SN，发完才递增，故帧首锁存即正确)
    //--------------------------------------------------------------------------
    always @ (posedge clk or posedge reset) begin
        if (reset)
        sn_cur <= 8'd0;
        else if (frame_start)
        sn_cur <= vl_sn_out[cur_vl * 8 +: 8];
    end
    //--------------------------------------------------------------------------
    // 输出握手：A、B 两路必须同时就绪才推进(严格同步复制)
    //   out_xfer 是本拍两路同时完成一次字节传输的唯一条件。每个通道的 valid
    //   必须用 out_xfer 门控：若只就绪一路而另一路未就绪，就绪那一路会因
    //   valid 持续为 1 而重复采样同一字节，造成 A/B 内容不一致。
    //--------------------------------------------------------------------------
    wire                 out_valid = (state != S_IDLE);
    wire                 both_ready = a_out_ready && b_out_ready;
    wire                 out_xfer = out_valid && both_ready;
    //--------------------------------------------------------------------------
    // 输出字节选择(组合)：SN 字段首字节为 SN 值，其余为保留 0x00；数据段直通
    //--------------------------------------------------------------------------
    reg  [7:0]           out_byte;
    always @ (*) begin
        case (state)
            S_SN : out_byte = (sn_cnt == 4'd0) ? sn_cur : 8'h00;
            S_DATA : out_byte = vl_tx_data;
            default : out_byte = 8'h00;
        endcase
    end
    assign a_out_data = out_byte;
    assign a_out_valid = out_xfer;
    assign b_out_data = out_byte;
    assign b_out_valid = out_xfer;
    //--------------------------------------------------------------------------
    // 反压回 vl_scheduler：仅在数据转发阶段、且 A/B 都就绪时才接收下一字节
    // (SN 输出阶段不消耗 vl_scheduler 的数据，故 vl_tx_ready 保持为 0)
    //--------------------------------------------------------------------------
    assign vl_tx_ready = (state == S_DATA) && both_ready;
    //--------------------------------------------------------------------------
    // 主状态机
    //--------------------------------------------------------------------------
    always @ (posedge clk or posedge reset) begin
        if (reset) begin
            state <= S_IDLE;
            sn_cnt <= 4'd0;
            stat_tx_frame_cnt <= 32'd0;
        end
        else begin
            case (state)
                //---- 帧间空闲：检测到新帧首则进入 SN 输出阶段 ----
                S_IDLE : begin
                    if (frame_start) begin
                        state <= S_SN;
                        sn_cnt <= 4'd0;
                    end
                end
                //---- 输出 SN 字段(SN_BYTES 字节) ----
                S_SN : begin
                    if (out_xfer) begin
                        if (sn_cnt == SN_LAST) begin
                            sn_cnt <= 4'd0;
                            state <= S_DATA;
                        end
                        else begin
                            sn_cnt <= sn_cnt + 4'd1;
                        end
                    end
                end
                //---- 转发业务数据：帧尾字节转发完成后回到空闲并计数 ----
                S_DATA : begin
                    if (out_xfer && vl_tx_last) begin
                        state <= S_IDLE;
                        stat_tx_frame_cnt <= stat_tx_frame_cnt + 32'd1;
                    end
                end
                default : state <= S_IDLE;
            endcase
        end
    end
endmodule
