//==============================================================================
// 文件名   : bag_regulator.v
// 所属层次 : rtl/tx_core —— 虚拟链路 BAG 调节器(发送调度)
// 功能描述 : 依据 ARINC 664 P7 的 BAG(Bandwidth Allocation Gap)规则，对每条 VL 的
//            发送做节流：同一条 VL 相邻两帧的发送起始时刻间隔不得小于它的 BAG。
//            BAG 取值 1/2/4/8/16/32/64/128 ms，由 SNMP-MIB 下发(vl_cfg_bag)。
//              本模块为每条 VL 维护一个 BAG 倒计时器：
//                · 复位后计时器为 0            → 第一条帧可以立即发送；
//                · 计时器不为 0 时每个时钟递减 → 减到 0 表示该 VL 可以再次发送；
//                · 授权发出后(vl_grant 单拍)   → 该 VL 计时器重新装载
//                  BAG(ms) × CYCLES_PER_MS 个时钟周期，从而限制最小发送间隔。
// 接口约定 : 1) vl_grant 是"授权发送一帧"的单拍脉冲，与 vl_scheduler 的约定一致；
//               仅在发送通道空闲(vl_tx_valid=0)且该 VL 满足
//               "有整帧待发(vl_has_data) + BAG 计时已到(vl_bag_ready)"时才给出，
//               因此不会出现"授权发出却没人接收"而被丢弃的情况。
//            2) vl_tx_valid 直接接 vl_scheduler 的 vl_tx_valid(同名直连)
//               (该信号为高表示有帧正在发送，即通道忙)，本模块据此判忙。
//            3) 同一时刻只授权一条 VL；多条 VL 同时满足条件时按轮询(round-robin)
//               选出一条，避免高编号 VL 长期得不到发送机会。
// 备注     : (1) 本模块不处理 SN / LMAX：SN 由 vl_scheduler 按帧递增，LMAX 由
//                vl_scheduler 用于超长帧丢弃，故这里不引入这些端口。
//            (2) CYCLES_PER_MS 必须按系统时钟填写 = CLK_FREQ/1000。AFDX_top 中
//                CLK_FREQ = 12_500_000 Hz(100Mbps 以太网字节时钟)，故默认 12500。
//                它是常数参数，综合时 BAG 装载退化为"常数乘法/移位"，不消耗乘法器。
//            (3) vl_cfg_bag = 0 表示"不限速"(未配置/调试用)，此时计时器恒为 0，
//                该 VL 每个时钟都可被授权；正常运行时 MIB 应下发合法 BAG(1~128ms)。
//            (4) 若以后改用全局 RTC(rtc_timestamp)统一计时，只需把 bag_cnt 的递减
//                与比较改成对 rtc_timestamp 的比较，模块端口保持不变。
//==============================================================================
`timescale 1ns / 1ns
module bag_regulator #(
    parameter                 VL_NUM        = 2,
    // 虚拟链路数量，和顶层保持一致
    parameter                 CYCLES_PER_MS = 12500,
    // 1ms 对应的时钟周期数 = CLK_FREQ/1000
    parameter                 BAG_CNT_W     = 32,
    // BAG 计时器位宽(需能容纳 最大BAG×CYCLES_PER_MS)
    // VL 号位宽：按 VL_NUM 自动推导(最多 16 条 VL)
    parameter                 VL_ID_W       = (VL_NUM <= 2) ? 1 : (VL_NUM <= 4) ? 2 :
    (VL_NUM <= 8) ? 3 : 4
) (
    // 端口命名与 vl_scheduler 对齐(同名直连)：vl_has_data / vl_tx_valid 来自
    // vl_scheduler，vl_grant 回给 vl_scheduler；便于在 afdx_tx_core 中直接对接。
    input  wire                     clk,
    // 时钟信号
    input  wire                     reset,
    // 复位信号(高电平复位)
    //---- 来自 SNMP-MIB 的 VL 配置 ----
    input  wire [32 * VL_NUM - 1:0] vl_cfg_bag,
    // 每条 VL 的 BAG 配置(单位 ms，0=不限速)
    //---- 来自 vl_scheduler 的发送请求 ----
    input  wire [VL_NUM - 1:0]      vl_has_data,
    // 每 bit 代表对应的 VL 是否有整帧待发
    input  wire                     vl_tx_valid,
    // 发送通道忙(接 vl_scheduler 的 vl_tx_valid，高=正在发送一帧)
    //---- 授权给 vl_scheduler ----
    output reg  [VL_NUM - 1:0]      vl_grant,
    // 授权某 VL 发送一帧(单拍脉冲)
    output wire [VL_ID_W - 1:0]     vl_grant_id,
    // 本拍被授权的 VL 号(与 vl_grant 同拍有效)
    //---- 状态指示(供波形观察 / 统计上报) ----
    output wire [VL_NUM - 1:0]      vl_bag_ready
    // 该 VL 的 BAG 计时已到(可以发送)
);
    //--------------------------------------------------------------------------
    // 每条 VL 一个 BAG 倒计时器
    //--------------------------------------------------------------------------
    reg     [BAG_CNT_W - 1:0] bag_cnt[0:VL_NUM - 1];
    // 剩余等待时钟数，0 表示"计时已到"
    integer                   i;
    // 通用循环变量
    genvar                    gi;
    // generate 变量
    generate
            for (gi = 0; gi < VL_NUM; gi = gi + 1) begin : g_bag_ready
            assign vl_bag_ready[gi] = (bag_cnt[gi] == {BAG_CNT_W {1'b0}});
        end
    endgenerate
    //--------------------------------------------------------------------------
    // 轮询指针：记录本次被授权的 VL，下一轮从它的下一条 VL 开始找
    //--------------------------------------------------------------------------
    reg     [VL_ID_W - 1:0]   arb_ptr;
    // 轮询起始位置
    reg     [VL_ID_W - 1:0]   grant_vl;
    // 本拍被选中的 VL 号
    integer                   idx;
    // 轮询过程中的 VL 号
    //--------------------------------------------------------------------------
    // 授权选择(组合逻辑)
    //   条件：发送通道空闲(vl_tx_valid=0) + 该 VL 有整帧待发 + 该 VL 的 BAG 计时已到；
    //   多条 VL 同时满足时从 arb_ptr 开始轮询，每拍只授权一条 VL。
    //   注：vl_grant 不寄存 —— 通道空闲时给出，vl_scheduler 在下一个时钟上升沿取走该
    //       授权并随即把 vl_tx_valid 拉高，因此本拍授权自然只维持一个时钟周期。
    //--------------------------------------------------------------------------
    always @ (*) begin
        vl_grant = {VL_NUM {1'b0}};
        grant_vl = {VL_ID_W {1'b0}};
        if (!vl_tx_valid) begin
            for (i = 0; i < VL_NUM; i = i + 1) begin
                idx = arb_ptr + i;
                // 从上次位置开始轮询
                if (idx >= VL_NUM) idx = idx - VL_NUM;
                // 回卷到 0
                if ((vl_grant == {VL_NUM {1'b0}}) &&
                    // 本拍还没有授权出去
                vl_has_data[idx] && vl_bag_ready[idx]) begin
                    vl_grant[idx] = 1'b1;
                    // 只授权一条 VL
                    grant_vl = idx[VL_ID_W - 1:0];
                end
            end
        end
    end
    assign vl_grant_id = grant_vl;
    // 与 vl_grant 同拍输出被授权的 VL 号
    //--------------------------------------------------------------------------
    // BAG 计时器与轮询指针更新
    //--------------------------------------------------------------------------
    always @ (posedge clk or posedge reset) begin
        if (reset) begin
            arb_ptr <= {VL_ID_W {1'b0}};
            for (i = 0; i < VL_NUM; i = i + 1) begin
                bag_cnt[i] <= {BAG_CNT_W {1'b0}};
                // 复位后计时为 0 → 第一条帧可立即发送
            end
        end
        else begin
            for (i = 0; i < VL_NUM; i = i + 1) begin
                if (vl_grant[i]) begin
                    //---- 本 VL 刚被授权发一帧：装载 BAG 间隔(ms × CYCLES_PER_MS) ----
                    bag_cnt[i] <= vl_cfg_bag[i * 32 +: 32] * CYCLES_PER_MS;
                end
                else if (bag_cnt[i] != {BAG_CNT_W {1'b0}}) begin
                    //---- BAG 倒计时；减到 0 后保持 0，表示该 VL 可以再次发送 ----
                    bag_cnt[i] <= bag_cnt[i] - 1'b1;
                end
            end
            //---- 轮询指针移到本次授权 VL 的下一条 ----
            if (vl_grant != {VL_NUM {1'b0}}) begin
                arb_ptr <= grant_vl + 1'b1;
                // 位宽截断即自动回卷
            end
        end
    end
endmodule
