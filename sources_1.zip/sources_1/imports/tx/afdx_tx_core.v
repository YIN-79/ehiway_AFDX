`timescale 1ns/1ns
// Complete business frames, one storage slot per VL. SN is metadata, not UDP data.
module afdx_tx_core #(
    parameter                 VL_NUM        = 2,
    FRAME_LEN = 62,
    FIFO_DEPTH = 1471,
    SN_BYTES = 0,
    parameter                 CYCLES_PER_MS = 12500,
    EXPLICIT_FRAMES = 0,
    parameter TIMED_TX=0,
    parameter USE_START_FEEDBACK=0,
    parameter COMPENSATE_LATENCY=0, FRAGMENT_ENABLE=0
) (
    input  wire                     clk,
    input  wire                     reset,
    input  wire [7:0]               payload_in_data,
    input  wire                     payload_in_valid,
    output wire                     payload_in_ready,
    input  wire                     payload_in_sop,
    input  wire                     payload_in_eop,
    input  wire [15:0]              payload_in_vlid,
    input  wire [15:0]              payload_in_length,
    input  wire [32 * VL_NUM - 1:0] vl_cfg_bag,
    input  wire [32 * VL_NUM - 1:0] vl_cfg_lmax,
    input  wire [31:0]              rtc_timestamp,
    output wire [7:0]               a_out_data,
    output wire [7:0]               b_out_data,
    output wire                     a_out_valid,
    output wire                     b_out_valid,
    input  wire                     a_out_ready,
    input  wire                     b_out_ready,
    output wire                     out_sop,
    output wire                     out_eop,
    output wire [15:0]              out_length,
    output wire [15:0]              tx_vl_id_out,
    output wire [7:0]               out_sn,
    output reg  [31:0]              stat_tx_frame_cnt,
    output reg  [31:0]              stat_drop_oversize,
    output reg  [31:0]              stat_bad_descriptor,
    input wire [VL_NUM-1:0] sched_enable,
    input wire [32*VL_NUM-1:0] sched_period,sched_phase,
    output wire out_launch_valid,
    output wire [31:0] out_launch_tick,
    input wire a_tx_start,b_tx_start,
    input wire [15:0] a_tx_start_vlid,b_tx_start_vlid,
    output reg [31:0] stat_schedule_late,
    input wire payload_header_valid,
    input wire [15:0] payload_src_port,payload_dst_port,
    input wire [31:0] payload_src_ip,payload_dst_ip,
    output wire [15:0] out_src_port,out_dst_port,
    output wire [31:0] out_src_ip,out_dst_ip,
    input wire payload_fragment,output wire out_fragment,
    output wire [31:0] scheduler_tick
);
    localparam                MAX_PAYLOAD   = 1471;
    localparam VL_AW = VL_NUM < 2 ? 1 : $clog2(VL_NUM);
    // Every legal payload is <=1471 bytes. Keep one alignment byte per VL,
    // without allocating the unused remainder of a 2048-byte power-of-two slot.
    localparam PAYLOAD_STRIDE=1472;
    localparam PAYLOAD_AW=$clog2(VL_NUM*PAYLOAD_STRIDE);
    (* ramstyle = "M4K, no_rw_check" *) reg [7:0] mem[0:VL_NUM*PAYLOAD_STRIDE-1];
    function [PAYLOAD_AW-1:0] payload_storage_address;
        input [VL_AW-1:0] vl;
        input [10:0] byte_offset;
        reg [PAYLOAD_AW-7:0] vl_units,units;
        begin
            vl_units=vl;
            units=(vl_units<<4)+(vl_units<<3)-vl_units+byte_offset[10:6];
            payload_storage_address={units,byte_offset[5:0]};
        end
    endfunction
    reg [7:0] payload_q;
    (* ramstyle = "M4K, no_rw_check" *) reg [96:0] udp_headers[0:VL_NUM-1];
    reg [96:0] udp_header_q;
    assign {out_fragment,out_src_port,out_dst_port,out_src_ip,out_dst_ip}=udp_header_q;
    reg     [15:0]         length[0:VL_NUM - 1];
    reg     [7:0]          sn[0:VL_NUM - 1];
    reg     [31:0]         timer[0:VL_NUM - 1];
    reg     [VL_NUM - 1:0] queued;
    reg                    collecting, bad_input, busy, sent_a, sent_b;
    reg     [15:0]         write_vl, legacy_vl, write_count, declared_length, read_vl, read_count;
    reg [VL_AW-1:0] arb;
    reg [31:0] local_tick,next_due[0:VL_NUM-1];
    // Independent of RTC wall-clock correction; one tick per byte clock.
    assign scheduler_tick=local_tick;
    reg [VL_NUM-1:0] schedule_armed,await_a_start,await_b_start;
    reg launch_timed;
    reg [31:0] launch_tick;
    reg preparing;
    reg [31:0] arb_epoch,selected_epoch,selected_tick,selected_timer;
    reg [10:0] selected_distance;
    reg [15:0] selected_length;
    assign out_launch_valid=launch_timed;
    assign out_launch_tick=launch_tick;
    // Equalize wire serialization + receive payload drain, without adding bytes
    // to the Ethernet/IP/UDP frame. 2997 = 1518 frame + 8 preamble + 1471 data.
    // Short frames are sent later; a reserved calendar prevents cross-VL stalls.
    function [31:0] completion_offset;
        input [15:0] bytes;
        reg [31:0] frame_bytes;
        begin
            frame_bytes=bytes<17?32'd64:bytes+32'd47;
            if(COMPENSATE_LATENCY && bytes>=1 && bytes<=MAX_PAYLOAD)
                completion_offset=32'd2997-(frame_bytes+32'd8+bytes);
            else completion_offset=0;
        end
    endfunction
    integer                i, choice;
    wire    [15:0]         first_vl = EXPLICIT_FRAMES ? payload_in_vlid : legacy_vl;
    wire    [15:0]         incoming_vl = collecting ? write_vl : first_vl;
    wire                   finish_input = EXPLICIT_FRAMES ? payload_in_eop : (write_count == FRAME_LEN - 1);
    wire    [31:0]         max_cfg = (incoming_vl < VL_NUM) ? vl_cfg_lmax[incoming_vl * 32 +: 32] : 0;
    wire    [15:0]         new_length = write_count + 16'd1;
    wire raw_fragment=FRAGMENT_ENABLE && payload_fragment;
    wire [15:0] frame_length=raw_fragment?(new_length<25?16'd64:new_length+16'd39):((new_length<17)?16'd64:new_length+16'd47);
        assign payload_in_ready = !reset && (collecting || (first_vl >= VL_NUM) ||
    (!queued[first_vl] && !(busy && read_vl == first_vl)));
    assign a_out_data = payload_q;
    assign b_out_data = a_out_data;
    assign a_out_valid = !reset && busy && !preparing && !sent_a;
    assign b_out_valid = !reset && busy && !preparing && !sent_b;
    assign out_sop = (read_count == 0);
    assign out_eop = (read_count + 1 == length[read_vl]);
    assign out_length = length[read_vl];
    assign tx_vl_id_out = read_vl;
    assign out_sn = sn[read_vl];
    wire                   ack_a = sent_a || (a_out_valid && a_out_ready);
    wire                   ack_b = sent_b || (b_out_valid && b_out_ready);
    // The existing preparing clock fetches byte zero after read_vl is
    // registered. Keep the tournament out of the compact address arithmetic.
    wire [VL_AW-1:0] ram_read_vl = read_vl[VL_AW-1:0];
    wire [10:0] ram_read_count = !busy ? 11'd0 :
        read_count[10:0] + ((ack_a && ack_b && !out_eop) ? 11'd1 : 11'd0);
    always @(posedge clk) begin
        if(!reset && payload_in_valid && payload_in_ready && incoming_vl<VL_NUM && write_count<MAX_PAYLOAD)
            mem[payload_storage_address(incoming_vl[VL_AW-1:0],write_count[10:0])] <= payload_in_data;
        payload_q <= mem[payload_storage_address(ram_read_vl,ram_read_count)];
        if(ram_read_vl<VL_NUM)udp_header_q<=udp_headers[ram_read_vl];
        if(!reset && payload_in_valid && payload_in_ready && !collecting && first_vl<VL_NUM)begin
            if(payload_header_valid)udp_headers[first_vl]<={raw_fragment,payload_src_port,payload_dst_port,payload_src_ip,payload_dst_ip};
            else udp_headers[first_vl]<={1'b0,16'h0bb8,16'h0bba,32'h0a000001,32'h0a000002};
        end
    end
    // Read each VL at a fixed index. Rotating a variable array index inside
    // a VL_NUM-iteration scan creates VL_NUM separate VL_NUM-to-one muxes.
    // A balanced tournament keeps the comparison depth logarithmic instead.
    localparam ARB_LEAVES=1<<VL_AW;
    // Leaves are in ascending VL order. Equal keys always choose the left
    // subtree, so the VL ID need not also pass through every key comparator.
    localparam ARB_KEY_W=13;
    wire [2*ARB_LEAVES-1:0] arb_valid;
    wire [ARB_KEY_W-1:0] arb_key[0:2*ARB_LEAVES-1];
    wire [VL_AW-1:0] arb_id[0:2*ARB_LEAVES-1];
    genvar ag;
    generate for(ag=0;ag<ARB_LEAVES;ag=ag+1)begin:g_arb_leaf
        localparam [VL_AW-1:0] ID=ag;
        if(ag<VL_NUM)begin:g_present
            wire timed=TIMED_TX && sched_enable[ag];
            wire [31:0] distance=next_due[ag]+completion_offset(length[ag])-local_tick;
            wire frame_ready=queued[ag] && length[ag]!=0 &&
                (!USE_START_FEEDBACK || (!await_a_start[ag] && !await_b_start[ag]));
            wire timed_ready=schedule_armed[ag] && sched_period[ag*32+:32]!=0 &&
                !distance[31] && distance<=length[ag]+32'd8;
            reg sampled_valid;
            reg [ARB_KEY_W-1:0] sampled_key;
            always @(posedge clk or posedge reset)begin
                if(reset)begin sampled_valid<=0;sampled_key<=0;end
                else begin
                    sampled_valid<=frame_ready && (timed?timed_ready:timer[ag]<=length[ag]);
                    sampled_key<={!timed,(timed?distance[10:0]:11'd0),(ID<arb)};
                end
            end
            // Recheck live frame ownership: a just-consumed frame must never
            // be chosen from a stale sample. Mode changes invalidate the sample.
            assign arb_valid[ARB_LEAVES+ag]=sampled_valid && frame_ready &&
                (timed==!sampled_key[ARB_KEY_W-1]) &&
                (!timed || sched_period[ag*32+:32]!=0);
            // Eligible distances are <=1471+8, so eleven key bits suffice.
            // Scheduled frames precede ordinary traffic; ties use round robin.
            assign arb_key[ARB_LEAVES+ag]=sampled_key;
        end else begin:g_absent
            assign arb_valid[ARB_LEAVES+ag]=0;
            assign arb_key[ARB_LEAVES+ag]=0;
        end
        assign arb_id[ARB_LEAVES+ag]=ID;
    end
    for(ag=1;ag<ARB_LEAVES;ag=ag+1)begin:g_arb_node
        wire left_wins=arb_valid[2*ag] && (!arb_valid[2*ag+1] || arb_key[2*ag]<=arb_key[2*ag+1]);
        assign arb_valid[ag]=arb_valid[2*ag] || arb_valid[2*ag+1];
        assign arb_key[ag]=left_wins?arb_key[2*ag]:arb_key[2*ag+1];
        assign arb_id[ag]=left_wins?arb_id[2*ag]:arb_id[2*ag+1];
    end endgenerate
    assign arb_valid[0]=0;
    assign arb_key[0]=0;
    assign arb_id[0]=0;
    always @(*)begin
        if(arb_valid[1])choice=arb_id[1];else choice=-1;
    end
    always @ (posedge clk or posedge reset) begin
        if (reset) begin
            local_tick<=0;schedule_armed<=0;await_a_start<=0;await_b_start<=0;
            launch_timed<=0;launch_tick<=0;stat_schedule_late<=0;
            preparing<=0;arb_epoch<=0;selected_epoch<=0;selected_distance<=0;
            selected_tick<=0;selected_timer<=0;selected_length<=0;
            collecting <= 0;
            bad_input <= 0;
            busy <= 0;
            sent_a <= 0;
            sent_b <= 0;
            queued <= 0;
            write_vl <= 0;
            legacy_vl <= 0;
            write_count <= 0;
            declared_length <= 0;
            read_vl <= 0;
            read_count <= 0;
            arb <= 0;
            stat_tx_frame_cnt <= 0;
            stat_drop_oversize <= 0;
            stat_bad_descriptor <= 0;
            for (i = 0; i < VL_NUM; i = i + 1) begin
                length[i] <= 0;
                // Strict 1..255 sequence space, including the first frame.
                sn[i] <= 8'd1;
                timer[i] <= 0;
                next_due[i]<=0;
            end
        end else begin
            local_tick<=local_tick+1'b1;arb_epoch<=local_tick;
            for(i=0;i<VL_NUM;i=i+1)begin
                if(timer[i]!=0)timer[i]<=timer[i]-1'b1;
                if(TIMED_TX && sched_enable[i] && sched_period[i*32+:32]!=0)begin
                    if(!schedule_armed[i])begin next_due[i]<=sched_phase[i*32+:32];schedule_armed[i]<=1;end
                    else if($signed(local_tick-(next_due[i]+completion_offset(length[i])))>=0)
                        next_due[i]<=next_due[i]+sched_period[i*32+:32];
                end else schedule_armed[i]<=0;
            end
            if(USE_START_FEEDBACK)begin
                if(a_tx_start && a_tx_start_vlid<VL_NUM)begin
                    // Start feedback is observed two clocks after the release edge;
                    // compensate this fixed pipeline delay in the release-time timer.
                    timer[a_tx_start_vlid]<=vl_cfg_bag[a_tx_start_vlid*32+:32]*CYCLES_PER_MS-3;
                    await_a_start[a_tx_start_vlid]<=0;
                end
                if(b_tx_start && b_tx_start_vlid<VL_NUM)begin
                    timer[b_tx_start_vlid]<=vl_cfg_bag[b_tx_start_vlid*32+:32]*CYCLES_PER_MS-3;
                    await_b_start[b_tx_start_vlid]<=0;
                end
            end
            if (payload_in_valid && payload_in_ready) begin
                if (!collecting) begin
                    write_vl <= first_vl;
                    declared_length <= EXPLICIT_FRAMES ? payload_in_length : FRAME_LEN;
                    bad_input <= EXPLICIT_FRAMES && (!payload_in_sop || payload_in_length < 1 || payload_in_length > MAX_PAYLOAD);
                end else if (EXPLICIT_FRAMES && payload_in_sop) bad_input <= 1;

                if (finish_input) begin
                    collecting <= 0;
                    write_count <= 0;
                    bad_input <= 0;
                    if (incoming_vl >= VL_NUM || bad_input || (EXPLICIT_FRAMES &&
                        ((!collecting && (!payload_in_sop || payload_in_length != new_length)) ||
                    (collecting && (declared_length != new_length || payload_in_sop)))))
                    stat_bad_descriptor <= stat_bad_descriptor + 1'b1;
                    else if (new_length > MAX_PAYLOAD || (max_cfg != 0 && frame_length > max_cfg))
                    stat_drop_oversize <= stat_drop_oversize + 1'b1;
                    else begin
                        length[incoming_vl] <= new_length;
                        queued[incoming_vl] <= 1;
                    end
                    if (!EXPLICIT_FRAMES) legacy_vl <= (legacy_vl == VL_NUM - 1) ? 0 : legacy_vl + 1'b1;
                end else begin
                    collecting <= 1;
                    if (write_count < 16'hffff) write_count <= write_count + 1'b1;
                    else bad_input <= 1;
                end
            end
            // Present the selected frame independently of ready. The MAC may accept
            // the next payload while transmitting, but holds its final byte until idle.
            if (!busy && choice >= 0) begin
                busy <= 1;
                preparing<=1;
                read_vl <= choice;
                launch_timed<=TIMED_TX && sched_enable[choice];
                // Separate tournament/index selection from launch arithmetic.
                // Capture this epoch so 32-bit wrap and BAG release semantics
                // remain the same despite the additional preparation clock.
                selected_epoch<=arb_epoch;selected_distance<=arb_key[1][11:1];
                selected_length<=length[choice];
                selected_tick<=local_tick;selected_timer<=timer[choice];
                read_count <= 0;
                sent_a <= 0;
                sent_b <= 0;
                arb <= (choice == VL_NUM - 1) ? 0 : choice + 1;
            end else if(preparing)begin
                preparing<=0;
                if(launch_timed)begin
                    if($signed((selected_epoch+{21'd0,selected_distance})-(selected_tick+selected_timer))>=0)
                        launch_tick<=selected_epoch+{21'd0,selected_distance};
                    else launch_tick<=selected_tick+selected_timer;
                end else launch_tick<=0;
            end else if (busy) begin
                if (ack_a && ack_b) begin
                    sent_a <= 0;
                    sent_b <= 0;
                    if (out_eop) begin
                        busy <= 0;
                        queued[read_vl] <= 0;
                        stat_tx_frame_cnt <= stat_tx_frame_cnt + 1'b1;
                        sn[read_vl] <= (sn[read_vl] == 255) ? 8'd1 : sn[read_vl] + 1'b1;
                        // MAC begins preamble next clock. Cooldown is anchored at complete A/B capture.
                        // Lookahead only overlaps the next copy with cooldown; it never shortens BAG.
                        if(USE_START_FEEDBACK)begin await_a_start[read_vl]<=1;await_b_start[read_vl]<=1;end
                        else timer[read_vl] <= vl_cfg_bag[read_vl * 32 +: 32] * CYCLES_PER_MS;
                        if(launch_timed && $signed(local_tick-launch_tick)>=0)stat_schedule_late<=stat_schedule_late+1'b1;
                    end else read_count <= read_count + 1'b1;
                end else begin
                    sent_a <= ack_a;
                    sent_b <= ack_b;
                end
            end
        end
    end
endmodule
