//==============================================================================
// 文件名   : host_if_top.v
// 所属层次 : rtl/host_if —— 615A 主机加载卸载接口顶层(AFDX 端系统 <-> 主机)
// 模块名说明: 文件名按规划为 host_if_top.v，但**模块名必须保持 afdx_615a_if**：
//            rtl/AFDX_top.v 第 115 行已按 `afdx_615a_if u_afdx_615a_if(...)`
//            例化，而顶层文件不可改动。Verilog 不要求文件名与模块名一致，
//            仿真(work.afdx_615a_if)与综合均按模块名解析。
// 功能描述 : AFDX 端系统对外的"主机加载/卸载接口"。端口与 AFDX_top.v 中
//            u_afdx_615a_if 的例化逐位一致，内部由两条相互独立的单向通路组成：
//              加载(load)  ：host_load_* -> data_buffer(缓存) -> load_ctrl_fsm
//                            (定长分帧) -> tx_payload_*
//              卸载(unload)：rx_payload_* -> data_buffer(缓存) -> host_unload_*
//            两条通路各用一个 data_buffer 吸收主机总线与 AFDX 载荷流之间的速率
//            差异，配合 valid-ready 反压保证"不丢字节、不重复、不乱序"。
// 结构分工 : load_ctrl_fsm.v —— 加载控制状态机(含主机侧握手与观测计数)；
//            data_buffer.v   —— 8bit FWFT 同步缓存，加载/卸载两个方向共用；
//            host_if_top.v   —— 例化与连线。
//            卸载方向没有状态机(纯握手直连：缓存满就反压、非空就交付)，
//            因此其握手逻辑与观测计数直接写在顶层，不再单独设模块。
// 加载分帧 : 顶层没有 sop/eop 帧边界端口，AFDX 发送核心按固定长度分帧，因此
//            load_ctrl_fsm 按 CFG_FRAME_LEN 分帧输出，并强制帧与帧之间
//            tx_payload_valid 至少拉低 1 拍(帧边界在波形上可见)；
//            CFG_FRAME_LEN 应与 udp_ip_wrapper 的 CFG_PAYLOAD_LEN 配套：
//                CFG_FRAME_LEN(业务数据) + 2 字节 SN = CFG_PAYLOAD_LEN。
// 卸载形式 : 接收核心输出的业务载荷没有帧边界信息，卸载通路按字节流透明转发，
//            不解析也不修改数据内容。
// 关于 615A: 顶层端口只有 8bit 数据 + valid/ready，没有操作码/长度/状态端口，
//            因此本模块实现的是 ARINC 615A 加载/卸载过程中的"数据搬运 + 流控"
//            部分；615A 报文层(操作码、块号、状态字、校验)的解析与组装属于
//            主机侧软件，或需要后续为顶层增加帧边界与命令总线后在本层扩展。
// 复位约定 : reset 高电平有效、异步复位；复位期间两侧均不握手，两个 data_buffer
//            的指针清零(缓存内容丢弃)。
//==============================================================================
`timescale 1ns / 1ns
module afdx_615a_if #(
    parameter          [15:0] CFG_FRAME_LEN     = 16'd62,
    // 加载方向每帧业务数据字节数
    parameter  integer        LOAD_FIFO_DEPTH   = 256,
    // 加载通路缓存深度(字节)
    parameter  integer        UNLOAD_FIFO_DEPTH = 256,
    parameter FRAMED_UNLOAD = 0
    // 卸载通路缓存深度(字节)
) (
    input  wire       clk,
    // 时钟信号
    input  wire       reset,
    // 复位信号(高电平有效)
    //---- 主机侧：加载(主机 -> 端系统) ----
    input  wire [7:0] host_load_data,
    // 主机数据
    input  wire       host_load_valid,
    // 主机数据有效
    output wire       host_load_ready,
    // 允许主机送数
    //---- 主机侧：卸载(端系统 -> 主机) ----
    output wire [7:0] host_unload_data,
    // 交付主机的数据
    output wire       host_unload_valid,
    // 交付主机的数据有效
    input  wire       host_unload_ready,
    // 主机可接收
    //---- 端系统侧：送往 AFDX_TX 核心的业务载荷 ----
    output wire [7:0] tx_payload_data,
    // 业务载荷数据
    output wire       tx_payload_valid,
    // 业务载荷数据有效
    input  wire       tx_payload_ready,
    // 发送核心允许接收
    //---- 端系统侧：来自 AFDX_RX 核心的业务载荷 ----
    input  wire [7:0] rx_payload_data,
    // 接收核心上交的载荷数据
    input  wire       rx_payload_valid,
    // 接收核心上交的数据有效
    output wire       rx_payload_ready,
    input wire rx_sop,rx_eop,
    input wire [15:0] rx_vlid,rx_length,rx_src_port,rx_dst_port,
    input wire [31:0] rx_src_ip,rx_dst_ip,
    output wire host_unload_sop,host_unload_eop,
    output wire [15:0] host_unload_vlid,host_unload_length,host_unload_src_port,host_unload_dst_port,
    output wire [31:0] host_unload_src_ip,host_unload_dst_ip
    // 允许接收核心送数
);
    //--------------------------------------------------------------------------
    // 加载方向：load_ctrl_fsm(控制状态机) + data_buffer(加载缓存)
    //--------------------------------------------------------------------------
    wire [7:0]  lbuf_rd_data;
    // 加载缓存队首数据
    wire        lbuf_full;
    // 加载缓存满
    wire        lbuf_empty;
    // 加载缓存空
    wire [7:0]  lbuf_wr_data;
    // 写入加载缓存的数据
    wire        lbuf_wr_en;
    // 加载缓存写使能
    wire        lbuf_rd_en;
    // 加载缓存读使能
        load_ctrl_fsm #(
        .CFG_FRAME_LEN(CFG_FRAME_LEN)
    ) u_load(
        .clk(clk),
        .reset(reset),
        .host_data(host_load_data),
        .host_valid(host_load_valid),
        .host_ready(host_load_ready),
        .buf_wr_data(lbuf_wr_data),
        .buf_wr_en(lbuf_wr_en),
        .buf_full(lbuf_full),
        .buf_rd_data(lbuf_rd_data),
        .buf_rd_en(lbuf_rd_en),
        .buf_empty(lbuf_empty),
        .tx_data(tx_payload_data),
        .tx_valid(tx_payload_valid),
        .tx_ready(tx_payload_ready)
    );
        data_buffer #(
        .DEPTH(LOAD_FIFO_DEPTH)
    ) u_load_buf(
        .clk(clk),
        .reset(reset),
        .wr_data(lbuf_wr_data),
        .wr_en(lbuf_wr_en),
        .full(lbuf_full),
        .rd_data(lbuf_rd_data),
        .rd_en(lbuf_rd_en),
        .empty(lbuf_empty)
    );
    //--------------------------------------------------------------------------
    // 卸载方向：data_buffer(卸载缓存) + 顶层握手(无状态机)
    //--------------------------------------------------------------------------
    wire [7:0]  ubuf_rd_data;
    // 卸载缓存队首数据
    wire        ubuf_full;
    // 卸载缓存满
    wire        ubuf_empty;
    // 卸载缓存空
    wire        urx_xfer = rx_payload_valid && rx_payload_ready;
    // 接收核心侧握手
    wire        uhost_xfer = host_unload_valid && host_unload_ready;
    // 主机侧握手
    generate if(!FRAMED_UNLOAD)begin:g_unframed
    assign host_unload_sop=0;assign host_unload_eop=0;
    assign host_unload_vlid=0;assign host_unload_length=0;
    assign host_unload_src_port=0;assign host_unload_dst_port=0;
    assign host_unload_src_ip=0;assign host_unload_dst_ip=0;
    assign rx_payload_ready = !reset && !ubuf_full;
    // 复位或缓存满则反压
    assign host_unload_valid = !reset && !ubuf_empty;
    // 有数据才交付
    assign host_unload_data = ubuf_rd_data;
    // FWFT 直出
        data_buffer #(
        .DEPTH(UNLOAD_FIFO_DEPTH)
    ) u_unload_buf(
        .clk(clk),
        .reset(reset),
        .wr_data(rx_payload_data),
        .wr_en(urx_xfer),
        .full(ubuf_full),
        .rd_data(ubuf_rd_data),
        .rd_en(uhost_xfer),
        .empty(ubuf_empty)
    );

    end else begin:g_framed
        afdx_framed_unload #(.DEPTH(UNLOAD_FIFO_DEPTH)) u_unload(
            .clk(clk),.reset(reset),.s_data(rx_payload_data),.s_valid(rx_payload_valid),.s_ready(rx_payload_ready),
            .s_sop(rx_sop),.s_eop(rx_eop),.s_vlid(rx_vlid),.s_length(rx_length),
            .s_src_port(rx_src_port),.s_dst_port(rx_dst_port),.s_src_ip(rx_src_ip),.s_dst_ip(rx_dst_ip),
            .m_data(host_unload_data),.m_valid(host_unload_valid),.m_ready(host_unload_ready),
            .m_sop(host_unload_sop),.m_eop(host_unload_eop),.m_vlid(host_unload_vlid),.m_length(host_unload_length),
            .m_src_port(host_unload_src_port),.m_dst_port(host_unload_dst_port),.m_src_ip(host_unload_src_ip),.m_dst_ip(host_unload_dst_ip)
        );
    end endgenerate
    //--------------------------------------------------------------------------
    // 卸载方向统计(内部观测，供波形核对/文档锚点；不影响功能，不在端口上)
    //--------------------------------------------------------------------------
    reg  [31:0] stat_unload_in_bytes;
    // 从接收核心收到字节数
    reg  [31:0] stat_unload_out_bytes;
    // 交付主机字节数
    reg  [31:0] stat_unload_stall_beats;
    // rx_payload_valid=1 且 ready=0 的等待拍
    reg  [31:0] stat_unload_idle_beats;
    // host_unload_valid=0 的空闲拍
    always @ (posedge clk or posedge reset) begin
        if (reset) begin
            stat_unload_in_bytes <= 32'd0;
            stat_unload_out_bytes <= 32'd0;
            stat_unload_stall_beats <= 32'd0;
            stat_unload_idle_beats <= 32'd0;
        end
        else begin
            if (urx_xfer) stat_unload_in_bytes <= stat_unload_in_bytes + 32'd1;
            if (uhost_xfer) stat_unload_out_bytes <= stat_unload_out_bytes + 32'd1;
            if (rx_payload_valid && !rx_payload_ready)
            stat_unload_stall_beats <= stat_unload_stall_beats + 32'd1;
            if (!host_unload_valid)
            stat_unload_idle_beats <= stat_unload_idle_beats + 32'd1;
        end
    end
endmodule

// A byte FIFO and a separate per-frame descriptor FIFO retain packet boundaries.
module afdx_framed_unload #(parameter DEPTH=256)(
    input wire clk,reset,
    input wire [7:0] s_data,input wire s_valid,output wire s_ready,
    input wire s_sop,s_eop,input wire [15:0] s_vlid,s_length,s_src_port,s_dst_port,
    input wire [31:0] s_src_ip,s_dst_ip,
    output wire [7:0] m_data,output wire m_valid,input wire m_ready,
    output wire m_sop,m_eop,output wire [15:0] m_vlid,m_length,m_src_port,m_dst_port,
    output wire [31:0] m_src_ip,m_dst_ip
);
    wire byte_full,byte_empty,meta_full,meta_empty;
    wire [9:0] byte_head;
    wire [127:0] meta_head;
    wire push=s_valid && s_ready,pop=m_valid && m_ready;
    assign s_ready=!reset && !byte_full && (!s_sop || !meta_full);
    assign m_valid=!reset && !byte_empty && !meta_empty;
    assign {m_sop,m_eop,m_data}=byte_head;
    assign {m_vlid,m_length,m_src_port,m_dst_port,m_src_ip,m_dst_ip}=meta_head;
    data_buffer #(.DATA_W(10),.DEPTH(DEPTH)) bytes_fifo(
        .clk(clk),.reset(reset),.wr_data({s_sop,s_eop,s_data}),.wr_en(push),.full(byte_full),
        .rd_data(byte_head),.rd_en(pop),.empty(byte_empty));
    data_buffer #(.DATA_W(128),.DEPTH(32)) descriptors(
        .clk(clk),.reset(reset),.wr_data({s_vlid,s_length,s_src_port,s_dst_port,s_src_ip,s_dst_ip}),
        .wr_en(push && s_sop),.full(meta_full),.rd_data(meta_head),.rd_en(pop && m_eop),.empty(meta_empty));
endmodule
