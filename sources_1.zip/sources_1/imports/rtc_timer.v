`timescale 1ns / 1ns
//==============================================================================
// 文件名   : rtc_timer.v
// 所属层次 : rtl/afdx —— AFDX 端系统全局时间基准(RTC)
// 功能描述 : 产生端系统全局 32bit 时间戳，供
//              (1) afdx_rx_core 做冗余偏斜窗口(SkewMax)判定
//              (2) 顶层 rtc_timestamp 输出，作为报文时间标记供外部读取
//
// 端口说明 : sync_valid/sync_ts_in 写绝对时间；pps_in 经两级同步后校正相位。
//            monotonic_ts_out 独立计时，外部校时不影响接收冗余窗口。
//
// 时间单位 : 每个 tick 代表的物理时间由参数 TICK_NS 决定，默认 1_000_000 ns
//            即 1ms/tick。32bit 计数器在 1ms/tick 下约 49.7 天回绕一次，
//            远大于任何单帧的 SkewMax 判定窗口，回绕对功能无影响。
//
// ★ 关键约束 : TICK_NS 必须与 afdx_rx_core 的 RTC_UNIT_NS 保持一致！
//    rx_core 内部用 RTC_UNIT_NS 把 SKEW_MAX_MS 换算成 tick 数后与时间戳做差。
//    若两边单位不一致(例如这里 1us/tick、那边按 1ms/tick 算)，SkewMax 窗口
//    会被放大或缩小 1000 倍，冗余去重将判错。
//    改单位时两处必须同时改：本文件 TICK_NS 与 rx_core 的 RTC_UNIT_NS。
//
// 实现说明 : 分频系数 = CLK_FREQ / (1_000_000_000 / TICK_NS)
//    —— 刻意先算"每秒 tick 数"再除，而不是算 CLK_FREQ * TICK_NS。
//      后者在 100MHz/1ms 下为 1e14，超出 32bit integer 范围会溢出。
//    —— 要求 CLK_FREQ 能被每秒 tick 数整除(100MHz + 1ms/tick -> 100000，整除)。
//      若不能整除则取整，实际 tick 略快，需在选型时确认。
//==============================================================================
module rtc_timer #(
    parameter CLK_FREQ=100_000_000,
    parameter TICK_NS=1_000_000
)(
    input wire clk,reset,
    output reg [31:0] rtc_ts_out,
    input wire sync_valid,
    input wire [31:0] sync_ts_in,
    input wire pps_in,
    output reg [31:0] monotonic_ts_out,
    output reg sync_locked,
    output reg [31:0] sync_count
);
    localparam TICKS_PER_SEC=1_000_000_000/TICK_NS;
    localparam DIV_RAW=CLK_FREQ/TICKS_PER_SEC;
    localparam DIV=DIV_RAW<1?1:DIV_RAW;
    localparam DW=DIV<2?1:$clog2(DIV);
    localparam LOCK_TIMEOUT=CLK_FREQ*2;
    reg [DW-1:0] div_cnt,mono_div_cnt;
    (* async_reg = "true" *) reg pps_meta,pps_sync;
    reg pps_last;
    reg [31:0] lock_age;
    wire pps_edge=pps_sync && !pps_last;
    always @(posedge clk or posedge reset)begin
        if(reset)begin pps_meta<=0;pps_sync<=0;pps_last<=0;end
        else begin pps_meta<=pps_in;pps_sync<=pps_meta;pps_last<=pps_sync;end
    end
    // Wall clock can be synchronized; integrity/skew logic uses the independent
    // monotonic clock so an external time correction cannot poison RM windows.
    always @(posedge clk or posedge reset)begin
        if(reset)begin
            div_cnt<=0;mono_div_cnt<=0;rtc_ts_out<=0;monotonic_ts_out<=0;
            sync_locked<=0;sync_count<=0;lock_age<=0;
        end else begin
            if(mono_div_cnt==DIV-1)begin mono_div_cnt<=0;monotonic_ts_out<=monotonic_ts_out+1'b1;end
            else mono_div_cnt<=mono_div_cnt+1'b1;
            if(div_cnt==DIV-1)begin div_cnt<=0;rtc_ts_out<=rtc_ts_out+1'b1;end
            else div_cnt<=div_cnt+1'b1;
            if(sync_valid)begin
                rtc_ts_out<=sync_ts_in;div_cnt<=0;
                sync_locked<=1;sync_count<=sync_count+1'b1;lock_age<=0;
            end else if(pps_edge)begin
                // PPS supplies phase only. Absolute time is supplied by sync_ts_in.
                div_cnt<=0;sync_locked<=1;lock_age<=0;
            end else if(lock_age<LOCK_TIMEOUT)lock_age<=lock_age+1'b1;
            else sync_locked<=0;
        end
    end
endmodule
