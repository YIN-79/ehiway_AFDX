`timescale 1ns/1ns
// =============================================================================
// 文件：AFDX_top.v
// 功能：连接主机接口、发送核心、A/B 双通道 MAC、接收核心、MIB 和 RTC。
//
// 一、协议及功能缩写：英文原词 / 中文含义
// AFDX  : Avionics Full-Duplex Switched Ethernet / 航空电子全双工交换式以太网
// MAC   : Media Access Control                 / 媒体访问控制
// PHY   : Physical Layer                       / 物理层
// IP    : Internet Protocol                    / 网际协议
// UDP   : User Datagram Protocol               / 用户数据报协议
// SNMP  : Simple Network Management Protocol   / 简单网络管理协议
// MIB   : Management Information Base           / 管理信息库
// RTC   : Real-Time Clock                      / 实时时钟
// CRC   : Cyclic Redundancy Check               / 循环冗余校验
// FCS   : Frame Check Sequence                  / 帧校验序列
// VL    : Virtual Link                         / 虚拟链路
// VLID  : Virtual Link Identifier              / 虚拟链路标识符
// SN    : Sequence Number                      / 序列号
// BAG   : Bandwidth Allocation Gap             / 带宽分配间隔
// LMAX  : Maximum Frame Length（本工程命名）    / 每条 VL 的最大允许帧长
// SOP   : Start of Packet                      / 帧起始标志
// EOP   : End of Packet                        / 帧结束标志
// 615A  : ARINC 615A 标准编号，不是英文缩写；涉及航空数据加载协议。
//         当前 afdx_615a_if 完成主机数据搬运和流控，尚非完整 615A 会话。
//
// 二、端口及参数中的英文简写
// TX / RX       : Transmit / Receive           / 发送 / 接收
// CLK / FREQ    : Clock / Frequency            / 时钟 / 频率
// CFG / NUM     : Configuration / Number      / 配置 / 数量
// LEN / ADDR    : Length / Address             / 长度 / 地址
// WR / RD / EN  : Write / Read / Enable        / 写 / 读 / 使能
// MS            : Millisecond                 / 毫秒
// host          : Host                        / 主机
// payload       : Payload                     / 业务载荷
// valid / ready : Valid / Ready               / 数据有效 / 允许接收
// load / unload : Load / Unload               / 加载 / 卸载
// skew          : Skew                        / A/B 冗余副本的到达时间偏差
// legacy        : Legacy                      / 原有定长字节流兼容模式
// slots         : Slots                       / 完整接收帧的缓存槽位
//
// 三、内部短信号名（项目简写，并非协议标准名称）
// ta / tb       : TX channel A/B data          / 发送核心送往 A/B MAC 的业务字节
// tav / tbv     : TX A/B valid                 / A/B 发送数据有效
// tar / tbr     : TX A/B ready                 / A/B MAC 允许接收业务字节
// tsop / teop   : TX SOP/EOP                   / 发送业务帧起始 / 结束
// tlen / tvl    : TX length / VL               / 发送业务长度 / 虚拟链路标识
// tsn           : TX sequence number           / 发送序列号
// ra / rb       : RX channel A/B data          / A/B MAC 送往接收核心的业务字节
// rav / rbv     : RX A/B valid                 / A/B 接收数据有效
// rar / rbr     : RX A/B ready                 / 接收核心允许接收 A/B 业务字节
// rasop / rbsop : RX A/B SOP                   / A/B 接收业务帧起始
// raeop / rbeop : RX A/B EOP                   / A/B 接收业务帧结束
// ralen / rblen : RX A/B payload length        / A/B 接收业务载荷长度
// raflen/rbflen : RX A/B frame length          / A/B 完整帧长度（含 FCS）
// ravl / rbvl   : RX A/B VL                    / A/B 接收虚拟链路标识
// asn / bsn     : A/B sequence number          / A/B 接收序列号
// acrc / bcrc   : A/B CRC error                / A/B CRC 错误诊断脉冲
// aproto/bproto : A/B protocol error           / A/B 协议格式错误诊断脉冲
// aoverflow / boverflow : A/B overflow error   / A/B 接收缓存溢出诊断脉冲
// bags / lmax   : Per-VL BAG / LMAX table      / 各 VL 的间隔 / 帧长配置表
// unused_*      : Unused output metadata       / 已连接但未向主机导出的帧描述信息
//
// 四、工作模式和接口约定
// HOST_FRAMED=0：主机按固定 FRAME_LEN 字节分帧，发送 VL 轮询选择。
// HOST_FRAMED=1：首字节握手锁存 SOP、VLID、length，末字节用 EOP 标记。
// 内部业务流以 valid && ready 为真实传输条件，允许帧内停顿和反压。
// 物理侧为 8 位字节流；默认 CLK_FREQ=12.5 MHz，对应 100 Mbps。
// tx_a_ready / tx_b_ready 表示发送端口缓存空闲，不是外部输入握手信号。
// rx_a_ready / rx_b_ready 为保留兼容输入；物理 RX 不通过它们暂停来帧。
// MAC 接收缓存满时整帧丢弃；内部 ready 用于调节缓存后的业务数据传输。
// RTC 支持绝对时间写入和PPS相位同步；独立单调计时用于冗余检查。
// =============================================================================
module AFDX_top #(
    // 规模与时序参数：VL 数量、冗余最大偏斜（ms）、字节时钟频率（Hz）。
    parameter                 VL_NUM      = 2,
    // 发送与接收VL数量可独立配置，未覆盖时沿用VL_NUM。
    parameter                 TX_VL_NUM   = VL_NUM,
    parameter                 RX_VL_NUM   = VL_NUM,
    parameter                 SKEW_MAX_MS = 5,
    parameter                 CLK_FREQ    = 12_500_000,
    // 主机分帧及缓存参数：定长/显式帧、定长字节数、每路接收帧槽数。
    parameter                 HOST_FRAMED = 0,
    parameter                 FRAME_LEN   = 62,
    parameter                 RX_SLOTS    = 4,
    parameter RX_LENGTH_EQUALIZE = 0,
    parameter TIMED_TX = 0,
    parameter COMPENSATE_LATENCY = 0,
    parameter ENABLE_HW_SNMP = 0,
    parameter ENABLE_HW_615A = 1,
    parameter DOWNLOAD_MAX_FILES=4, DOWNLOAD_FILE_BYTES=4096,
    parameter DOWNLOAD_TIMEOUT_MS=1000,
    parameter DOWNLOAD_DALLY_SLOTS=4, DOWNLOAD_DALLY_MS=DOWNLOAD_TIMEOUT_MS*6,
    parameter MANAGEMENT_VL = TX_VL_NUM-1
) (
    // 全局控制：所有模块共用时钟，reset 高电平复位。
    input  wire        clk,
    input  wire        reset,

    // A/B 物理字节接口：data/valid 传输线上字节，TX ready 表示缓存空闲。
    output wire [7:0]  tx_a_data,
    input  wire [7:0]  rx_a_data,
    output wire        tx_a_valid,
    input  wire        rx_a_valid,
    output wire        tx_a_ready,
    input  wire        rx_a_ready,
    output wire [7:0]  tx_b_data,
    input  wire [7:0]  rx_b_data,
    output wire        tx_b_valid,
    input  wire        rx_b_valid,
    output wire        tx_b_ready,
    input  wire        rx_b_ready,
    // 主机加载/卸载业务流：valid && ready 时传输一个字节。
    input  wire [7:0]  host_load_data,
    input  wire        host_load_valid,
    output wire        host_load_ready,
    output wire [7:0]  host_unload_data,
    output wire        host_unload_valid,
    input  wire        host_unload_ready,
    // MIB 寄存器接口：按地址读配置及统计，wr_en 控制写入。
    input  wire [7:0]  mib_addr,
    input  wire        mib_wr_en,
    input  wire [31:0] mib_wr_data,
    output wire [31:0] mib_rd_data,
    // RTC 输出：32 位本地毫秒计数。
    output wire [31:0] rtc_timestamp,
    // 显式帧描述：SOP/EOP 标记边界，首字节提供 VLID 和业务长度。
    input  wire        host_load_sop,
    input  wire        host_load_eop,
    input  wire [15:0] host_load_vlid,
    input  wire [15:0] host_load_length,
    input wire rtc_sync_valid,
    input wire [31:0] rtc_sync_timestamp,
    input wire rtc_pps_in,
    output wire rtc_sync_locked,
    output wire host_unload_sop,host_unload_eop,
    output wire [15:0] host_unload_vlid,host_unload_length,host_unload_src_port,host_unload_dst_port,
    output wire [31:0] host_unload_src_ip,host_unload_dst_ip,
    input wire host_load_header_valid,
    input wire [15:0] host_load_src_port,host_load_dst_port,
    input wire [31:0] host_load_src_ip,host_load_dst_ip,
    output wire mib_busy
);
    // 物理接收不能暂停，内部反压由有限容量的整帧缓存吸收。
    // 内部业务字节及握手信号：兼容加载通路、TX 输入、RX 输出。
    wire [7:0]               legacy_data, tx_payload, rx_payload;
    wire                     legacy_valid, legacy_ready, legacy_host_ready, tx_valid_in, tx_ready_in, rx_valid_out, rx_ready_out;
    // VL 配置总线：每条 VL 占 32 位，保存 BAG（ms）及 LMAX（字节）。
    wire [32 * TX_VL_NUM - 1:0] bags, tx_lmax;
    wire [32 * (RX_VL_NUM > 16 ? 1 : RX_VL_NUM) - 1:0] rx_lmax;
    wire [15:0] rx_lmax_index, rx_lmax_value;
    wire [31:0] arrival_a,arrival_b;
    wire [15:0] a_sport,a_dport,b_sport,b_dport,rx_sport,rx_dport;
    wire [31:0] a_sip,a_dip,b_sip,b_dip,rx_sip,rx_dip;
    wire [TX_VL_NUM-1:0] sched_enable;
    wire [32*TX_VL_NUM-1:0] sched_period,sched_phase;
    wire launch_valid,a_tx_start,b_tx_start;
    wire [31:0] launch_tick,schedule_late,tx_scheduler_tick;
    wire [15:0] a_start_vlid,b_start_vlid,tx_sport,tx_dport;
    wire [31:0] tx_sip,tx_dip;
    wire [31:0] rtc_monotonic,rtc_sync_count;
    wire [7:0] active_mib_addr;
    wire active_mib_write;
    wire [31:0] active_mib_wdata;
    wire rtc_mib_sync=active_mib_write && active_mib_addr==8'h60;

    // Independent TX/RX LMAX tables are supplied by the indexed MIB bank.

    // MIB 读值及统计计数：收发、校验、丢弃统计由模块输出，协议及溢出错误由顶层累计。
    wire [31:0]              mib_basic, tx_frames, rx_frames, crc_errors, sn_errors, duplicates, oversize;
    wire [31:0]              tx_oversize, bad_descriptor, unknown_vl, bad_length;
    reg  [31:0]              protocol_errors, overflow_errors;
    // TX 至双 MAC 的业务流及帧描述：数据握手独立，长度/VL/SN 共用。
    wire [7:0]               ta, tb;
    wire                     tav, tbv, tar, tbr, tsop, teop;
    wire [15:0]              tlen, tvl;
    wire [7:0]               tsn;
    // 双 MAC 至 RX 的业务流及帧描述：每路独立提供数据、SN、长度和边界。
    wire [7:0]               ra, rb, asn, bsn;
    wire                     rav, rbv, rar, rbr, rasop, rbsop, raeop, rbeop;
    wire [15:0]              ralen, rblen, ravl, rbvl, raflen, rbflen;
    // MAC 错误诊断脉冲：CRC、协议格式及接收缓存溢出。
    wire                     acrc, bcrc, aproto, bproto, aoverflow, boverflow;
    // RX帧描述同时供主机卸载和片上管理服务使用。
    wire                     unused_sop, unused_eop;
    wire [15:0]              unused_vlid, unused_length;
    // 选择加载通路及对应 ready；显式帧模式关闭兼容加载流。
    wire snmp_tx_valid,snmp_tx_ready,snmp_tx_sop,snmp_tx_eop,snmp_rx_ready;
    wire [7:0] snmp_tx_data;
    wire [15:0] snmp_tx_length,snmp_tx_vlid,snmp_tx_sport,snmp_tx_dport;
    wire [31:0] snmp_tx_sip,snmp_tx_dip;
    wire snmp_bus_request,snmp_bus_write,snmp_bus_grant;
    wire [7:0] snmp_bus_addr;wire [31:0] snmp_bus_wdata;
    wire [31:0] snmp_requests,snmp_responses,snmp_bad_requests;
    reg rx_route_locked,rx_route_snmp,tx_route_locked,tx_route_snmp;
    reg rx_route_615a,tx_route_615a;
    wire dl_rx_ready,dl_owns,dl_tx_valid,dl_tx_ready,dl_tx_sop,dl_tx_eop,dl_busy;
    wire [7:0] dl_tx_data;
    wire [15:0] dl_tx_length,dl_tx_vlid,dl_tx_sport,dl_tx_dport,dl_status;
    wire [31:0] dl_tx_sip,dl_tx_dip,dl_mib_data;
    wire [31:0] dl_complete,dl_failed,dl_retries,dl_cfg_errors;
    wire rx_is_snmp=ENABLE_HW_SNMP && HOST_FRAMED &&
        (rx_route_locked?rx_route_snmp:rx_dport==161);
    wire tx_is_snmp=ENABLE_HW_SNMP && HOST_FRAMED &&
        (tx_route_locked?tx_route_snmp:snmp_tx_valid);
    wire rx_is_615a=ENABLE_HW_615A && HOST_FRAMED && !rx_is_snmp &&
        (rx_route_locked?rx_route_615a:dl_owns);
    wire tx_is_615a=ENABLE_HW_615A && HOST_FRAMED && !tx_is_snmp &&
        (tx_route_locked?tx_route_615a:dl_tx_valid);
    wire host_rx_ready;
    wire [7:0] frag_data;wire frag_valid,frag_ready,frag_sop,frag_eop,frag_raw,frag_header;
    wire [15:0] frag_vl,frag_length,frag_sport,frag_dport;wire [31:0] frag_sip,frag_dip;
    wire [31:0] fragment_bad;
    wire tx_raw,a_raw,b_raw,rx_raw;
    wire [7:0] raw_data;wire raw_valid,raw_ready,raw_sop,raw_eop;
    wire [15:0] raw_vl,raw_length,raw_sport,raw_dport;wire [31:0] raw_sip,raw_dip;
    wire [31:0] reassembly_completed,reassembly_rejected,reassembly_timeout;
    afdx_ip_fragment_tx fragmenter(
        .clk(clk),.reset(reset),.s_data(host_load_data),.s_valid(host_load_valid && HOST_FRAMED),.s_ready(frag_ready),
        .s_sop(host_load_sop),.s_eop(host_load_eop),.s_vlid(host_load_vlid),.s_length(host_load_length),
        .s_header_valid(host_load_header_valid),.s_sport(host_load_src_port),.s_dport(host_load_dst_port),
        .s_sip(host_load_src_ip),.s_dip(host_load_dst_ip),
        .m_data(frag_data),.m_valid(frag_valid),.m_ready(tx_ready_in && !tx_is_snmp && !tx_is_615a),
        .m_sop(frag_sop),.m_eop(frag_eop),.m_fragment(frag_raw),.m_header_valid(frag_header),
        .m_vlid(frag_vl),.m_length(frag_length),.m_sport(frag_sport),.m_dport(frag_dport),
        .m_sip(frag_sip),.m_dip(frag_dip),.stat_bad_message(fragment_bad));
    afdx_ip_reassembly reassembler(
        .clk(clk),.reset(reset),.now_ms(rtc_monotonic),
        .s_data(raw_data),.s_valid(raw_valid),.s_ready(raw_ready),.s_sop(raw_sop),.s_eop(raw_eop),
        .s_fragment(rx_raw),.s_vlid(raw_vl),.s_length(raw_length),.s_sport(raw_sport),.s_dport(raw_dport),
        .s_sip(raw_sip),.s_dip(raw_dip),
        .m_data(rx_payload),.m_valid(rx_valid_out),.m_ready(rx_ready_out),.m_sop(unused_sop),.m_eop(unused_eop),
        .m_vlid(unused_vlid),.m_length(unused_length),.m_sport(rx_sport),.m_dport(rx_dport),
        .m_sip(rx_sip),.m_dip(rx_dip),.stat_completed(reassembly_completed),
        .stat_rejected(reassembly_rejected),.stat_timeout(reassembly_timeout));

    wire tx_input_sop=tx_is_snmp?snmp_tx_sop:(tx_is_615a?dl_tx_sop:frag_sop);
    wire tx_input_eop=tx_is_snmp?snmp_tx_eop:(tx_is_615a?dl_tx_eop:frag_eop);
    assign tx_payload = HOST_FRAMED ? (tx_is_snmp?snmp_tx_data:(tx_is_615a?dl_tx_data:frag_data)) : legacy_data;
    assign tx_valid_in = HOST_FRAMED ? (tx_is_snmp?snmp_tx_valid:(tx_is_615a?dl_tx_valid:frag_valid)) : legacy_valid;
    assign legacy_ready = HOST_FRAMED ? 1'b0 : tx_ready_in;
    assign host_load_ready = HOST_FRAMED ? frag_ready : legacy_host_ready;
    assign snmp_tx_ready=tx_ready_in && tx_is_snmp;
    assign dl_tx_ready=tx_ready_in && tx_is_615a;
    assign rx_ready_out=rx_is_snmp?snmp_rx_ready:(rx_is_615a?dl_rx_ready:host_rx_ready);
    // Local configuration writes have priority. During remote reads/writes the
    // host must wait for mib_busy=0 before sampling a local read transaction.
    assign snmp_bus_grant=snmp_bus_request && !mib_wr_en;
    assign mib_busy=snmp_bus_grant;
    assign active_mib_addr=snmp_bus_grant?snmp_bus_addr:mib_addr;
    assign active_mib_write=mib_wr_en || (snmp_bus_grant && snmp_bus_write);
    assign active_mib_wdata=snmp_bus_grant?snmp_bus_wdata:mib_wr_data;
    always @(posedge clk or posedge reset)begin
        if(reset)begin rx_route_locked<=0;rx_route_snmp<=0;tx_route_locked<=0;tx_route_snmp<=0;rx_route_615a<=0;tx_route_615a<=0;end
        else begin
            if(rx_valid_out && rx_ready_out)begin
                rx_route_locked<=!unused_eop;rx_route_snmp<=rx_is_snmp;rx_route_615a<=rx_is_615a;
            end
            if(HOST_FRAMED && tx_valid_in && tx_ready_in)begin
                tx_route_locked<=!tx_input_eop;tx_route_snmp<=tx_is_snmp;tx_route_615a<=tx_is_615a;
            end
        end
    end
    generate if(ENABLE_HW_SNMP && HOST_FRAMED)begin:g_hw_snmp
        afdx_snmp_service #(.TX_VL_NUM(TX_VL_NUM),.RX_VL_NUM(RX_VL_NUM),.MANAGEMENT_VL(MANAGEMENT_VL)) agent(
            .clk(clk),.reset(reset),.s_data(rx_payload),.s_valid(rx_valid_out && rx_is_snmp),.s_ready(snmp_rx_ready),
            .s_sop(unused_sop),.s_eop(unused_eop),.s_length(unused_length),
            .s_src_port(rx_sport),.s_dst_port(rx_dport),.s_src_ip(rx_sip),.s_dst_ip(rx_dip),
            .m_data(snmp_tx_data),.m_valid(snmp_tx_valid),.m_ready(snmp_tx_ready),.m_sop(snmp_tx_sop),.m_eop(snmp_tx_eop),
            .m_length(snmp_tx_length),.m_vlid(snmp_tx_vlid),.m_src_port(snmp_tx_sport),.m_dst_port(snmp_tx_dport),
            .m_src_ip(snmp_tx_sip),.m_dst_ip(snmp_tx_dip),
            .bus_request(snmp_bus_request),.bus_write(snmp_bus_write),.bus_addr(snmp_bus_addr),
            .bus_wdata(snmp_bus_wdata),.bus_grant(snmp_bus_grant),.bus_rdata(mib_rd_data),
            .stat_requests(snmp_requests),.stat_responses(snmp_responses),.stat_bad_requests(snmp_bad_requests));
    end else begin:g_no_hw_snmp
        assign snmp_tx_valid=0;assign snmp_tx_data=0;assign snmp_rx_ready=0;
        assign snmp_tx_sop=0;assign snmp_tx_eop=0;assign snmp_tx_length=0;assign snmp_tx_vlid=0;
        assign snmp_tx_sport=0;assign snmp_tx_dport=0;assign snmp_tx_sip=0;assign snmp_tx_dip=0;
        assign snmp_bus_request=0;assign snmp_bus_write=0;assign snmp_bus_addr=0;assign snmp_bus_wdata=0;
        assign snmp_requests=0;assign snmp_responses=0;assign snmp_bad_requests=0;
    end endgenerate
    // 主机接口：缓存兼容加载字节及 RX 交付的卸载字节。
    generate if(ENABLE_HW_615A && HOST_FRAMED)begin:g_hw_615a
        afdx_615a_service #(.MANAGEMENT_VL(MANAGEMENT_VL),.CYCLES_PER_MS(CLK_FREQ/1000),
            .MAX_FILES(DOWNLOAD_MAX_FILES),.FILE_BYTES(DOWNLOAD_FILE_BYTES),.TIMEOUT_MS(DOWNLOAD_TIMEOUT_MS),
            .DALLY_SLOTS(DOWNLOAD_DALLY_SLOTS),.DALLY_MS(DOWNLOAD_DALLY_MS)) downloader(
            .clk(clk),.reset(reset),.s_data(rx_payload),.s_valid(rx_valid_out && rx_is_615a),.s_ready(dl_rx_ready),
            .s_sop(unused_sop),.s_eop(unused_eop),.s_length(unused_length),.s_vlid(unused_vlid),
            .s_src_port(rx_sport),.s_dst_port(rx_dport),.s_src_ip(rx_sip),.s_dst_ip(rx_dip),.owns_udp_port(dl_owns),
            .m_data(dl_tx_data),.m_valid(dl_tx_valid),.m_ready(dl_tx_ready),.m_sop(dl_tx_sop),.m_eop(dl_tx_eop),
            .m_length(dl_tx_length),.m_vlid(dl_tx_vlid),.m_src_port(dl_tx_sport),.m_dst_port(dl_tx_dport),
            .m_src_ip(dl_tx_sip),.m_dst_ip(dl_tx_dip),
            .cfg_write(active_mib_write),.cfg_addr(active_mib_addr),.cfg_data(active_mib_wdata),.cfg_read(dl_mib_data),
            .busy(dl_busy),.operation_status(dl_status),.completed_operations(dl_complete),
            .failed_operations(dl_failed),.retransmissions(dl_retries),.config_errors(dl_cfg_errors));
    end else begin:g_no_hw_615a
        assign dl_rx_ready=0;assign dl_owns=0;assign dl_tx_valid=0;assign dl_tx_data=0;
        assign dl_tx_sop=0;assign dl_tx_eop=0;assign dl_tx_length=0;assign dl_tx_vlid=0;
        assign dl_tx_sport=0;assign dl_tx_dport=0;assign dl_tx_sip=0;assign dl_tx_dip=0;
        assign dl_mib_data=0;assign dl_busy=0;assign dl_status=0;
        assign dl_complete=0;assign dl_failed=0;assign dl_retries=0;assign dl_cfg_errors=0;
    end endgenerate
        afdx_615a_if #(
        .CFG_FRAME_LEN(FRAME_LEN),
        .FRAMED_UNLOAD(1)
    ) u_afdx_615a_if(
        .clk(clk),
        .reset(reset),
        .host_load_data(host_load_data),
        .host_load_valid(host_load_valid && !HOST_FRAMED),
        .host_load_ready(legacy_host_ready),
        .tx_payload_data(legacy_data),
        .tx_payload_valid(legacy_valid),
        .tx_payload_ready(legacy_ready),
        .rx_payload_data(rx_payload),
        .rx_payload_valid(rx_valid_out && !rx_is_snmp && !rx_is_615a),
        .rx_payload_ready(host_rx_ready),
        .host_unload_data(host_unload_data),
        .host_unload_valid(host_unload_valid),
        .host_unload_ready(host_unload_ready),
        .rx_sop(unused_sop),.rx_eop(unused_eop),.rx_vlid(unused_vlid),.rx_length(unused_length),
        .rx_src_port(rx_sport),.rx_dst_port(rx_dport),.rx_src_ip(rx_sip),.rx_dst_ip(rx_dip),
        .host_unload_sop(host_unload_sop),.host_unload_eop(host_unload_eop),
        .host_unload_vlid(host_unload_vlid),.host_unload_length(host_unload_length),
        .host_unload_src_port(host_unload_src_port),.host_unload_dst_port(host_unload_dst_port),
        .host_unload_src_ip(host_unload_src_ip),.host_unload_dst_ip(host_unload_dst_ip)
    );
    // 发送核心：完整业务帧缓存、VL 调度、BAG 限制及双路冗余发送。
        afdx_tx_core #(
        .VL_NUM(TX_VL_NUM),
        .FRAME_LEN(FRAME_LEN),
        .EXPLICIT_FRAMES(HOST_FRAMED),
        .CYCLES_PER_MS(CLK_FREQ / 1000),
        .TIMED_TX(TIMED_TX),
        .COMPENSATE_LATENCY(COMPENSATE_LATENCY),
        .USE_START_FEEDBACK(TIMED_TX),.FRAGMENT_ENABLE(1)
    ) u_afdx_tx_core(
        .clk(clk),
        .reset(reset),
        .payload_fragment(HOST_FRAMED && !tx_is_snmp && !tx_is_615a && frag_raw),.out_fragment(tx_raw),
        .payload_in_data(tx_payload),
        .payload_in_valid(tx_valid_in),
        .payload_in_ready(tx_ready_in),
        .payload_in_sop(tx_input_sop),
        .payload_in_eop(tx_input_eop),
        .payload_in_vlid(tx_is_snmp?snmp_tx_vlid:(tx_is_615a?dl_tx_vlid:frag_vl)),
        .payload_in_length(tx_is_snmp?snmp_tx_length:(tx_is_615a?dl_tx_length:frag_length)),
        .vl_cfg_bag(bags),
        .vl_cfg_lmax(tx_lmax),
        .rtc_timestamp(rtc_monotonic),
        .a_out_data(ta),
        .a_out_valid(tav),
        .a_out_ready(tar),
        .b_out_data(tb),
        .b_out_valid(tbv),
        .b_out_ready(tbr),
        .out_sop(tsop),
        .out_eop(teop),
        .out_length(tlen),
        .tx_vl_id_out(tvl),
        .out_sn(tsn),
        .stat_tx_frame_cnt(tx_frames),
        .stat_drop_oversize(tx_oversize),
        .stat_bad_descriptor(bad_descriptor),
        .sched_enable(sched_enable),.sched_period(sched_period),.sched_phase(sched_phase),
        .out_launch_valid(launch_valid),.out_launch_tick(launch_tick),
        .a_tx_start(a_tx_start),.b_tx_start(b_tx_start),
        .a_tx_start_vlid(a_start_vlid),.b_tx_start_vlid(b_start_vlid),
        .stat_schedule_late(schedule_late),
        .scheduler_tick(tx_scheduler_tick),
        .payload_header_valid((tx_is_snmp || tx_is_615a)?1'b1:frag_header),
        .payload_src_port(tx_is_snmp?snmp_tx_sport:(tx_is_615a?dl_tx_sport:frag_sport)),
        .payload_dst_port(tx_is_snmp?snmp_tx_dport:(tx_is_615a?dl_tx_dport:frag_dport)),
        .payload_src_ip(tx_is_snmp?snmp_tx_sip:(tx_is_615a?dl_tx_sip:frag_sip)),
        .payload_dst_ip(tx_is_snmp?snmp_tx_dip:(tx_is_615a?dl_tx_dip:frag_dip)),
        .out_src_port(tx_sport),.out_dst_port(tx_dport),.out_src_ip(tx_sip),.out_dst_ip(tx_dip)
    );
    // 双通道帧适配器：封装 Ethernet/IP/UDP/SN/FCS，校验并缓存接收整帧。
        afdx_packet_port #(
        .SOURCE_MAC(48'h020000000120),
        .RX_SLOTS(RX_SLOTS),
        .RX_LENGTH_EQUALIZE(RX_LENGTH_EQUALIZE),
        .QUEUED_TX(TIMED_TX),
        .MANAGEMENT_PORTS(1),.SUPPORT_FRAGMENT(1)
    ) u_mac_a(
        .clk(clk),
        .reset(reset),
        .s_fragment(tx_raw),.m_fragment(a_raw),
        .s_data(ta),
        .s_valid(tav),
        .s_ready(tar),
        .s_sop(tsop),
        .s_eop(teop),
        .s_length(tlen),
        .s_vlid(tvl),
        .s_sn(tsn),
        .tx_data(tx_a_data),
        .tx_valid(tx_a_valid),
        .tx_idle(tx_a_ready),
        .rx_data(rx_a_data),
        .rx_valid(rx_a_valid),
        .m_data(ra),
        .m_valid(rav),
        .m_ready(rar),
        .m_sop(rasop),
        .m_eop(raeop),
        .m_length(ralen),
        .m_vlid(ravl),
        .m_frame_length(raflen),
        .m_sn(asn),
        .crc_error(acrc),
        .protocol_error(aproto),
        .overflow_error(aoverflow),
        .rx_timestamp(rtc_monotonic),
        .m_timestamp(arrival_a),
        .m_src_port(a_sport),.m_dst_port(a_dport),.m_src_ip(a_sip),.m_dst_ip(a_dip),
        .s_launch_valid(launch_valid),.s_launch_tick(launch_tick),
        .tx_start_pulse(a_tx_start),.tx_start_vlid(a_start_vlid),
        .s_header_valid(1'b1),.s_src_port(tx_sport),.s_dst_port(tx_dport),.s_src_ip(tx_sip),.s_dst_ip(tx_dip)
    );
        afdx_packet_port #(
        .SOURCE_MAC(48'h020000000140),
        .RX_SLOTS(RX_SLOTS),
        .RX_LENGTH_EQUALIZE(RX_LENGTH_EQUALIZE),
        .QUEUED_TX(TIMED_TX),
        .MANAGEMENT_PORTS(1),.SUPPORT_FRAGMENT(1)
    ) u_mac_b(
        .clk(clk),
        .reset(reset),
        .s_fragment(tx_raw),.m_fragment(b_raw),
        .s_data(tb),
        .s_valid(tbv),
        .s_ready(tbr),
        .s_sop(tsop),
        .s_eop(teop),
        .s_length(tlen),
        .s_vlid(tvl),
        .s_sn(tsn),
        .tx_data(tx_b_data),
        .tx_valid(tx_b_valid),
        .tx_idle(tx_b_ready),
        .rx_data(rx_b_data),
        .rx_valid(rx_b_valid),
        .m_data(rb),
        .m_valid(rbv),
        .m_ready(rbr),
        .m_sop(rbsop),
        .m_eop(rbeop),
        .m_length(rblen),
        .m_vlid(rbvl),
        .m_frame_length(rbflen),
        .m_sn(bsn),
        .crc_error(bcrc),
        .protocol_error(bproto),
        .overflow_error(boverflow),
        .rx_timestamp(rtc_monotonic),
        .m_timestamp(arrival_b),
        .m_src_port(b_sport),.m_dst_port(b_dport),.m_src_ip(b_sip),.m_dst_ip(b_dip),
        .s_launch_valid(launch_valid),.s_launch_tick(launch_tick),
        .tx_start_pulse(b_tx_start),.tx_start_vlid(b_start_vlid),
        .s_header_valid(1'b1),.s_src_port(tx_sport),.s_dst_port(tx_dport),.s_src_ip(tx_sip),.s_dst_ip(tx_dip)
    );
    // 接收核心：整帧执行 VL、长度、SN 及冗余检查，再交付业务数据。
        afdx_rx_core #(
        .VL_NUM(RX_VL_NUM),
        .SKEW_MAX_MS(SKEW_MAX_MS),
        .CLK_FREQ(CLK_FREQ),
        .INDEXED_LMAX(1),
        .MAC_STREAMING(1),.FRAGMENT_ENABLE(1),
        .USE_ARRIVAL_TIMESTAMP(1)
    ) u_afdx_rx_core(
        .a_fragment(a_raw),.b_fragment(b_raw),.out_fragment(rx_raw),
        .clk(clk),
        .reset(reset),
        .a_payload_data(ra),
        .a_payload_valid(rav),
        .a_payload_ready(rar),
        .a_payload_sop(rasop),
        .a_payload_eop(raeop),
        .a_payload_vlid(ravl),
        .a_sn(asn),
        .a_length(ralen),
        .a_frame_length(raflen),
        .a_crc_err(acrc),
        .a_payload_bad(1'b0),
        .b_payload_data(rb),
        .b_payload_valid(rbv),
        .b_payload_ready(rbr),
        .b_payload_sop(rbsop),
        .b_payload_eop(rbeop),
        .b_payload_vlid(rbvl),
        .b_sn(bsn),
        .b_length(rblen),
        .b_frame_length(rbflen),
        .b_crc_err(bcrc),
        .b_payload_bad(1'b0),
        .rtc_timestamp(rtc_monotonic),
        .vl_cfg_lmax(rx_lmax[31:0]),
        .out_payload_data(raw_data),
        .out_payload_valid(raw_valid),
        .out_payload_ready(raw_ready),
        .out_payload_sop(raw_sop),
        .out_payload_eop(raw_eop),
        .out_payload_vlid(raw_vl),
        .out_payload_length(raw_length),
        .stat_rx_frame_cnt(rx_frames),
        .stat_err_crc(crc_errors),
        .stat_err_sn(sn_errors),
        .stat_drop_redundant(duplicates),
        .stat_drop_oversize(oversize),
        .stat_drop_unknown(unknown_vl),
        .stat_bad_length(bad_length),
        .lmax_index(rx_lmax_index),
        .indexed_lmax(rx_lmax_value),
        .a_arrival_timestamp(arrival_a),
        .b_arrival_timestamp(arrival_b),
        .a_src_port(a_sport),.a_dst_port(a_dport),.b_src_port(b_sport),.b_dst_port(b_dport),
        .a_src_ip(a_sip),.a_dst_ip(a_dip),.b_src_ip(b_sip),.b_dst_ip(b_dip),
        .out_src_port(raw_sport),.out_dst_port(raw_dport),.out_src_ip(raw_sip),.out_dst_ip(raw_dip)
    );
    // 本地MIB与片上SNMP共享访问，外部配置写入优先。
        snmp_mib #(
        .VL_NUM(VL_NUM),
        .TX_VL_NUM(TX_VL_NUM),
        .RX_VL_NUM(RX_VL_NUM),
        .RAM_RX_TABLE(RX_VL_NUM > 16),
        .SCHED_CYCLES_PER_MS(CLK_FREQ/1000),
        .SCHED_START_SPREAD(COMPENSATE_LATENCY?2928:0)
    ) u_snmp_mib(
        .clk(clk),
        .reset(reset),
        .mib_addr(active_mib_addr),
        .mib_wr_en(active_mib_write),
        .mib_wr_data(active_mib_wdata),
        .mib_rd_data(mib_basic),
        .vl_cfg_bag(bags),
        .vl_cfg_lmax(tx_lmax),
        .vl_cfg_rx_lmax(rx_lmax),
        .stat_tx_frame_cnt(tx_frames),
        .stat_rx_frame_cnt(rx_frames),
        .stat_err_crc(crc_errors),
        .stat_err_sn(sn_errors),
        .rx_lookup_index(rx_lmax_index),
        .rx_lookup_lmax(rx_lmax_value),
        .sched_enable(sched_enable),.sched_period(sched_period),.sched_phase(sched_phase)
    );
    // 本地 RTC：分频产生毫秒时间戳，供接收冗余窗口判断。
        rtc_timer #(
        .CLK_FREQ(CLK_FREQ)
    ) u_rtc(
        .clk(clk),
        .reset(reset),
        .rtc_ts_out(rtc_timestamp),
        .sync_valid(rtc_mib_sync?1'b1:rtc_sync_valid),
        .sync_ts_in(rtc_mib_sync?active_mib_wdata:rtc_sync_timestamp),
        .pps_in(rtc_pps_in),
        .monotonic_ts_out(rtc_monotonic),
        .sync_locked(rtc_sync_locked),
        .sync_count(rtc_sync_count)
    );
    // 扩展统计映射 0x24～0x2B，其他地址返回基础 MIB 读值。
    wire monitor_selected;wire [31:0] monitor_data;
    afdx_monitor #(.CLK_FREQ(CLK_FREQ)) monitor(
        .clk(clk),.reset(reset),.timestamp(rtc_monotonic),
        .live_stats({32'd0,32'd0,rtc_sync_count,schedule_late,bad_length,unknown_vl,bad_descriptor,
            tx_oversize,overflow_errors,protocol_errors,oversize,duplicates,sn_errors,crc_errors,rx_frames,tx_frames}),
        .mac_faults({2'd0,boverflow,aoverflow,bproto,aproto,bcrc,acrc}),
        .bus_addr(active_mib_addr),.bus_write(active_mib_write),.bus_wdata(active_mib_wdata),
        .bus_rdata(monitor_data),.bus_selected(monitor_selected));
    assign mib_rd_data = (ENABLE_HW_615A && active_mib_addr>=8'hb0 && active_mib_addr<=8'hbb) ? dl_mib_data :
    monitor_selected ? monitor_data :
    (active_mib_addr == 8'h90) ? snmp_requests : (active_mib_addr == 8'h91) ? snmp_responses :
    (active_mib_addr == 8'h92) ? snmp_bad_requests :
    (active_mib_addr == 8'h94) ? fragment_bad :
    (active_mib_addr == 8'h95) ? reassembly_completed :
    (active_mib_addr == 8'h96) ? reassembly_rejected :
    (active_mib_addr == 8'h97) ? reassembly_timeout :
    (active_mib_addr == 8'h48) ? schedule_late :
    (active_mib_addr == 8'h4a) ? tx_scheduler_tick :
    (active_mib_addr == 8'h60) ? rtc_timestamp :
    (active_mib_addr == 8'h61) ? {31'd0,rtc_sync_locked} :
    (active_mib_addr == 8'h62) ? rtc_sync_count :
    (active_mib_addr == 8'h63) ? rtc_monotonic :
    (active_mib_addr == 8'h24) ? duplicates : (active_mib_addr == 8'h25) ? oversize :
    (active_mib_addr == 8'h26) ? protocol_errors : (active_mib_addr == 8'h27) ? overflow_errors :
    (active_mib_addr == 8'h28) ? tx_oversize : (active_mib_addr == 8'h29) ? bad_descriptor :
    (active_mib_addr == 8'h2a) ? unknown_vl : (active_mib_addr == 8'h2b) ? bad_length : mib_basic;
    // 累计两路诊断错误：同拍均报错则加 2，复位清零。
    always @ (posedge clk or posedge reset) begin
        if (reset) begin
            protocol_errors <= 0;
            overflow_errors <= 0;
        end else begin
            if (aproto || bproto)
            protocol_errors <= protocol_errors + {31'd0, aproto} + {31'd0, bproto};
            if (aoverflow || boverflow)
            overflow_errors <= overflow_errors + {31'd0, aoverflow} + {31'd0, boverflow};
        end
    end
endmodule
