`timescale 1ns/1ns
// Synthesizable A3 download target. UDP/IP/FCS and redundant-copy validation
// are supplied by the AFDX MAC/RX core. No CPU or Python executes this protocol.
// Fixed octet/512-byte TFTP profile; unknown options are ignored (RFC 2347).
// Export RAM and names are programmed through the local B0..BA MIB window.
module afdx_615a_service #(
    parameter MANAGEMENT_VL=0, CYCLES_PER_MS=12500,
    parameter MAX_FILES=4, FILE_BYTES=4096, NAME_BYTES=32,
    parameter [127:0] TARGET_ID="TARGET", parameter TARGET_LEN=6,
    parameter TIMEOUT_MS=1000, MAX_RETRIES=5, SELECTION_TIMEOUT_MS=30000,
    parameter OPERATION_TIMEOUT_MS=120000,
    // RFC 1350 receiver dally. Keep completed transfers independently of
    // the current operation; never evict an unexpired final-ACK record.
    parameter DALLY_SLOTS=4, DALLY_MS=TIMEOUT_MS*(MAX_RETRIES+1)
)(
    input wire clk,reset,
    input wire [7:0] s_data,input wire s_valid,output wire s_ready,
    input wire s_sop,s_eop,input wire [15:0] s_length,s_vlid,
    input wire [15:0] s_src_port,s_dst_port,input wire [31:0] s_src_ip,s_dst_ip,
    output wire owns_udp_port,
    output wire [7:0] m_data,output wire m_valid,input wire m_ready,
    output wire m_sop,m_eop,output wire [15:0] m_length,m_vlid,m_src_port,m_dst_port,
    output wire [31:0] m_src_ip,m_dst_ip,
    input wire cfg_write,input wire [7:0] cfg_addr,input wire [31:0] cfg_data,
    output reg [31:0] cfg_read,
    output reg busy,output reg [15:0] operation_status,
    output reg [31:0] completed_operations,failed_operations,retransmissions,config_errors
);
    localparam WAIT_RX=0,CAPTURE=1,PARSE=2,SEND_MASTER=3,SEND_REPLY=4,
        START_FILE=5,SELECT_FILES=6,CHECK_DALLY=7,COPY_WAIT=8,COPY_SELECTION=9,
        DALLY_WAIT=10,SELECT_LENGTH_WAIT=11,SELECT_LENGTH=12,SELECT_CANDIDATE=13,
        SELECT_CHAR_WAIT=14,SELECT_CHAR=15,SELECT_END_WAIT=16,SELECT_END=17,
        BUILD_PREFIX=18,BUILD_ENTRY=19,BUILD_NAME_LENGTH=20,BUILD_NAME=21,
        BUILD_TRAILER=22;
    localparam REPLY_ACK=0,REPLY_ERROR=1,REPLY_INIT=2,REPLY_SNAPSHOT=3;
    localparam KIND_STATUS=1,KIND_LIST=2,KIND_FILE=3;
    localparam ACCEPTED=16'h0001,PROGRESS=16'h0002,COMPLETE=16'h0003,
        DENIED=16'h1000,TARGET_ABORT=16'h1003,LOADER_ABORT=16'h1004,OPERATOR_ABORT=16'h1005;
    reg [4:0] state;
    // Only the small protocol header needs parallel inspection. Packet bodies
    // use synchronous byte RAMs with one write per clock and no content reset.
    reg [7:0] request_mem[0:127];
    reg [7:0] request_last;
    (* ramstyle="M4K, no_rw_check" *) reg [7:0] request_data_mem[0:2047];
    (* ramstyle="M4K, no_rw_check" *) reg [7:0] selection_mem[0:1023];
    reg [7:0] selection_header[0:7];
    (* ramstyle="M4K, no_rw_check" *) reg [7:0] object_mem[0:511];
    (* ramstyle="M4K, no_rw_check" *) reg [7:0] read_mem[0:1023];
    (* ramstyle="M4K, no_rw_check" *) reg [7:0] file_mem[0:MAX_FILES*FILE_BYTES-1];
    reg [7:0] names[0:MAX_FILES*NAME_BYTES-1];
    reg [5:0] name_length[0:MAX_FILES-1];
    reg [31:0] file_length[0:MAX_FILES-1];
    reg [MAX_FILES-1:0] file_enabled;
    reg [15:0] file_status[0:MAX_FILES-1];
    reg [7:0] selected[0:MAX_FILES-1];
    reg [7:0] cfg_index,name_index,selection_count,completed_files,current_file;
    reg [31:0] cfg_offset,file_offset;
    reg [10:0] capture_count,request_length,reply_length,master_length,send_index;
    reg capture_bad;
    reg [15:0] request_sport,request_dport,request_vlid;
    reg [31:0] request_sip,request_dip,owner_ip,local_ip;
    reg [15:0] owner_vlid;
    reg operator_mode,initialized,status_dirty,list_pending,selection_committed;
    reg [15:0] generation,control_tid,client_tid,init_sport,control_sport,client_peer;
    reg [15:0] read_tid,read_sport,read_vlid;
    reg [31:0] read_ip,read_local,read_timer;
    reg [10:0] read_length;
    reg read_alive,read_list;
    reg [7:0] read_retries,control_retries;
    reg control_alive,control_writing,client_alive,master_outstanding,master_data;
    reg [15:0] control_block,client_block;
    reg [10:0] selection_length,object_length,block_length;
    reg [31:0] object_offset;
    reg [1:0] master_kind;
    reg [15:0] status_counter;
    reg [31:0] byte_clock,control_timer,client_timer,operation_timer,selection_timer,status_timer,client_timeout;
    reg [7:0] retries;
    reg [15:0] reply_source,reply_destination;
    reg [31:0] reply_ip,reply_local;
    reg [15:0] reply_vlid;
    reg [7:0] file_q;
    reg [9:0] build_index;
    reg [7:0] request_q,selection_q,object_q,read_q,dally_q;
    reg [1:0] reply_kind;
    reg [15:0] reply_code;
    reg reply_wait;
    reg build_snapshot,build_list_file;
    reg [10:0] build_position,build_length,build_prefix_length;
    reg [7:0] build_entry,build_file,build_char;
    reg [2:0] build_tail;
    reg [15:0] build_status_code,build_status_counter;
    reg [7:0] build_description_length,build_count;
    wire [7:0] build_ratio;
    reg ratio_start;
    reg [10:0] select_cursor;
    reg [7:0] select_count,select_entry,select_file,select_char,select_name_length;
    reg [15:0] reply_after;
    reg [DALLY_SLOTS-1:0] dally_valid,dally_started;
    reg [15:0] dally_tid[0:DALLY_SLOTS-1],dally_peer[0:DALLY_SLOTS-1],dally_vlid[0:DALLY_SLOTS-1];
    reg [15:0] dally_block[0:DALLY_SLOTS-1];
    reg [31:0] dally_ip[0:DALLY_SLOTS-1],dally_local[0:DALLY_SLOTS-1],dally_timer[0:DALLY_SLOTS-1];
    reg [10:0] dally_length[0:DALLY_SLOTS-1];
    (* ramstyle="M4K, no_rw_check" *) reg [7:0] dally_mem[0:DALLY_SLOTS*512-1];
    integer control_dally_slot,dally_check_slot,dally_free,dally_match,dally_port_index;
    reg dally_owns;
    integer i,j,k,n,fid,total;
    reg bad,equal_name,owner_matches;
    reg [15:0] opcode,received_block,abort_code;
    reg [7:0] suffix0,suffix1,suffix2;
    reg [MAX_FILES-1:0] seen;
    wire tick_ms=byte_clock==CYCLES_PER_MS-1;
    wire reply_sending=state==SEND_REPLY;
    // Fifteen restoring-division steps finish before the earliest percentage
    // byte (prefix offset 23). Object construction does not need another state.
    afdx_load_percent percent_engine(.clk(clk),.reset(reset),.start(ratio_start),
        .complete(operation_status==COMPLETE),.completed(completed_files),
        .selected(selection_count),.value(build_ratio));
    always @(*)begin
        dally_owns=0;
        for(dally_port_index=0;dally_port_index<DALLY_SLOTS;dally_port_index=dally_port_index+1)
            if(dally_valid[dally_port_index] && s_dst_port==dally_tid[dally_port_index])dally_owns=1;
    end
    assign s_ready=(state==WAIT_RX || state==CAPTURE) && !reset;
    assign owns_udp_port=s_dst_port==69 || (control_alive && s_dst_port==control_tid) ||
        (client_alive && s_dst_port==client_tid) || (read_alive && s_dst_port==read_tid) || dally_owns;
    assign m_valid=(state==SEND_MASTER || state==SEND_REPLY) && !reset;
    // Prefetch the next byte only on a handshake. The registered RAM outputs
    // consequently remain stable during arbitrary output backpressure.
    wire [10:0] tx_prefetch=m_valid?
        send_index+((m_ready && !m_eop)?11'd1:11'd0):11'd0;
    wire [7:0] wrq_name_length=master_kind==KIND_FILE?name_length[current_file]:TARGET_LEN+4;
    wire [7:0] master_byte=master_data?
        (send_index==0?8'd0:send_index==1?8'd3:
         send_index==2?client_block[15:8]:send_index==3?client_block[7:0]:
         master_kind==KIND_FILE?file_q:object_q):wrq_byte(send_index);
    assign m_data=reply_sending?(reply_kind==REPLY_SNAPSHOT?read_q:reply_byte(send_index)):master_byte;
    assign m_length=reply_sending?reply_length:master_length;
    assign m_sop=send_index==0;
    assign m_eop=send_index==m_length-1;
    assign m_vlid=MANAGEMENT_VL;
    assign m_src_port=reply_sending?reply_source:client_tid;
    assign m_dst_port=reply_sending?reply_destination:(client_peer==0?16'd69:client_peer);
    assign m_src_ip=reply_sending?reply_local:local_ip;
    assign m_dst_ip=reply_sending?reply_ip:owner_ip;

    function [7:0] target_byte;
        input integer index;
        begin target_byte=TARGET_ID >> ((TARGET_LEN-1-index)*8);end
    endfunction
    function [7:0] wrq_byte;
        input [10:0] index;
        integer offset;
        begin
            offset=index-2;
            if(index==0)wrq_byte=0;
            else if(index==1)wrq_byte=2;
            else if(offset<wrq_name_length)begin
                if(master_kind==KIND_FILE)wrq_byte=names[current_file*NAME_BYTES+offset];
                else if(offset<TARGET_LEN)wrq_byte=target_byte(offset);
                else case(offset-TARGET_LEN)
                    0:wrq_byte=".";1:wrq_byte="L";2:wrq_byte="N";
                    default:wrq_byte=master_kind==KIND_STATUS?"S":"L";
                endcase
            end else case(offset-wrq_name_length)
                1:wrq_byte="o";2:wrq_byte="c";3:wrq_byte="t";
                4:wrq_byte="e";5:wrq_byte="t";default:wrq_byte=0;
            endcase
        end
    endfunction
    function [7:0] reply_byte;
        input [10:0] index;
        begin
            reply_byte=0;
            if(reply_kind==REPLY_INIT)case(index)
                1:reply_byte=3;3:reply_byte=1;7:reply_byte=10;
                8:reply_byte="A";9:reply_byte="3";11,12:reply_byte=1;
                default:reply_byte=0;
            endcase
            else if(index==1)reply_byte=reply_kind==REPLY_ACK?8'd4:8'd5;
            else if(index==2)reply_byte=reply_code[15:8];
            else if(index==3)reply_byte=reply_code[7:0];
            else if(reply_kind==REPLY_ERROR && reply_wait)case(index)
                4:reply_byte="W";5:reply_byte="A";6:reply_byte="I";
                7:reply_byte="T";8:reply_byte=":";9:reply_byte="1";
                default:reply_byte=0;
            endcase
        end
    endfunction
    function [15:0] allocate_tid;
        input [15:0] previous;
        reg [15:0] candidate;
        reg used;
        integer a,b;
        begin
            allocate_tid=16'hc000|((previous+1'b1)&16'h3fff);
            // Candidates depend only on the original TID, not the preceding
            // candidate's comparison. Descending priority selects the first
            // unused TID, including wrap, exactly as the former serial search.
            for(a=DALLY_SLOTS+3;a>=0;a=a-1)begin
                candidate=16'hc000|((previous+a+1)&16'h3fff);
                used=(control_alive && candidate==control_tid) ||
                    (client_alive && candidate==client_tid) || (read_alive && candidate==read_tid);
                for(b=0;b<DALLY_SLOTS;b=b+1)
                    if(dally_valid[b] && candidate==dally_tid[b])used=1;
                if(!used)allocate_tid=candidate;
            end
        end
    endfunction
    function [15:0] next_block;
        input [15:0] block;
        begin next_block=block==16'hffff ? 16'd1 : block+1'b1;end
    endfunction
    function [3:0] hex_value;
        input [7:0] c;
        begin hex_value=c<=8'h39 ? c-8'h30 : ((c|8'h20)-8'h61+10);end
    endfunction
    function is_hex;
        input [7:0] c;
        begin is_hex=(c>=8'h30&&c<=8'h39)||((c|8'h20)>=8'h61&&(c|8'h20)<=8'h66);end
    endfunction
    function integer description_length;
        input [15:0] code;
        begin case(code)
            ACCEPTED:description_length=8;PROGRESS:description_length=7;COMPLETE:description_length=9;
            DENIED:description_length=17;TARGET_ABORT:description_length=17;
            OPERATOR_ABORT:description_length=14;default:description_length=15;
        endcase end
    endfunction
    function [7:0] description_byte;
        input [15:0] code;input integer index;
        reg [135:0] text;
        begin
            case(code)
                ACCEPTED:text="Accepted";PROGRESS:text="Sending";COMPLETE:text="Completed";
                DENIED:text="Invalid selection";TARGET_ABORT:text="Operation timeout";
                OPERATOR_ABORT:text="Operator abort";default:text="Transfer failed";
            endcase
            description_byte=text >> ((description_length(code)-1-index)*8);
        end
    endfunction
    // Exact three decimal digits for every unsigned octet, without / or %.
    function [11:0] ratio_decimal;
        input [7:0] value;
        reg [7:0] remainder;
        reg [3:0] hundreds,tens,ones;
        begin
            if(value>=200)begin hundreds=2;remainder=value-8'd200;end
            else if(value>=100)begin hundreds=1;remainder=value-8'd100;end
            else begin hundreds=0;remainder=value;end
            if(remainder>=90)tens=9;
            else if(remainder>=80)tens=8;
            else if(remainder>=70)tens=7;
            else if(remainder>=60)tens=6;
            else if(remainder>=50)tens=5;
            else if(remainder>=40)tens=4;
            else if(remainder>=30)tens=3;
            else if(remainder>=20)tens=2;
            else if(remainder>=10)tens=1;
            else tens=0;
            ones=remainder-tens*8'd10;
            ratio_decimal={hundreds,tens,ones};
        end
    endfunction
    function [7:0] prefix_byte;
        input [10:0] position;
        integer offset,tail;
        reg [11:0] digits;
        begin
            digits=ratio_decimal(build_ratio);
            offset=position-(build_snapshot?4:0);
            tail=offset-10-build_description_length;
            prefix_byte=0;
            if(build_snapshot && position<4)begin
                if(position==1)prefix_byte=3;
                else if(position==3)prefix_byte=1;
            end else if(offset<4)case(offset)
                2:prefix_byte={5'd0,build_length[10:8]};
                3:prefix_byte=build_length[7:0];
                default:prefix_byte=0;
            endcase
            else if(offset==4)prefix_byte="A";
            else if(offset==5)prefix_byte="3";
            else if(build_list_file)begin
                if(offset==7)prefix_byte=build_count;
            end else if(offset==6)prefix_byte=build_status_code[15:8];
            else if(offset==7)prefix_byte=build_status_code[7:0];
            else if(offset==8)prefix_byte=build_description_length+1'b1;
            else if(offset<9+build_description_length)
                prefix_byte=description_byte(build_status_code,offset-9);
            else case(tail)
                0:prefix_byte=build_status_counter[15:8];
                1:prefix_byte=build_status_counter[7:0];
                6:prefix_byte="0"+digits[11:8];
                7:prefix_byte="0"+digits[7:4];
                8:prefix_byte="0"+digits[3:0];
                10:prefix_byte=build_count;
                default:prefix_byte=0;
            endcase
        end
    endfunction
    reg [7:0] build_byte;
    wire build_write=state==BUILD_PREFIX || state==BUILD_NAME_LENGTH ||
        state==BUILD_NAME || state==BUILD_TRAILER;
    always @(*)begin
        build_byte=0;
        case(state)
            BUILD_PREFIX:build_byte=prefix_byte(build_position);
            BUILD_NAME_LENGTH:build_byte=name_length[build_file]+1'b1;
            BUILD_NAME:build_byte=names[build_file*NAME_BYTES+build_char];
            BUILD_TRAILER:begin
                if(build_list_file)begin
                    if(build_tail==1)build_byte=1;
                end else case(build_tail)
                    1:build_byte=file_status[build_file][15:8];
                    2:build_byte=file_status[build_file][7:0];
                    3:build_byte=1;
                    default:build_byte=0;
                endcase
            end
            default:begin end
        endcase
    end

    localparam FILE_AW=MAX_FILES*FILE_BYTES<2?1:$clog2(MAX_FILES*FILE_BYTES);
    localparam DALLY_AW=DALLY_SLOTS*512<2?1:$clog2(DALLY_SLOTS*512);
    wire [FILE_AW-1:0] file_read_address=current_file*FILE_BYTES+file_offset+
        (tx_prefetch>=4?tx_prefetch-11'd4:11'd0);
    wire [FILE_AW-1:0] file_write_address=cfg_index*FILE_BYTES+cfg_offset;
    wire [8:0] object_read_address=object_offset+(tx_prefetch>=4?tx_prefetch-11'd4:11'd0);
    wire [10:0] request_read_address={1'b0,build_index}+11'd4;
    wire [10:0] selection_read_position=select_cursor+
        ((state==SELECT_CHAR_WAIT || state==SELECT_CHAR)?{3'd0,select_char}:11'd0);
    wire [10:0] selection_write_position=selection_length+{1'b0,build_index};
    wire [DALLY_AW-1:0] dally_read_address=dally_check_slot*512+build_index;
    wire [DALLY_AW-1:0] dally_write_address=control_dally_slot*512+build_index;
    always @(posedge clk)begin
        request_q<=request_data_mem[request_read_address];
        selection_q<=selection_mem[selection_read_position[9:0]];
        dally_q<=dally_mem[dally_read_address];
        read_q<=read_mem[tx_prefetch[9:0]];
        object_q<=object_mem[object_read_address];
        file_q<=file_mem[file_read_address];
        if(!reset)begin
            if(s_valid && (state==WAIT_RX || state==CAPTURE))begin
                if(state==WAIT_RX)request_data_mem[0]<=s_data;
                else if(capture_count<1471)request_data_mem[capture_count]<=s_data;
            end
            if(state==COPY_SELECTION)begin
                selection_mem[selection_write_position[9:0]]<=request_q;
                dally_mem[dally_write_address]<=request_q;
                if(selection_write_position<8)selection_header[selection_write_position[2:0]]<=request_q;
            end
            if(build_write)begin
                if(build_snapshot)read_mem[build_position[9:0]]<=build_byte;
                else object_mem[build_position[8:0]]<=build_byte;
            end
            if(cfg_write && !busy && state==WAIT_RX && cfg_addr==8'hb5 && cfg_offset<FILE_BYTES)
                file_mem[file_write_address]<=cfg_data[7:0];
        end
    end
    function [15:0] incoming_abort;
        input [10:0] length;
        reg [15:0] code;
        begin
            code=LOADER_ABORT;
            if(length==15 && request_mem[2]==0 && request_mem[3]==0 && request_mem[4]=="A" && request_mem[5]=="B" && request_mem[6]=="O" && request_mem[7]=="R" && request_mem[8]=="T" && request_mem[9]==":" && request_mem[14]==0 &&
                is_hex(request_mem[10])&&is_hex(request_mem[11])&&is_hex(request_mem[12])&&is_hex(request_mem[13]))begin
                code={hex_value(request_mem[10]),hex_value(request_mem[11]),hex_value(request_mem[12]),hex_value(request_mem[13])};
                if(code!=TARGET_ABORT && code!=OPERATOR_ABORT)code=LOADER_ABORT;
            end
            incoming_abort=code;
        end
    endfunction

    task start_reply;
        input [15:0] source_port;
        input integer length;
        begin
            reply_source<=source_port;reply_destination<=request_sport;
            reply_ip<=request_sip;reply_local<=request_dip;reply_vlid<=request_vlid;
            reply_length<=length;send_index<=0;state<=SEND_REPLY;
        end
    endtask
    task acknowledge;
        input [15:0] source_port,block;
        begin
            reply_kind<=REPLY_ACK;reply_code<=block;
            start_reply(source_port,4);
        end
    endtask
    task error_reply;
        input [15:0] source_port,code;
        input wait_message;
        begin
            reply_kind<=REPLY_ERROR;reply_code<=code;reply_wait<=wait_message;
            start_reply(source_port,wait_message?11:5);
        end
    endtask
    task repeat_initialization;
        begin
            reply_kind<=REPLY_INIT;
            reply_source<=control_tid;reply_destination<=init_sport;reply_ip<=owner_ip;reply_local<=local_ip;
            reply_length<=14;send_index<=0;state<=SEND_REPLY;
        end
    endtask
    task repeat_snapshot;
        begin
            reply_kind<=REPLY_SNAPSHOT;
            reply_source<=read_tid;reply_destination<=read_sport;reply_ip<=read_ip;reply_local<=read_local;
            reply_length<=read_length;send_index<=0;state<=SEND_REPLY;
        end
    endtask
    task set_operation;
        input [15:0] code;
        begin
            operation_status<=code;status_dirty<=1;status_counter<=status_counter+1'b1;
        end
    endtask
    task abort_operation;
        input [15:0] code;
        begin
            master_outstanding<=0;client_alive<=0;control_writing<=0;
            list_pending<=0;initialized<=1;state<=WAIT_RX;
            for(k=0;k<MAX_FILES;k=k+1)if(file_status[k]!=COMPLETE)file_status[k]<=code;
            set_operation(code);
        end
    endtask
    // Count only per-file metadata in parallel. The builder emits a single
    // byte per clock; variable-length names never create parallel RAM ports.
    task begin_object;
        input list_file,snapshot;
        begin
            n=description_length(operation_status);
            total=list_file?8:21+n;
            fid=0;
            for(i=0;i<MAX_FILES;i=i+1)begin
                if(list_file)begin
                    if(file_enabled[i])begin total=total+name_length[i]+4;fid=fid+1;end
                end else if(i<selection_count)total=total+name_length[selected[i]]+6;
            end
            ratio_start<=1;
            build_snapshot<=snapshot;build_list_file<=list_file;
            build_status_code<=operation_status;build_status_counter<=status_counter;
            build_description_length<=n;
            build_count<=list_file?fid:selection_count;
            build_length<=total;build_prefix_length<=(list_file?8:21+n)+(snapshot?4:0);
            build_position<=0;build_entry<=0;build_char<=0;build_tail<=0;
            if(snapshot)begin
                // The independent snapshot stays immutable until its ACK or
                // timeout, even while a master object is awaiting its ACK.
                generation<=allocate_tid(generation);read_tid<=allocate_tid(generation);
                read_alive<=1;read_retries<=0;read_timer<=0;read_length<=total+4;
                read_list<=list_file;reply_kind<=REPLY_SNAPSHOT;
                read_sport<=request_sport;read_ip<=request_sip;read_local<=request_dip;read_vlid<=request_vlid;
                start_reply(allocate_tid(generation),total+4);
            end else object_length<=total;
            state<=BUILD_PREFIX;
        end
    endtask
    task build_wrq;
        input [1:0] kind;
        begin
            master_kind<=kind;master_data<=0;client_peer<=0;client_block<=0;client_timeout<=TIMEOUT_MS;
            generation<=allocate_tid(generation);client_tid<=allocate_tid(generation);
            client_alive<=1;master_outstanding<=1;retries<=0;client_timer<=0;
            master_length<=(kind==KIND_FILE?name_length[current_file]:TARGET_LEN+4)+9;
            send_index<=0;state<=SEND_MASTER;
        end
    endtask
    task prepare_data;
        begin
            client_block<=next_block(client_block);master_data<=1;
            retries<=0;client_timer<=0;client_timeout<=TIMEOUT_MS;
            if(master_kind==KIND_FILE)begin
                total=file_length[current_file]-file_offset;if(total>512)total=512;
            end else begin
                total=object_length-object_offset;if(total>512)total=512;
            end
            // Data and retransmissions stream from the retained source RAM.
            // The four TFTP header bytes provide the synchronous read latency.
            block_length<=total;master_length<=total+4;send_index<=0;state<=SEND_MASTER;
        end
    endtask

    always @(*)begin
        cfg_read=0;
        case(cfg_addr)
            8'hb0:cfg_read=cfg_index;
            8'hb1:cfg_read=cfg_offset;
            8'hb2:cfg_read=file_length[cfg_index];
            8'hb3:cfg_read=name_index;
            8'hb6:cfg_read=file_enabled[cfg_index];
            8'hb7:cfg_read={15'd0,busy,operation_status};
            8'hb8:cfg_read=completed_operations;
            8'hb9:cfg_read=failed_operations;
            8'hba:cfg_read=retransmissions;
            8'hbb:cfg_read=config_errors;
            default:begin end
        endcase
    end
    always @(posedge clk or posedge reset)begin
        if(reset)begin
            state<=WAIT_RX;busy<=0;operation_status<=ACCEPTED;completed_operations<=0;failed_operations<=0;
            retransmissions<=0;config_errors<=0;file_enabled<=0;cfg_index<=0;name_index<=0;cfg_offset<=0;
            capture_count<=0;request_length<=0;capture_bad<=0;send_index<=0;reply_length<=0;master_length<=0;
            initialized<=0;operator_mode<=0;status_dirty<=0;list_pending<=0;selection_committed<=0;
            selection_count<=0;completed_files<=0;current_file<=0;selection_length<=0;
            control_alive<=0;client_alive<=0;control_writing<=0;master_outstanding<=0;master_data<=0;
            read_alive<=0;read_list<=0;read_tid<=0;read_sport<=0;read_ip<=0;read_local<=0;read_vlid<=0;read_length<=0;
            read_timer<=0;read_retries<=0;control_retries<=0;
            generation<=0;control_tid<=16'hc000;client_tid<=16'hc001;control_block<=0;client_block<=0;
            init_sport<=0;control_sport<=0;client_peer<=0;owner_ip<=0;local_ip<=0;owner_vlid<=0;
            byte_clock<=0;control_timer<=0;client_timer<=0;operation_timer<=0;selection_timer<=0;status_timer<=0;
            retries<=0;status_counter<=0;file_offset<=0;object_offset<=0;object_length<=0;block_length<=0;client_timeout<=TIMEOUT_MS;
            build_index<=0;reply_after<=0;request_last<=0;
            reply_kind<=REPLY_ACK;reply_code<=0;reply_wait<=0;
            build_snapshot<=0;build_list_file<=0;build_position<=0;build_length<=0;build_prefix_length<=0;
            build_entry<=0;build_file<=0;build_char<=0;build_tail<=0;
            build_status_code<=ACCEPTED;build_status_counter<=0;build_description_length<=0;ratio_start<=0;build_count<=0;
            select_cursor<=0;select_count<=0;select_entry<=0;select_file<=0;select_char<=0;select_name_length<=0;seen<=0;
            dally_valid<=0;dally_started<=0;control_dally_slot<=0;dally_check_slot<=0;
            for(i=0;i<DALLY_SLOTS;i=i+1)begin
                dally_tid[i]<=0;dally_peer[i]<=0;dally_vlid[i]<=0;dally_block[i]<=0;
                dally_ip[i]<=0;dally_local[i]<=0;dally_timer[i]<=0;dally_length[i]<=0;
            end
            for(i=0;i<MAX_FILES;i=i+1)begin name_length[i]<=0;file_length[i]<=0;file_status[i]<=ACCEPTED;selected[i]<=0;end
        end else begin
            ratio_start<=0;
            if(tick_ms)begin
                byte_clock<=0;
                if(busy)begin operation_timer<=operation_timer+1'b1;selection_timer<=selection_timer+1'b1;status_timer<=status_timer+1'b1;end
                if(control_alive)control_timer<=control_timer+1'b1;
                if(master_outstanding)client_timer<=client_timer+1'b1;
                if(read_alive)read_timer<=read_timer+1'b1;
                for(i=0;i<DALLY_SLOTS;i=i+1)if(dally_valid[i] && dally_started[i])begin
                    // The global tick can occur just after the first ACK;
                    // allow one extra tick so retention is never shorter
                    // than DALLY_MS measured from that ACK handshake.
                    if(dally_timer[i]>=DALLY_MS)dally_valid[i]<=0;
                    else dally_timer[i]<=dally_timer[i]+1'b1;
                end
            end else byte_clock<=byte_clock+1'b1;
            if(!busy && control_alive && control_timer>=TIMEOUT_MS*(MAX_RETRIES+1))control_alive<=0;
            if(cfg_write && cfg_addr>=8'hb0 && cfg_addr<=8'hb6)begin
                if(busy || state!=WAIT_RX)config_errors<=config_errors+1'b1;
                else case(cfg_addr)
                    8'hb0:if(cfg_data<MAX_FILES)begin cfg_index<=cfg_data;name_index<=0;cfg_offset<=0;end else config_errors<=config_errors+1'b1;
                    8'hb1:if(cfg_data<FILE_BYTES)cfg_offset<=cfg_data;else config_errors<=config_errors+1'b1;
                    8'hb2:if(cfg_data<=FILE_BYTES)file_length[cfg_index]<=cfg_data;else config_errors<=config_errors+1'b1;
                    8'hb3:if(cfg_data<NAME_BYTES)name_index<=cfg_data;else config_errors<=config_errors+1'b1;
                    8'hb4:if(name_index<NAME_BYTES)begin
                        names[cfg_index*NAME_BYTES+name_index]<=cfg_data[7:0];
                        if(cfg_data[7:0]!=0)name_length[cfg_index]<=name_index+1'b1;
                        else if(name_index<name_length[cfg_index])name_length[cfg_index]<=name_index;
                        name_index<=name_index+1'b1;
                    end else config_errors<=config_errors+1'b1;
                    8'hb5:if(cfg_offset<FILE_BYTES)cfg_offset<=cfg_offset+1'b1;else config_errors<=config_errors+1'b1;
                    8'hb6:begin
                        bad=name_length[cfg_index]==0;
                        for(i=0;i<NAME_BYTES;i=i+1)if(i<name_length[cfg_index] &&
                            (names[cfg_index*NAME_BYTES+i]==0 || names[cfg_index*NAME_BYTES+i]=="/" ||
                             names[cfg_index*NAME_BYTES+i]==8'h5c || names[cfg_index*NAME_BYTES+i]==":" || names[cfg_index*NAME_BYTES+i]>127))bad=1;
                        if(name_length[cfg_index]==1 && names[cfg_index*NAME_BYTES]==".")bad=1;
                        if(name_length[cfg_index]==2 && names[cfg_index*NAME_BYTES]=="." && names[cfg_index*NAME_BYTES+1]==".")bad=1;
                        equal_name=name_length[cfg_index]>=TARGET_LEN+4;
                        for(i=0;i<16;i=i+1)if(i<TARGET_LEN && names[cfg_index*NAME_BYTES+i]!=target_byte(i))equal_name=0;
                        if(equal_name && names[cfg_index*NAME_BYTES+TARGET_LEN]==".")bad=1;
                        for(i=0;i<MAX_FILES;i=i+1)if(i!=cfg_index && file_enabled[i])begin
                            equal_name=name_length[cfg_index]==name_length[i];
                            for(j=0;j<NAME_BYTES;j=j+1)if(j<name_length[i] && names[cfg_index*NAME_BYTES+j]!=names[i*NAME_BYTES+j])equal_name=0;
                            if(equal_name)bad=1;
                        end
                        if(!cfg_data[0] || !bad)file_enabled[cfg_index]<=cfg_data[0];
                        else config_errors<=config_errors+1'b1;
                    end
                    default:begin end
                endcase
            end
            case(state)
                WAIT_RX:begin
                    if(s_valid)begin
                        request_sport<=s_src_port;request_dport<=s_dst_port;request_vlid<=s_vlid;
                        request_sip<=s_src_ip;request_dip<=s_dst_ip;
                        request_mem[0]<=s_data;request_last<=s_data;capture_count<=1;request_length<=s_length;
                        capture_bad<=!s_sop || s_length<2 || s_length>1471;
                        state<=s_eop?PARSE:CAPTURE;
                    end else if(busy && operation_status<16'h1000 && operation_status!=COMPLETE &&
                        (operation_timer>=OPERATION_TIMEOUT_MS || (!selection_committed && selection_timer>=SELECTION_TIMEOUT_MS)))begin
                        abort_operation(TARGET_ABORT);
                    end else if(busy && control_alive && !initialized && control_timer>=TIMEOUT_MS)begin
                        if(control_retries>=MAX_RETRIES)abort_operation(TARGET_ABORT);
                        else begin control_retries<=control_retries+1'b1;control_timer<=0;retransmissions<=retransmissions+1'b1;repeat_initialization();end
                    end else if(read_alive && read_timer>=TIMEOUT_MS)begin
                        if(read_retries>=MAX_RETRIES)read_alive<=0;
                        else begin read_retries<=read_retries+1'b1;read_timer<=0;retransmissions<=retransmissions+1'b1;repeat_snapshot();end
                    end else if(master_outstanding && client_timer>=client_timeout)begin
                        if(retries>=MAX_RETRIES)begin
                            if(master_kind==KIND_STATUS && operation_status>=16'h1000)begin busy<=0;failed_operations<=failed_operations+1'b1;master_outstanding<=0;client_alive<=0;end
                            else abort_operation(LOADER_ABORT);
                        end else begin retries<=retries+1'b1;retransmissions<=retransmissions+1'b1;client_timer<=0;send_index<=0;state<=SEND_MASTER;end
                    end else if(busy && initialized && !master_outstanding)begin
                        // Do not insert a periodic push between selection
                        // DATA blocks while the loader is waiting for ACKs.
                        if(status_dirty || (!control_writing && status_timer>=TIMEOUT_MS))begin
                            begin_object(0,0);object_offset<=0;status_dirty<=0;status_timer<=0;
                        end else if(list_pending)begin
                            begin_object(1,0);object_offset<=0;list_pending<=0;
                        end else if(selection_committed && completed_files<selection_count && operation_status<16'h1000)begin
                            current_file<=selected[completed_files];file_offset<=0;state<=START_FILE;
                        end
                    end
                end
                CAPTURE:if(s_valid)begin
                    if(capture_count<128)request_mem[capture_count[6:0]]<=s_data;
                    request_last<=s_data;
                    if(s_sop || capture_count>=1471)capture_bad<=1;
                    capture_count<=capture_count+1'b1;
                    if(s_eop)state<=PARSE;
                end
                PARSE:begin
                    state<=WAIT_RX;
                    opcode={request_mem[0],request_mem[1]};received_block={request_mem[2],request_mem[3]};
                    owner_matches=(busy || initialized) && request_sip==owner_ip && request_dip==local_ip && request_vlid==owner_vlid;
                    dally_free=-1;dally_match=-1;
                    for(i=0;i<DALLY_SLOTS;i=i+1)begin
                        if(!dally_valid[i] && dally_free<0)dally_free=i;
                        if(dally_valid[i] && request_dport==dally_tid[i])dally_match=i;
                    end
                    if(capture_bad || capture_count!=request_length)begin end
                    else if(dally_match>=0)begin
                        // Completed transfers are isolated from owner_ip and
                        // control_tid, which may already describe a new operation.
                        if(opcode==3 && request_length==dally_length[dally_match] &&
                            received_block==dally_block[dally_match] &&
                            request_sport==dally_peer[dally_match] && request_vlid==dally_vlid[dally_match] &&
                            request_sip==dally_ip[dally_match] && request_dip==dally_local[dally_match])begin
                            if(request_length==4)acknowledge(request_dport,received_block);
                            else begin dally_check_slot<=dally_match;build_index<=0;state<=DALLY_WAIT;end
                        end
                    end
                    else if(request_dport==69 && (opcode==1 || opcode==2))begin
                        // Every supported control name is TARGET_ID + .LNx.
                        // Inspect fixed header offsets instead of unrolling
                        // two whole-packet zero-terminator searches.
                        bad=request_length>512 || request_length<TARGET_LEN+13 ||
                            request_mem[TARGET_LEN+6]!=0 || request_mem[TARGET_LEN+7]!="o" ||
                            request_mem[TARGET_LEN+8]!="c" || request_mem[TARGET_LEN+9]!="t" ||
                            request_mem[TARGET_LEN+10]!="e" || request_mem[TARGET_LEN+11]!="t" ||
                            request_mem[TARGET_LEN+12]!=0;
                        equal_name=1;
                        for(i=0;i<16;i=i+1)if(i<TARGET_LEN && request_mem[i+2]!=target_byte(i))equal_name=0;
                        if(request_mem[TARGET_LEN+2]!=".")equal_name=0;
                        suffix0=request_mem[TARGET_LEN+3];suffix1=request_mem[TARGET_LEN+4];suffix2=request_mem[TARGET_LEN+5];
                        if(bad || !equal_name || suffix0!="L" || suffix1!="N")error_reply(69,4,0);
                        else if(opcode==1 && (suffix2=="D" || suffix2=="O"))begin
                            if(busy)begin
                                if(owner_matches && request_sport==init_sport && operator_mode==(suffix2=="O") && !initialized)begin
                                    reply_kind<=REPLY_INIT;
                                    start_reply(control_tid,14);
                                end else error_reply(69,0,1);
                            end else begin
                                busy<=1;initialized<=0;operator_mode<=suffix2=="O";selection_committed<=0;
                                owner_ip<=request_sip;local_ip<=request_dip;owner_vlid<=request_vlid;init_sport<=request_sport;
                                selection_count<=0;completed_files<=0;selection_length<=0;status_counter<=0;
                                status_dirty<=0;list_pending<=0;operation_timer<=0;selection_timer<=0;status_timer<=0;
                                generation<=allocate_tid(generation);control_tid<=allocate_tid(generation);
                                control_alive<=1;control_writing<=0;control_block<=1;control_sport<=request_sport;control_timer<=0;
                                control_retries<=0;
                                operation_status<=ACCEPTED;
                                for(i=0;i<MAX_FILES;i=i+1)file_status[i]<=ACCEPTED;
                                reply_kind<=REPLY_INIT;
                                start_reply(allocate_tid(generation),14);
                            end
                        end else if(!owner_matches)error_reply(69,2,0);
                        else if(opcode==2 && ((suffix2=="R" && !operator_mode)||(suffix2=="A" && operator_mode)))begin
                            if(!initialized || selection_committed)error_reply(69,0,1);
                            else if(control_writing && request_sport==control_sport)acknowledge(control_tid,control_block);
                            else if(control_writing)error_reply(69,0,1);
                            else if(dally_free<0)error_reply(69,0,1);
                            else begin
                                generation<=allocate_tid(generation);control_tid<=allocate_tid(generation);
                                control_dally_slot<=dally_free;
                                control_alive<=1;control_writing<=1;control_block<=0;control_sport<=request_sport;
                                selection_length<=0;control_timer<=0;acknowledge(allocate_tid(generation),0);
                            end
                        end else if(opcode==1 && (suffix2=="S" || (suffix2=="L" && operator_mode)))begin
                            if(read_alive)begin
                                if(request_sport==read_sport && request_sip==read_ip && request_dip==read_local && read_list==(suffix2=="L"))repeat_snapshot();
                                else error_reply(69,0,1);
                            end else begin_object(suffix2=="L",1);
                        end
                        else error_reply(69,2,0);
                    end else if(read_alive && request_dport==read_tid && request_sport==read_sport &&
                        request_sip==read_ip && request_dip==read_local && request_vlid==read_vlid)begin
                        if(opcode==4 && request_length==4 && received_block==1)read_alive<=0;
                        else if(opcode==5)read_alive<=0;
                    end else if(control_alive && owner_matches && request_dport==control_tid && request_sport==control_sport)begin
                        if(opcode==5 && busy && request_length>=5)abort_operation(incoming_abort(request_length));
                        else if(opcode==4 && request_length==4 && !control_writing && received_block==1 && !initialized)begin
                            initialized<=1;list_pending<=operator_mode;set_operation(ACCEPTED);control_timer<=0;
                        end else if(opcode==3 && control_writing && request_length>=4 && request_length<=516)begin
                            control_timer<=0;
                            if(received_block==control_block)acknowledge(control_tid,control_block);
                            else if(received_block!=next_block(control_block))acknowledge(control_tid,control_block);
                            else if(selection_length+request_length-4>1024 || selection_committed)error_reply(control_tid,3,0);
                            else begin
                                build_index<=0;reply_after<=received_block;control_block<=received_block;
                                if(request_length==4)state<=SELECT_FILES;
                                else state<=COPY_WAIT;
                            end
                        end
                    end else if(owner_matches && request_dport==client_tid && master_outstanding &&
                        (client_peer==0 || request_sport==client_peer))begin
                        if(opcode==4 && request_length==4 && received_block==client_block)begin
                            client_timer<=0;client_peer<=request_sport;
                            if(!master_data)prepare_data();
                            else if(block_length==512)begin
                                if(master_kind==KIND_FILE)file_offset=file_offset+512;else object_offset=object_offset+512;
                                prepare_data();
                            end else begin
                                master_outstanding<=0;client_alive<=0;
                                if(master_kind==KIND_FILE)begin
                                    file_status[current_file]<=COMPLETE;completed_files<=completed_files+1'b1;
                                    set_operation(completed_files+1==selection_count?COMPLETE:PROGRESS);
                                end else if(master_kind==KIND_STATUS && (operation_status==COMPLETE || operation_status>=16'h1000) && !status_dirty)begin
                                    busy<=0;control_writing<=0;
                                    if(operation_status==COMPLETE)completed_operations<=completed_operations+1'b1;
                                    else failed_operations<=failed_operations+1'b1;
                                end
                            end
                        end else if(opcode==5 && request_length>=5)begin
                            abort_code=LOADER_ABORT;
                            if(request_length==15 && request_mem[4]=="A" && request_mem[5]=="B" && request_mem[6]=="O" && request_mem[7]=="R" && request_mem[8]=="T" && request_mem[9]==":" && request_mem[14]==0 &&
                                is_hex(request_mem[10])&&is_hex(request_mem[11])&&is_hex(request_mem[12])&&is_hex(request_mem[13]))begin
                                abort_code={hex_value(request_mem[10]),hex_value(request_mem[11]),hex_value(request_mem[12]),hex_value(request_mem[13])};
                                if(abort_code!=TARGET_ABORT && abort_code!=OPERATOR_ABORT)abort_code=LOADER_ABORT;
                            end
                            if(!master_data && client_peer==0 && request_length>=11 &&
                                request_mem[2]==0 && request_mem[3]==0 && request_mem[4]=="W" && request_mem[5]=="A" && request_mem[6]=="I" && request_mem[7]=="T" && request_mem[8]==":" && request_last==0)begin
                                total=0;bad=0;
                                for(i=9;i<15;i=i+1)if(i<request_length-1)begin
                                    if(request_mem[i]<"0" || request_mem[i]>"9")bad=1;
                                    else total=total*10+request_mem[i]-"0";
                                end
                                if(request_length>15 || total<1 || total>65535 || bad || retries>=MAX_RETRIES)abort_operation(LOADER_ABORT);
                                else begin retries<=retries+1'b1;client_timeout<=total*1000;client_timer<=0;end
                            end else if(master_kind==KIND_STATUS && operation_status>=16'h1000)begin
                                busy<=0;failed_operations<=failed_operations+1'b1;master_outstanding<=0;client_alive<=0;
                            end else abort_operation(abort_code);
                        end
                    end
                end
                COPY_WAIT:state<=COPY_SELECTION;
                COPY_SELECTION:begin
                    // request_q was fetched in COPY_WAIT. selection_mem and
                    // the reserved dally slot each receive only this one byte.
                    if(build_index+5==request_length)begin
                        selection_length<=selection_length+request_length-4;
                        if(request_length<516)state<=SELECT_FILES;
                        else acknowledge(control_tid,reply_after);
                    end else begin build_index<=build_index+1'b1;state<=COPY_WAIT;end
                end
                SELECT_FILES:begin
                    bad=selection_length<8 ||
                        {selection_header[0],selection_header[1],selection_header[2],selection_header[3]}!=selection_length ||
                        selection_header[4]!="A" || selection_header[5]!="3";
                    n={selection_header[6],selection_header[7]};
                    if(n<1 || n>MAX_FILES)bad=1;
                    if(bad)begin abort_operation(DENIED);error_reply(control_tid,2,0);end
                    else begin
                        select_count<=n;select_entry<=0;select_cursor<=8;seen<=0;
                        state<=SELECT_LENGTH_WAIT;
                    end
                end
                SELECT_LENGTH_WAIT:state<=SELECT_LENGTH;
                SELECT_LENGTH:begin
                    if(select_cursor>=selection_length || selection_q<2 || selection_q>NAME_BYTES+1 ||
                        select_cursor+1+selection_q>selection_length)begin
                        abort_operation(DENIED);error_reply(control_tid,2,0);
                    end else begin
                        select_name_length<=selection_q-1'b1;select_cursor<=select_cursor+1'b1;
                        select_file<=0;select_char<=0;state<=SELECT_CANDIDATE;
                    end
                end
                SELECT_CANDIDATE:begin
                    if(select_file>=MAX_FILES)begin abort_operation(DENIED);error_reply(control_tid,2,0);end
                    else if(file_enabled[select_file] && name_length[select_file]==select_name_length)
                        state<=SELECT_CHAR_WAIT;
                    else select_file<=select_file+1'b1;
                end
                SELECT_CHAR_WAIT:state<=SELECT_CHAR;
                SELECT_CHAR:begin
                    if((select_char<select_name_length && selection_q!=names[select_file*NAME_BYTES+select_char]) ||
                        (select_char==select_name_length && selection_q!=0))begin
                        select_file<=select_file+1'b1;select_char<=0;state<=SELECT_CANDIDATE;
                    end else if(select_char==select_name_length)begin
                        if(seen[select_file])begin abort_operation(DENIED);error_reply(control_tid,2,0);end
                        else begin
                            selected[select_entry]<=select_file;seen[select_file]<=1;
                            select_cursor<=select_cursor+select_name_length+1'b1;
                            select_entry<=select_entry+1'b1;
                            state<=select_entry+1==select_count?SELECT_END_WAIT:SELECT_LENGTH_WAIT;
                        end
                    end else begin select_char<=select_char+1'b1;state<=SELECT_CHAR_WAIT;end
                end
                SELECT_END_WAIT:state<=SELECT_END;
                SELECT_END:begin
                    bad=operator_mode?(select_cursor!=selection_length):
                        (select_cursor>=selection_length || select_cursor+1+selection_q!=selection_length);
                    if(bad)begin abort_operation(DENIED);error_reply(control_tid,2,0);end
                    else begin
                        selection_count<=select_count;selection_committed<=1;
                        set_operation(PROGRESS);acknowledge(control_tid,reply_after);
                        control_writing<=0;control_alive<=0;
                        dally_valid[control_dally_slot]<=1;dally_started[control_dally_slot]<=0;
                        dally_timer[control_dally_slot]<=0;
                        dally_tid[control_dally_slot]<=control_tid;dally_peer[control_dally_slot]<=request_sport;
                        dally_ip[control_dally_slot]<=request_sip;dally_local[control_dally_slot]<=request_dip;
                        dally_vlid[control_dally_slot]<=request_vlid;dally_block[control_dally_slot]<=reply_after;
                        dally_length[control_dally_slot]<=request_length;
                    end
                end
                DALLY_WAIT:state<=CHECK_DALLY;
                CHECK_DALLY:begin
                    if(request_q!=dally_q)state<=WAIT_RX;
                    else if(build_index+5==request_length)acknowledge(request_dport,received_block);
                    else begin build_index<=build_index+1'b1;state<=DALLY_WAIT;end
                end
                BUILD_PREFIX:begin
                    build_position<=build_position+1'b1;
                    if(build_position+1==build_prefix_length)state<=BUILD_ENTRY;
                end
                BUILD_ENTRY:begin
                    if(build_entry>=(build_list_file?MAX_FILES:build_count))begin
                        if(build_snapshot)begin send_index<=0;state<=SEND_REPLY;end
                        else build_wrq(build_list_file?KIND_LIST:KIND_STATUS);
                    end else if(build_list_file && !file_enabled[build_entry])build_entry<=build_entry+1'b1;
                    else begin
                        build_file<=build_list_file?build_entry:selected[build_entry];
                        build_char<=0;build_tail<=0;state<=BUILD_NAME_LENGTH;
                    end
                end
                BUILD_NAME_LENGTH:begin
                    build_position<=build_position+1'b1;
                    state<=name_length[build_file]==0?BUILD_TRAILER:BUILD_NAME;
                end
                BUILD_NAME:begin
                    build_position<=build_position+1'b1;
                    if(build_char+1==name_length[build_file])state<=BUILD_TRAILER;
                    else build_char<=build_char+1'b1;
                end
                BUILD_TRAILER:begin
                    build_position<=build_position+1'b1;
                    if(build_tail==(build_list_file?2:4))begin
                        build_entry<=build_entry+1'b1;state<=BUILD_ENTRY;
                    end else build_tail<=build_tail+1'b1;
                end
                START_FILE:begin build_wrq(KIND_FILE);file_status[current_file]<=PROGRESS;end
                SEND_MASTER:if(m_ready)begin
                    if(m_eop)begin state<=WAIT_RX;client_timer<=0;end else send_index<=send_index+1'b1;
                end
                SEND_REPLY:if(m_ready)begin
                    if(m_eop)begin
                        state<=WAIT_RX;
                        // Start the bounded retention interval only once the
                        // first final ACK has left this ready/valid interface.
                        for(i=0;i<DALLY_SLOTS;i=i+1)
                            if(dally_valid[i] && !dally_started[i] && reply_source==dally_tid[i])begin
                                dally_started[i]<=1;dally_timer[i]<=0;
                            end
                    end else send_index<=send_index+1'b1;
                end
                default:state<=WAIT_RX;
            endcase
        end
    end
endmodule

// Exact floor(completed*100/selected), retaining the former 8-bit result.
// The bounded, shift/subtract datapath avoids a long combinational divider.
module afdx_load_percent(
    input wire clk,reset,start,complete,
    input wire [7:0] completed,selected,
    output reg [7:0] value
);
    reg [14:0] dividend;
    reg [8:0] remainder;
    reg [7:0] divisor;
    reg [3:0] steps;
    wire [8:0] trial={remainder[7:0],dividend[14]};
    wire quotient_bit=trial>={1'b0,divisor};
    wire [14:0] next_dividend={dividend[13:0],quotient_bit};
    always @(posedge clk or posedge reset)begin
        if(reset)begin value<=0;dividend<=0;remainder<=0;divisor<=0;steps<=0;end
        else if(start)begin
            value<=complete?8'd100:8'd0;
            steps<=complete || selected==0?4'd0:4'd15;
            dividend<=completed*15'd100;remainder<=0;divisor<=selected;
        end else if(steps!=0)begin
            dividend<=next_dividend;
            remainder<=quotient_bit?trial-{1'b0,divisor}:trial;
            steps<=steps-1'b1;
            if(steps==1)value<=next_dividend[7:0];
        end
    end
endmodule
