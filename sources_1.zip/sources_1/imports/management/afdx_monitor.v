`timescale 1ns/1ns
// Live counters remain at 20..2b. A coherent 16-word snapshot updates every
// 100 ms at 80..8f; 6c sequence, 6d timestamp, 6e period, 6f capabilities.
// Event FIFO: 70 write-one pop, 71 count, 72 lost events, 73 capacity,
// 74..77 {timestamp, cause bits, TX count, RX count}. Peek settles one clock
// after a head change. A full FIFO preserves old events and counts losses.
module afdx_monitor #(
    parameter CLK_FREQ=12_500_000,EVENT_DEPTH=16
)(
    input wire clk,reset,input wire [31:0] timestamp,
    input wire [511:0] live_stats,input wire [7:0] mac_faults,
    input wire [7:0] bus_addr,input wire bus_write,input wire [31:0] bus_wdata,
    output reg [31:0] bus_rdata,output wire bus_selected
);
    localparam PERIOD=(CLK_FREQ/10)<1?1:CLK_FREQ/10;
    localparam CW=PERIOD<2?1:$clog2(PERIOD);
    localparam AW=EVENT_DEPTH<2?1:$clog2(EVENT_DEPTH);
    reg [CW-1:0] divider;
    reg [31:0] snapshot[0:15];reg [511:0] previous_stats;
    reg [31:0] snapshot_sequence,snapshot_time,lost_events;
    reg [7:0] previous_mac_faults;
    (* ramstyle="no_rw_check" *) reg [127:0] events[0:EVENT_DEPTH-1];
    reg [127:0] event_head;
    reg [AW-1:0] wr_ptr,rd_ptr;
    reg [AW:0] event_count;
    reg [31:0] cause;
    integer j,k;
    always @(*)begin
        cause=0;
        // Successful TX/RX and expected redundant copies are not faults.
        for(j=2;j<16;j=j+1)if(j!=4)
            cause[j]=live_stats[j*32+:32]!=previous_stats[j*32+:32];
        cause[23:16]=previous_mac_faults;
    end
    wire pop=bus_write && bus_addr==8'h70 && bus_wdata[0] && event_count!=0;
    wire present=|cause;
    wire push=present && (event_count<EVENT_DEPTH || pop);
    wire [AW-1:0] next_rd=rd_ptr==EVENT_DEPTH-1?0:rd_ptr+1'b1;
    always @(posedge clk)begin
        if(!reset && push)events[wr_ptr]<={timestamp,cause,live_stats[31:0],live_stats[63:32]};
        event_head<=events[pop?next_rd:rd_ptr];
    end
    always @(posedge clk or posedge reset)begin
        if(reset)begin
            divider<=0;snapshot_sequence<=0;snapshot_time<=0;previous_stats<=0;previous_mac_faults<=0;
            wr_ptr<=0;rd_ptr<=0;event_count<=0;lost_events<=0;
            for(k=0;k<16;k=k+1)snapshot[k]<=0;
        end else begin
            previous_stats<=live_stats;previous_mac_faults<=mac_faults;
            if(divider==PERIOD-1)begin
                divider<=0;snapshot_sequence<=snapshot_sequence+1'b1;snapshot_time<=timestamp;
                for(k=0;k<16;k=k+1)snapshot[k]<=live_stats[k*32+:32];
            end else divider<=divider+1'b1;
            if(push)wr_ptr<=wr_ptr==EVENT_DEPTH-1?0:wr_ptr+1'b1;
            if(pop)rd_ptr<=next_rd;
            if(present && !push)lost_events<=lost_events+1'b1;
            case({push,pop})
                2'b10:event_count<=event_count+1'b1;
                2'b01:event_count<=event_count-1'b1;
                default:begin end
            endcase
        end
    end
    assign bus_selected=(bus_addr>=8'h6c && bus_addr<=8'h77) || (bus_addr>=8'h80 && bus_addr<=8'h8f);
    always @(*)begin
        bus_rdata=0;
        if(bus_addr>=8'h80 && bus_addr<=8'h8f)bus_rdata=snapshot[bus_addr[3:0]];
        else case(bus_addr)
            8'h6c:bus_rdata=snapshot_sequence;
            8'h6d:bus_rdata=snapshot_time;
            8'h6e:bus_rdata=100;
            8'h6f:bus_rdata=32'h00000003; // snapshot and timestamped event FIFO
            8'h71:bus_rdata=event_count;
            8'h72:bus_rdata=lost_events;
            8'h73:bus_rdata=EVENT_DEPTH;
            8'h74:bus_rdata=event_count!=0?event_head[127:96]:0;
            8'h75:bus_rdata=event_count!=0?event_head[95:64]:0;
            8'h76:bus_rdata=event_count!=0?event_head[63:32]:0;
            8'h77:bus_rdata=event_count!=0?event_head[31:0]:0;
            default:begin end
        endcase
    end
endmodule
