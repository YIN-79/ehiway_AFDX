`timescale 1ns/1ns
// Bounded SNMPv2c agent: GET/GETNEXT, and validated single-register SET.
// UDP/IP/FCS validation is performed by the MAC before this payload interface.
// Public read community, private write community; experimental OID tree:
// 1.3.6.1.3.664.1.<register>.0.  System descr/name/uptime are also readable.
// Request/reply RAMs use synchronous reads; frame output obeys ready/valid.
module afdx_snmp_service #(
    parameter TX_VL_NUM=128,RX_VL_NUM=4096,
    parameter MANAGEMENT_VL=TX_VL_NUM-1
)(
    input wire clk,reset,
    input wire [7:0] s_data,input wire s_valid,output wire s_ready,
    input wire s_sop,s_eop,input wire [15:0] s_length,
    input wire [15:0] s_src_port,s_dst_port,input wire [31:0] s_src_ip,s_dst_ip,
    output wire [7:0] m_data,output wire m_valid,input wire m_ready,
    output wire m_sop,m_eop,output wire [15:0] m_length,m_vlid,m_src_port,m_dst_port,
    output wire [31:0] m_src_ip,m_dst_ip,
    output wire bus_request,bus_write,output wire [7:0] bus_addr,
    output wire [31:0] bus_wdata,input wire bus_grant,input wire [31:0] bus_rdata,
    output reg [31:0] stat_requests,stat_responses,stat_bad_requests
);
    localparam IDLE=0,CAPTURE=1,BAD=2,BYTE_ADDR=3,BYTE_WAIT=4,BYTE_USE=5,
        H_TAG=6,H_LEN=7,H_HI=8,H_LO=9,OUTER=10,VERSION=11,VERSION_VALUE=12,
        COMMUNITY=13,COMMUNITY_VALUE=14,PDU=15,INT_HEADER=16,INT_VALUE=17,
        LIST=18,HEADER_BUILD=19,ENTRY=20,OID_HEADER=21,OID_VALUE=22,
        VALUE_HEADER=23,VALUE_READ=24,RESOLVE=25,SCAN_START=26,SCAN_COMPARE=27,
        READ_MIB=28,WRITE_MIB=29,PREPARE_ENTRY=30,ENTRY_HEADER=31,ENTRY_OID=32,
        ENTRY_TAG=33,ENTRY_LENGTH=34,ENTRY_VALUE=35,ENTRY_DONE=36,
        PATCH=37,PRELOAD=38,SEND=39,NEXT_ENTRY=40,VERIFY_WRITE=41;
    reg [5:0] state,byte_return,header_return;
    (* ramstyle="M4K, no_rw_check" *) reg [7:0] request_mem[0:2047];
    (* ramstyle="M4K, no_rw_check" *) reg [7:0] response_mem[0:2047];
    reg [7:0] request_q,response_q,current_byte;
    reg [10:0] request_addr,cursor,capture_count,request_length,declared_length;
    reg capture_bad;
    reg [10:0] write_ptr,send_ptr,response_length,entry_end,list_end;
    reg [7:0] tag,op,length_hi;
    reg [15:0] value_length,header_end;
    reg [7:0] oid[0:31];reg [5:0] oid_length,oid_index;
    reg oid_component_start;
    reg [31:0] integer_value,request_id;
    reg [2:0] request_id_length;
    reg [2:0] integer_index;reg [15:0] bytes_left;
    reg [3:0] community_length,community_index;
    reg community_public,community_private;
    reg [7:0] entry_count,error_status,error_index;
    reg too_big;
    reg [7:0] value_tag;
    reg [10:0] value_start;
    reg [39:0] set_value;
    reg set_negative;
    reg [8:0] scan_object;
    reg [5:0] scan_position;
    // -1 uses the received OID, 0..2 system OIDs, 3..258 register OIDs.
    reg signed [9:0] reply_object;
    reg [7:0] register_addr,reply_tag;
    reg [31:0] reply_value;
    reg [10:0] reply_value_length;
    reg [5:0] reply_oid_length;
    reg [10:0] emit_index;
    reg [3:0] patch_index;
    reg [15:0] peer_port;reg [31:0] peer_ip,local_ip;
    // Exact unsigned division by 10 for all 32-bit uptime values. A constant
    // reciprocal multiplication avoids a serial chain of divider logic.
    (* multstyle="dsp" *) wire [63:0] uptime_product=bus_rdata*32'hcccccccd;
    wire [31:0] uptime_centiseconds=uptime_product>>35;

    function [7:0] community_char;
        input private_name;input [3:0] index;
        begin
            if(private_name)community_char=(56'h70726976617465 >> ((6-index)*8));
            else community_char=(48'h7075626c6963 >> ((5-index)*8));
        end
    endfunction
    function readable;
        input [7:0] a;
        begin readable=(a<32 && (a>>1)<TX_VL_NUM) || (a>=8'h20 && a<=8'h2b) ||
            (a>=8'h40 && a<=8'h47) || a==8'h48 || a==8'h49 || a==8'h4a ||
            (a>=8'h60 && a<=8'h63) || (a>=8'h6c && a<=8'h77) ||
            (a>=8'h80 && a<=8'h8f) || (a>=8'h90 && a<=8'h92);end
    endfunction
    function writable;
        input [7:0] a;
        begin writable=(a<32 && (a>>1)<TX_VL_NUM) ||
            (a>=8'h40 && a<=8'h44) || a==8'h60 || a==8'h70;end
    endfunction
    function write_value_good;
        input [7:0] a;input [31:0] v;
        reg bag,maximum;
        begin
            bag=v>=1 && v<=128 && (v&(v-1))==0;
            maximum=v>=64 && v<=1518;
            if(a<32)write_value_good=a[0]?maximum:bag;
            else case(a)
                8'h40:write_value_good=v<TX_VL_NUM;
                8'h41:write_value_good=bag;
                8'h42,8'h44:write_value_good=maximum;
                8'h43:write_value_good=v<RX_VL_NUM;
                8'h70:write_value_good=v==1;
                default:write_value_good=1;
            endcase
        end
    endfunction
    function [5:0] object_length;
        input [8:0] object_id;
        begin object_length=object_id<3?8:((object_id-3)<128?9:10);end
    endfunction
    function [7:0] object_byte;
        input [8:0] object_id;input [5:0] index;
        reg [7:0] a;
        begin
            a=object_id-3;object_byte=0;
            if(object_id<3)case(index)
                0:object_byte=8'h2b;1:object_byte=6;2:object_byte=1;
                3:object_byte=2;4:object_byte=1;5:object_byte=1;
                6:object_byte=object_id==0?1:(object_id==1?3:5);
                default:object_byte=0;
            endcase else case(index)
                0:object_byte=8'h2b;1:object_byte=6;2:object_byte=1;3:object_byte=3;
                4:object_byte=8'h85;5:object_byte=8'h18;6:object_byte=1;
                7:object_byte=a<128?a:8'h81;
                8:object_byte=a<128?0:{1'b0,a[6:0]};default:object_byte=0;
            endcase
        end
    endfunction
    function [2:0] unsigned_length;
        input [31:0] v;
        begin
            if(v[31])unsigned_length=5;
            else if(|v[30:23])unsigned_length=4;
            else if(|v[22:15])unsigned_length=3;
            else if(|v[14:7])unsigned_length=2;
            else unsigned_length=1;
        end
    endfunction
    wire private_prefix=oid_length>=9 && oid[0]==8'h2b && oid[1]==6 && oid[2]==1 &&
        oid[3]==3 && oid[4]==8'h85 && oid[5]==8'h18 && oid[6]==1;
    wire private_short=private_prefix && oid_length==9 && !oid[7][7] && oid[8]==0;
    wire private_long=private_prefix && oid_length==10 && oid[7]==8'h81 && !oid[8][7] && oid[9]==0;
    wire [7:0] oid_address=private_short?oid[7]:{1'b1,oid[8][6:0]};
    wire system_prefix=oid_length==8 && oid[0]==8'h2b && oid[1]==6 && oid[2]==1 &&
        oid[3]==2 && oid[4]==1 && oid[5]==1 && oid[7]==0;
    wire [10:0] pdu_position=11'd9+community_length;
    wire [10:0] id_position=pdu_position+4;
    wire [10:0] status_position=id_position+2+request_id_length;
    wire [10:0] index_position=status_position+3;
    wire [10:0] list_position=index_position+3;
    wire [10:0] first_entry_position=list_position+4;
    wire [1:0] value_length_extra=reply_value_length>=128?2:0;
    wire [15:0] encoded_entry_length=reply_oid_length+reply_value_length+4+value_length_extra;
    wire [10:0] reply_prefetch=send_ptr+((m_valid && m_ready && !m_eop)?11'd1:11'd0);
    assign s_ready=!reset && (state==IDLE || state==CAPTURE);
    assign m_valid=!reset && state==SEND;
    assign m_data=response_q;
    assign m_sop=send_ptr==0;assign m_eop=send_ptr+1==response_length;
    assign m_length=response_length;assign m_vlid=MANAGEMENT_VL;
    assign m_src_port=161;assign m_dst_port=peer_port;
    assign m_src_ip=local_ip;assign m_dst_ip=peer_ip;
    assign bus_request=state==READ_MIB || state==WRITE_MIB || state==VERIFY_WRITE;
    assign bus_write=state==WRITE_MIB;assign bus_addr=register_addr;
    assign bus_wdata=set_value[31:0];
    always @(posedge clk)begin
        if(!reset && s_valid && s_ready && capture_count<1471)
            request_mem[state==IDLE?11'd0:capture_count]<=s_data;
        request_q<=request_mem[request_addr];
        response_q<=response_mem[reply_prefetch];
    end

    task byte_read;
        input [5:0] destination;
        begin byte_return<=destination;state<=BYTE_ADDR;end
    endtask
    task header_read;
        input [5:0] destination;
        begin header_return<=destination;byte_read(H_TAG);end
    endtask

    reg response_write;
    reg [10:0] response_address;
    reg [7:0] response_byte;
    always @(*)begin
        response_write=0;response_address=write_ptr;response_byte=0;
        case(state)
            HEADER_BUILD:begin
                response_write=1;
                if(write_ptr==0)response_byte=8'h30;
                else if(write_ptr==1)response_byte=8'h82;
                else if(write_ptr==4)response_byte=2;
                else if(write_ptr==5 || write_ptr==6)response_byte=1;
                else if(write_ptr==7)response_byte=4;
                else if(write_ptr==8)response_byte=community_length;
                else if(write_ptr>=9 && write_ptr<pdu_position)
                    response_byte=community_char(community_private,write_ptr-9);
                else if(write_ptr==pdu_position)response_byte=8'ha2;
                else if(write_ptr==pdu_position+1)response_byte=8'h82;
                else if(write_ptr==id_position)response_byte=2;
                else if(write_ptr==id_position+1)response_byte=request_id_length;
                else if(write_ptr>=id_position+2 && write_ptr<status_position)
                    response_byte=request_id >> (8*(status_position-1-write_ptr));
                else if(write_ptr==status_position || write_ptr==index_position)response_byte=2;
                else if(write_ptr==status_position+1 || write_ptr==index_position+1)response_byte=1;
                else if(write_ptr==list_position)response_byte=8'h30;
                else if(write_ptr==list_position+1)response_byte=8'h82;
            end
            ENTRY_HEADER:begin
                response_write=1;
                case(emit_index)
                    0:response_byte=8'h30;1:response_byte=8'h82;
                    2:response_byte=encoded_entry_length[15:8];3:response_byte=encoded_entry_length[7:0];
                    4:response_byte=6;5:response_byte=reply_oid_length;
                endcase
            end
            ENTRY_OID:begin
                response_write=1;
                response_byte=reply_object<0?oid[emit_index[4:0]]:object_byte(reply_object,emit_index);
            end
            ENTRY_TAG:begin response_write=1;response_byte=reply_tag;end
            ENTRY_LENGTH:begin
                response_write=1;
                if(reply_value_length<128)response_byte=reply_value_length;
                else if(emit_index==0)response_byte=8'h82;
                else if(emit_index==1)response_byte=reply_value_length>>8;
                else response_byte=reply_value_length;
            end
            ENTRY_VALUE:begin
                response_write=1;
                if(op==8'ha3)response_byte=current_byte;
                else if(reply_object==0)response_byte=144'h46504741204146445820656e64706f696e74 >> (8*(17-emit_index));
                else if(reply_object==2)response_byte=120'h414644585f656e645f73797374656d >> (8*(14-emit_index));
                else if(reply_value_length==5 && emit_index==0)response_byte=0;
                else response_byte=reply_value >> (8*(reply_value_length-1-emit_index));
            end
            PATCH:begin
                response_write=1;
                case(patch_index)
                    0:begin response_address=2;response_byte=(response_length-4)>>8;end
                    1:begin response_address=3;response_byte=response_length-4;end
                    2:begin response_address=pdu_position+2;response_byte=(response_length-pdu_position-4)>>8;end
                    3:begin response_address=pdu_position+3;response_byte=response_length-pdu_position-4;end
                    4:begin response_address=list_position+2;response_byte=(response_length-first_entry_position)>>8;end
                    5:begin response_address=list_position+3;response_byte=response_length-first_entry_position;end
                    6:begin response_address=status_position+2;response_byte=too_big?1:error_status;end
                    7:begin response_address=index_position+2;response_byte=too_big?0:error_index;end
                endcase
            end
        endcase
    end
    always @(posedge clk)if(response_write && !reset)response_mem[response_address]<=response_byte;

    // Shared bounded BER header reader; constructed length bounds are checked
    // against their parent at each grammar step, before any register write.
    always @(posedge clk or posedge reset)begin
        if(reset)begin
            state<=IDLE;capture_count<=0;capture_bad<=0;cursor<=0;request_addr<=0;
            declared_length<=0;request_length<=0;write_ptr<=0;send_ptr<=0;response_length<=0;
            byte_return<=0;header_return<=0;current_byte<=0;tag<=0;value_length<=0;header_end<=0;length_hi<=0;
            community_length<=0;community_index<=0;community_public<=0;community_private<=0;
            integer_value<=0;integer_index<=0;request_id<=0;request_id_length<=1;bytes_left<=0;
            entry_end<=0;list_end<=0;oid_length<=0;oid_index<=0;oid_component_start<=1;entry_count<=0;op<=0;
            error_status<=0;error_index<=0;too_big<=0;value_tag<=0;value_start<=0;set_value<=0;set_negative<=0;
            scan_object<=0;scan_position<=0;reply_object<=-1;register_addr<=0;reply_tag<=0;reply_value<=0;
            reply_value_length<=0;reply_oid_length<=0;emit_index<=0;patch_index<=0;
            peer_port<=0;peer_ip<=0;local_ip<=0;
            stat_requests<=0;stat_responses<=0;stat_bad_requests<=0;
        end else case(state)
            IDLE:if(s_valid)begin
                capture_count<=1;declared_length<=s_length;
                peer_port<=s_src_port;peer_ip<=s_src_ip;local_ip<=s_dst_ip;
                capture_bad<=!s_sop || s_length==0 || s_length>1471 || s_dst_port!=161;
                if(s_eop)state<=BAD;else state<=CAPTURE;
            end
            CAPTURE:if(s_valid)begin
                if(s_sop || capture_count>=1471)capture_bad<=1;
                if(capture_count<2047)capture_count<=capture_count+1'b1;
                if(s_eop)begin
                    request_length<=capture_count+1'b1;capture_count<=0;cursor<=0;
                    error_status<=0;error_index<=0;too_big<=0;entry_count<=0;
                    if(capture_bad || s_sop || capture_count+1!=declared_length || capture_count>=1471)state<=BAD;
                    else begin stat_requests<=stat_requests+1'b1;header_read(OUTER);end
                end
            end
            BAD:begin stat_bad_requests<=stat_bad_requests+1'b1;state<=IDLE;capture_count<=0;end
            BYTE_ADDR:if(cursor>=request_length)state<=BAD;
                else begin request_addr<=cursor;state<=BYTE_WAIT;end
            BYTE_WAIT:state<=BYTE_USE;
            BYTE_USE:begin current_byte<=request_q;cursor<=cursor+1'b1;state<=byte_return;end
            H_TAG:begin tag<=current_byte;byte_read(H_LEN);end
            H_LEN:begin
                if(!current_byte[7])begin
                    value_length<=current_byte;header_end<=cursor+current_byte;
                    if(cursor+current_byte>request_length)state<=BAD;else state<=header_return;
                end else if(current_byte==8'h81)begin length_hi<=0;byte_read(H_LO);end
                else if(current_byte==8'h82)byte_read(H_HI);else state<=BAD;
            end
            H_HI:begin length_hi<=current_byte;byte_read(H_LO);end
            H_LO:begin
                value_length<={length_hi,current_byte};header_end<=cursor+{length_hi,current_byte};
                if(cursor+{length_hi,current_byte}>request_length)state<=BAD;else state<=header_return;
            end
            OUTER:if(tag!=8'h30 || header_end!=request_length)state<=BAD;else header_read(VERSION);
            VERSION:if(tag!=2 || value_length!=1)state<=BAD;else byte_read(VERSION_VALUE);
            VERSION_VALUE:if(current_byte!=1)state<=BAD;else header_read(COMMUNITY);
            COMMUNITY:if(tag!=4 || (value_length!=6 && value_length!=7))state<=BAD;
                else begin
                    community_length<=value_length;community_index<=0;
                    community_public<=value_length==6;community_private<=value_length==7;byte_read(COMMUNITY_VALUE);
                end
            COMMUNITY_VALUE:begin
                if(current_byte!=community_char(0,community_index))community_public<=0;
                if(current_byte!=community_char(1,community_index))community_private<=0;
                if(community_index+1==community_length)header_read(PDU);
                else begin community_index<=community_index+1'b1;byte_read(COMMUNITY_VALUE);end
            end
            PDU:if((!community_public && !community_private) ||
                    (tag!=8'ha0 && tag!=8'ha1 && tag!=8'ha3) || header_end!=request_length)state<=BAD;
                else begin op<=tag;integer_index<=0;header_read(INT_HEADER);end
            INT_HEADER:if(tag!=2 || value_length==0 || value_length>4)state<=BAD;
                else begin
                    integer_value<=0;bytes_left<=value_length;
                    if(integer_index==0)request_id_length<=value_length;
                    byte_read(INT_VALUE);
                end
            INT_VALUE:begin
                integer_value<={integer_value[23:0],current_byte};bytes_left<=bytes_left-1'b1;
                if(bytes_left==1)begin
                    if(integer_index==0)request_id<={integer_value[23:0],current_byte};
                    if(integer_index==2)header_read(LIST);
                    else begin integer_index<=integer_index+1'b1;header_read(INT_HEADER);end
                end else byte_read(INT_VALUE);
            end
            LIST:if(tag!=8'h30 || header_end!=request_length)state<=BAD;
                else begin list_end<=header_end;write_ptr<=0;state<=HEADER_BUILD;end
            HEADER_BUILD:begin
                write_ptr<=write_ptr+1'b1;
                if(write_ptr+1==first_entry_position)state<=NEXT_ENTRY;
            end
            NEXT_ENTRY:if(cursor==list_end)begin
                    response_length<=too_big?first_entry_position:write_ptr;patch_index<=0;state<=PATCH;
                end else if(cursor>list_end || entry_count==127)state<=BAD;
                else header_read(ENTRY);
            ENTRY:if(tag!=8'h30 || header_end>list_end)state<=BAD;
                else begin entry_end<=header_end;entry_count<=entry_count+1'b1;header_read(OID_HEADER);end
            OID_HEADER:if(tag!=6 || value_length==0 || value_length>32 || header_end>=entry_end)state<=BAD;
                else begin oid_length<=value_length;oid_index<=0;oid_component_start<=1;byte_read(OID_VALUE);end
            OID_VALUE:begin
                oid[oid_index]<=current_byte;
                oid_component_start<=!current_byte[7];
                if((oid_component_start && current_byte==8'h80) || (oid_index+1==oid_length && current_byte[7]))state<=BAD;
                else if(oid_index+1==oid_length)header_read(VALUE_HEADER);
                else begin oid_index<=oid_index+1'b1;byte_read(OID_VALUE);end
            end
            VALUE_HEADER:if(header_end!=entry_end || value_length>1471 ||
                    (op!=8'ha3 && (tag!=5 || value_length!=0)))state<=BAD;
                else begin
                    value_tag<=tag;value_start<=cursor;bytes_left<=value_length;set_value<=0;set_negative<=0;
                    if(op==8'ha3 && value_length!=0 && value_length<=5)byte_read(VALUE_READ);
                    else begin cursor<=header_end;state<=RESOLVE;end
                end
            VALUE_READ:begin
                set_value<={set_value[31:0],current_byte};
                if(bytes_left==value_length)set_negative<=current_byte[7] && value_tag==2;
                bytes_left<=bytes_left-1'b1;
                if(bytes_left==1)state<=RESOLVE;else byte_read(VALUE_READ);
            end
            RESOLVE:begin
                reply_object<=-1;reply_oid_length<=oid_length;reply_tag<=8'h80;reply_value_length<=0;
                if(op==8'ha3)begin
                    reply_tag<=value_tag;reply_value_length<=value_length;
                    if(error_status!=0)state<=PREPARE_ENTRY;
                    else if(entry_end!=list_end || entry_count!=1)begin error_status<=13;error_index<=1;state<=PREPARE_ENTRY;end
                    else if(!community_private)begin error_status<=16;error_index<=1;state<=PREPARE_ENTRY;end
                    else if(!(private_short || private_long) || !writable(oid_address))begin error_status<=17;error_index<=1;state<=PREPARE_ENTRY;end
                    else if((value_tag!=2 && value_tag!=8'h42) || value_length==0 || value_length>5)begin error_status<=7;error_index<=1;state<=PREPARE_ENTRY;end
                    else if(set_negative || set_value[39:32]!=0 || !write_value_good(oid_address,set_value[31:0]))begin error_status<=10;error_index<=1;state<=PREPARE_ENTRY;end
                    else begin register_addr<=oid_address;state<=WRITE_MIB;end
                end else if(op==8'ha1)begin scan_object<=0;state<=SCAN_START;end
                else if(system_prefix && (oid[6]==1 || oid[6]==3 || oid[6]==5))begin
                    reply_object<=oid[6]==1?0:(oid[6]==3?1:2);
                    if(oid[6]==3)begin register_addr<=8'h63;state<=READ_MIB;end
                    else begin reply_tag<=4;reply_value_length<=oid[6]==1?18:15;state<=PREPARE_ENTRY;end
                end else if((private_short || private_long) && readable(oid_address))begin
                    reply_object<=oid_address+10'd3;register_addr<=oid_address;state<=READ_MIB;
                end else state<=PREPARE_ENTRY;
            end
            SCAN_START:if(scan_object==259)begin reply_tag<=8'h82;state<=PREPARE_ENTRY;end
                else if(scan_object>=3 && !readable(scan_object-3))scan_object<=scan_object+1'b1;
                else begin scan_position<=0;state<=SCAN_COMPARE;end
            SCAN_COMPARE:begin
                if(scan_position==object_length(scan_object) ||
                    (scan_position<oid_length && object_byte(scan_object,scan_position)<oid[scan_position]))begin
                    scan_object<=scan_object+1'b1;state<=SCAN_START;
                end else if(scan_position==oid_length || object_byte(scan_object,scan_position)>oid[scan_position])begin
                    reply_object<=scan_object;reply_oid_length<=object_length(scan_object);
                    if(scan_object==0 || scan_object==2)begin
                        reply_tag<=4;reply_value_length<=scan_object==0?18:15;state<=PREPARE_ENTRY;
                    end else begin register_addr<=scan_object==1?8'h63:scan_object-3;state<=READ_MIB;end
                end else scan_position<=scan_position+1'b1;
            end
            READ_MIB:if(bus_grant)begin
                reply_value<=reply_object==1?uptime_centiseconds:bus_rdata;
                reply_tag<=reply_object==1?8'h43:8'h42;
                reply_value_length<=unsigned_length(reply_object==1?uptime_centiseconds:bus_rdata);
                state<=PREPARE_ENTRY;
            end
            WRITE_MIB:if(bus_grant)begin
                // TX calendar parameters may be locked by mib_reg. Report a
                // rejected SET instead of acknowledging a value never applied.
                if(register_addr<8'h20 || register_addr==8'h41 || register_addr==8'h42)
                    state<=VERIFY_WRITE;
                else state<=PREPARE_ENTRY;
            end
            VERIFY_WRITE:if(bus_grant)begin
                if(bus_rdata!=set_value[31:0])begin error_status<=12;error_index<=1;end
                state<=PREPARE_ENTRY;
            end
            PREPARE_ENTRY:begin
                emit_index<=0;
                if(too_big || write_ptr+reply_oid_length+reply_value_length+8+value_length_extra>1471)begin too_big<=1;state<=NEXT_ENTRY;end
                else state<=ENTRY_HEADER;
            end
            ENTRY_HEADER:begin
                write_ptr<=write_ptr+1'b1;
                if(emit_index==5)begin emit_index<=0;state<=ENTRY_OID;end else emit_index<=emit_index+1'b1;
            end
            ENTRY_OID:begin
                write_ptr<=write_ptr+1'b1;
                if(emit_index+1==reply_oid_length)begin emit_index<=0;state<=ENTRY_TAG;end else emit_index<=emit_index+1'b1;
            end
            ENTRY_TAG:begin write_ptr<=write_ptr+1'b1;state<=ENTRY_LENGTH;end
            ENTRY_LENGTH:begin
                write_ptr<=write_ptr+1'b1;
                if(reply_value_length>=128 && emit_index<2)emit_index<=emit_index+1'b1;
                else begin
                    emit_index<=0;
                    if(reply_value_length==0)state<=NEXT_ENTRY;
                    else if(op==8'ha3)begin cursor<=value_start;byte_read(ENTRY_VALUE);end
                    else state<=ENTRY_VALUE;
                end
            end
            ENTRY_VALUE:begin
                write_ptr<=write_ptr+1'b1;
                if(emit_index+1==reply_value_length)begin cursor<=entry_end;state<=NEXT_ENTRY;end
                else begin emit_index<=emit_index+1'b1;if(op==8'ha3)byte_read(ENTRY_VALUE);end
            end
            PATCH:if(patch_index==7)begin send_ptr<=0;state<=PRELOAD;end else patch_index<=patch_index+1'b1;
            PRELOAD:state<=SEND;
            SEND:if(m_ready)begin
                if(m_eop)begin state<=IDLE;capture_count<=0;stat_responses<=stat_responses+1'b1;end
                else send_ptr<=send_ptr+1'b1;
            end
            default:state<=BAD;
        endcase
    end
endmodule
