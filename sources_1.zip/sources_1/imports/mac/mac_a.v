`timescale 1ns / 1ns
// 传统 MAC A 通道模块，保留作为参考；当前 AFDX_top 使用 afdx_packet_port。
// 接口为 8 位字节流，100 Mbps 对应 12.5 MHz 字节时钟。
// TX：缓存完整帧体，再发送前导码、SFD、帧体、填充、FCS 和帧间隔。
// RX：用四字节延迟线分离 FCS，并在帧结束时给出 CRC 和长度判定。
// 目的 MAC 的低 16 位作为 VLID；IPv4 填充剥离由 STRIP_PAD 控制。
// 本注释依据代码重新整理；受损的原始注释无法完整恢复。

/*
发送通路：上层>帧体缓存FIFO*【1】>帧长FIFO*【2】>成帧状态机*【3】
┌───────┬─────┬────────┬───────┬──────┬──────┬──────┬────┬──────────┬──────┬─────┐
│前导码  │ SFD │目的MAC │ 源MAC │ 类型 │ IP头  │ UDP头│ SN │ 有效载荷  │ 填充 │ FCS │
│   7   │  1  │   6    │   6   │  2   │  20  │  8   │ 1  │ 17~1471  │0~1454│  4  │
└───────┴─────┴────────┴───────┴──────┴──────┴──────┴────┴──────────┴──────┴─────┘
   ↑       ↑   |              真题缓存和帧长FIFO时打包完得数据        |  ↑       ↑
 T_PRE   T_SFD |                                                    | T_PAD   T_FCS

【1】：赛题规定一次只能存1字节（rx_data[7:0]）,一帧有60字节——1518字节，
最少要存60个时钟；在AFDX内BAG要求帧不能断流，所以先存完再发
【2】：因为FIFO只有一个，所有的帧是流水线一样输进来的，
需要帧长度标记一帧范围来区别每一帧，在BAG调度器内准确连续一帧又一帧的发送
【3】：把以上处理后得裸帧按照AFDX帧格式封装{+前导码+SFD+FCS+填充}，格式见开头
*/
module mac_a #(
    parameter                 MAC_USER_ID   = 16'h0001,   
    parameter                 MAC_DST_CONST = 32'h03_00_00_00,
    parameter                 PROMISC       = 1'b0,
    parameter                 STRIP_PAD     = 1'b1,
    parameter                 MAX_FRAME     = 1518,
    parameter                 MIN_FRAME     = 64,
    parameter                 IFG           = 12,
    parameter                 FIFO_AW       = 11
) (
    input  wire        clk,
    input  wire        reset,
    output wire [7:0]  tx_a_data,
    input  wire [7:0]  rx_a_data,
    output wire        tx_a_valid,
    input  wire        rx_a_valid,
    output wire        tx_a_ready,
    output wire        rx_a_ready,
    input  wire [7:0]  maca_tx_in_data,
    input  wire        maca_tx_in_valid,
    output wire        maca_tx_in_ready,
    input  wire        maca_tx_in_sop,
    input  wire        maca_tx_in_eop,
    output wire [7:0]  maca_rx_out_data,
    output wire        maca_rx_out_valid,
    input  wire        maca_rx_out_ready,
    output wire        maca_rx_out_sop,
    output wire        maca_rx_out_eop,
    output wire        maca_rx_out_good,
    output wire        maca_rx_out_bad,
    output wire        maca_rx_out_dsth,
    output wire [15:0] maca_rx_out_vlid,
    output wire [10:0] maca_rx_out_len
);
    // =========================================================================
    // =========================================================================
    // A 通道源 MAC 地址：固定前缀、用户 ID、接口 ID 和保留位。
    localparam                LP_MAC_ADDR   = {24'h020000, MAC_USER_ID, 3'b001, 5'b00000};
    // =========================================================================
    // =========================================================================
    // 逐字节更新反射 CRC32，使用多项式 0xEDB88320。
    function [31:0] f_crc32;
        input       [31:0] crc_in;
        input       [7:0]  din;
        integer                 i;
        reg     [31:0]          c;
        begin
            c = crc_in ^ {24'h000000, din};
            
            for (i = 0; i < 8; i = i + 1) begin
                
                if (c[0]) c = (c >> 1) ^ 32'hEDB88320;
                
                else c = (c >> 1);
                
            end
            f_crc32 = c;
            
        end
    endfunction

    // =========================================================================
    
    
    
    
    // =========================================================================
    // TX 数据 FIFO 和帧长 FIFO，共同保存帧体及边界。
    localparam                LP_DEPTH      = 1 << FIFO_AW;
    localparam                LP_BODY_MIN   = MIN_FRAME - 4;
    reg     [7:0]           tx_fifo[0:LP_DEPTH - 1];
    reg     [FIFO_AW - 1:0] wr_addr;
    reg     [FIFO_AW - 1:0] rd_addr;
    reg     [FIFO_AW:0]     used;
    wire    [7:0]           fifo_dout;
    reg     [10:0]          len_fifo[0:7];
    reg     [2:0]           len_wr;
    reg     [2:0]           len_rd;
    reg     [3:0]           len_cnt;
    reg     [10:0]          w_len;
    wire                    fifo_full = (used == LP_DEPTH);
    wire                    len_full = (len_cnt == 4'd8);
    wire                    len_empty = (len_cnt == 4'd0);
    assign fifo_dout = tx_fifo[rd_addr];
    assign maca_tx_in_ready = !fifo_full && !len_full;
    assign rx_a_ready = 1'b1;
    
    always @ (posedge clk) begin
        if (reset) begin
            wr_addr <= 0;
            len_wr <= 0;
            w_len <= 0;
        end else begin
            if (maca_tx_in_valid && maca_tx_in_ready) begin
                tx_fifo[wr_addr] <= maca_tx_in_data;
                wr_addr <= wr_addr + 1'b1;
                if (maca_tx_in_sop) w_len <= 11'd1;
                else w_len <= w_len + 11'd1;
                if (maca_tx_in_eop) begin
                    
                    len_fifo[len_wr] <= maca_tx_in_sop ? 11'd1 : (w_len + 11'd1);
                    len_wr <= len_wr + 1'b1;
                end
            end
        end
    end
    
    // TX 状态机：等待整帧、前导码、SFD、帧体、填充、FCS、IFG。
    localparam                T_IDLE        = 3'd0, T_PRE = 3'd1, T_SFD = 3'd2,
    T_BODY = 3'd3, T_PAD = 3'd4, T_FCS = 3'd5, T_IFG = 3'd6;
    reg     [2:0]           tx_cs;
    reg     [2:0]           pre_cnt;
    reg     [10:0]          body_cnt;
    reg     [10:0]          cur_len;
    reg     [31:0]          tx_crc;
    reg     [31:0]          tx_fcs_sr;
    reg     [1:0]           fcs_cnt;
    reg     [3:0]           ifg_cnt;
    reg     [7:0]           tx_data_r;
    reg                     tx_valid_r;
    assign tx_a_data = tx_data_r;
    assign tx_a_valid = tx_valid_r;
    assign tx_a_ready = (tx_cs == T_IDLE) && !len_full && (used < LP_DEPTH);
    always @ (posedge clk) begin
        if (reset) begin
            tx_cs <= T_IDLE;
            rd_addr <= 0;
            len_rd <= 0;
            pre_cnt <= 0;
            body_cnt <= 0;
            cur_len <= 0;
            tx_crc <= 32'hFFFFFFFF;
            tx_fcs_sr <= 32'h0;
            fcs_cnt <= 0;
            ifg_cnt <= 0;
            tx_data_r <= 8'h00;
            tx_valid_r <= 1'b0;
        end else begin
            case (tx_cs)
                T_IDLE : begin // 等待完整帧体入 FIFO；满足帧长记录后才启动，保证线上连续发送。
                    
                    tx_valid_r <= 1'b0;
                    ifg_cnt <= 0;
                    if (!len_empty && (used >= len_fifo[len_rd])) begin
                        cur_len <= len_fifo[len_rd];
                        len_rd <= len_rd + 1'b1;
                        body_cnt <= 0;
                        pre_cnt <= 0;
                        tx_crc <= 32'hFFFFFFFF;
                        tx_cs <= T_PRE;
                    end
                end
                T_PRE : begin // 连续发送 7 个 0x55；前导码不参与帧体 CRC。
                    
                    tx_data_r <= 8'h55;
                    tx_valid_r <= 1'b1;
                    if (pre_cnt == 3'd6) begin
                        pre_cnt <= 0;
                        tx_cs <= T_SFD;
                    end else
                    pre_cnt <= pre_cnt + 1'b1;
                end
                T_SFD : begin // 发送帧起始定界符 0xD5，下一拍进入帧体发送。
                    
                    tx_data_r <= 8'hD5;
                    tx_cs <= T_BODY;
                end
                
                
                
                
                
                T_BODY : begin // 逐拍读取帧体 FIFO，输出字节并同步更新 CRC 和读指针。
                    if (body_cnt < cur_len) begin
                        tx_data_r <= fifo_dout;
                        tx_valid_r <= 1'b1;
                        tx_crc <= f_crc32(tx_crc, fifo_dout);
                        rd_addr <= rd_addr + 1'b1;
                        body_cnt <= body_cnt + 1'b1;
                        // 在输出最后一个帧体字节的这一拍决定跳转，避免下一拍重复输出。
                        if (body_cnt == cur_len - 1'b1) begin
                            
                            if (cur_len >= LP_BODY_MIN) begin
                                // 非阻塞赋值尚未更新 tx_crc，必须将本拍最后一字节计入后再取反。
                                tx_fcs_sr <= ~f_crc32(tx_crc, fifo_dout);
                                
                                fcs_cnt <= 2'd0;
                                tx_cs <= T_FCS;
                            end else
                            tx_cs <= T_PAD;
                            
                        end
                    end
                end
                T_PAD : begin // 不足最小帧长时补 0；填充字节也参与 CRC。
                    
                    tx_data_r <= 8'h00;
                    tx_crc <= f_crc32(tx_crc, 8'h00);
                    body_cnt <= body_cnt + 1'b1;
                    
                    
                    // 计数器是本拍更新前的值；最后一个填充字节发出后立即切换至 FCS。
                    if (body_cnt == LP_BODY_MIN - 1'b1) begin
                        // 将本拍填充的 0 计入 CRC 后取反，不能直接使用旧 tx_crc。
                        tx_fcs_sr <= ~f_crc32(tx_crc, 8'h00);
                        fcs_cnt <= 2'd0;
                        tx_cs <= T_FCS;
                    end
                end
                T_FCS : begin // 从低字节开始连续发送 4 字节 FCS，每拍右移 8 位。
                    
                    tx_data_r <= tx_fcs_sr[7:0];
                    tx_valid_r <= 1'b1;
                    tx_fcs_sr <= {8'h00, tx_fcs_sr[31:8]};
                    if (fcs_cnt == 2'd3) begin
                        fcs_cnt <= 0;
                        tx_cs <= T_IFG;
                    end else
                    fcs_cnt <= fcs_cnt + 1'b1;
                end
                T_IFG : begin // 拉低发送 valid，保持至少 IFG 个字节时钟的帧间隔。
                    
                    tx_valid_r <= 1'b0;
                    tx_data_r <= 8'h00;
                    if (ifg_cnt == IFG - 1) begin
                        ifg_cnt <= 0;
                        tx_cs <= T_IDLE;
                    end else
                    ifg_cnt <= ifg_cnt + 1'b1;
                end
                default : tx_cs <= T_IDLE;
            endcase
        end
    end
    
    
    
    
    
    wire                    w_wr_en = maca_tx_in_valid && maca_tx_in_ready;
    wire                    w_rd_pop = (tx_cs == T_BODY) && (body_cnt < cur_len);
    wire                    w_len_psh = w_wr_en && maca_tx_in_eop;
    wire                    w_len_pop = (tx_cs == T_IDLE) && !len_empty &&
    (used >= len_fifo[len_rd]);
    
    always @ (posedge clk) begin
        if (reset) begin
            used <= 0;
            len_cnt <= 0;
        end else begin
            
            // 只写加一、只读减一；同拍读写时占用量不变，由此处统一驱动计数器。
            case ({w_wr_en, w_rd_pop})
                2'b10 : used <= used + 1'b1;
                
                2'b01 : used <= used - 1'b1;
                
                default : used <= used;
                
            endcase
            // EOP 入队一条帧长记录，启动发送出队一条；同时发生则帧数不变。
            case ({w_len_psh, w_len_pop})
                2'b10 : len_cnt <= len_cnt + 1'b1;
                
                2'b01 : len_cnt <= len_cnt - 1'b1;
                
                default : len_cnt <= len_cnt;
                
            endcase
        end
    end
    // =========================================================================
    
    
    
    // =========================================================================
    
    
    // RX 状态机：等待前导码、识别 SFD、接收帧体。
    localparam                R_IDLE        = 2'd0, R_PRE = 2'd1, R_BODY = 2'd2;
    reg     [1:0]           rx_cs;
    // 四字节延迟线：帧结束时将末尾 FCS 留在延迟寄存器中。
    reg     [7:0]           dl0, dl1, dl2, dl3;
    reg     [3:0]           dlv;
    reg     [31:0]          rx_crc;
    reg     [31:0]          fcs_sr;
    reg     [10:0]          rx_cnt;
    reg     [10:0]          out_cnt;
    reg     [10:0]          out_num;
    reg     [47:0]          da_sr;
    reg     [2:0]           da_cnt;
    reg     [15:0]          type_r;
    reg     [15:0]          ip_len_r;
    wire    [10:0]          w_real_len = {3'b0, ip_len_r} + 11'd14;
    wire                    w_ipv4 = (type_r == 16'h0800);
    wire                    w_pad_zone = STRIP_PAD && w_ipv4 &&
    (out_cnt >= 11'd18) && (out_cnt >= w_real_len);
    wire                    w_raw_valid = dlv[3] && rx_a_valid && (rx_cs == R_BODY);
    wire                    w_len_ok = (rx_cnt >= MIN_FRAME) && (rx_cnt <= MAX_FRAME);
    // 比较接收 FCS 与帧体 CRC 的取反结果。
    wire                    w_fcs_ok = (fcs_sr == ~rx_crc);
    // 物理 valid 拉低表示当前以太网帧结束。
    wire                    w_done = (rx_cs == R_BODY) && !rx_a_valid;
    wire                    w_dst_hit = PROMISC ||
    (da_sr[47:16] == MAC_DST_CONST) ||
    (da_sr == LP_MAC_ADDR);
    reg                     rxo_valid_r, rxo_sop_r, rxo_eop_r, rxo_good_r, rxo_bad_r;
    reg     [7:0]           rxo_data_r;
    
    assign maca_rx_out_data = rxo_data_r;
    assign maca_rx_out_valid = rxo_valid_r;
    assign maca_rx_out_sop = rxo_sop_r;
    assign maca_rx_out_eop = rxo_eop_r;
    assign maca_rx_out_good = rxo_good_r;
    assign maca_rx_out_bad = rxo_bad_r;
    assign maca_rx_out_dsth = w_dst_hit;
    assign maca_rx_out_vlid = da_sr[15:0];
    
    assign maca_rx_out_len = out_num;
    
    always @ (posedge clk) begin
        if (reset) begin
            rx_cs <= R_IDLE;
            dlv <= 4'b0;
            dl0 <= 0;
            dl1 <= 0;
            dl2 <= 0;
            dl3 <= 0;
            rx_crc <= 32'hFFFFFFFF;
            fcs_sr <= 32'h0;
            rx_cnt <= 0;
            out_cnt <= 0;
            out_num <= 0;
            da_sr <= 48'h0;
            da_cnt <= 0;
            type_r <= 16'h0;
            ip_len_r <= 16'h0;
            rxo_data_r <= 8'h00;
            rxo_valid_r <= 1'b0;
            rxo_sop_r <= 1'b0;
            rxo_eop_r <= 1'b0;
            rxo_good_r <= 1'b0;
            rxo_bad_r <= 1'b0;
        end else begin
            
            // 数据和 valid/SOP 同拍寄存；good/bad 在帧结束时才给出，属于流式接收。
            rxo_data_r <= dl3;
            
            rxo_valid_r <= w_raw_valid && !w_pad_zone;
            rxo_sop_r <= w_raw_valid && !w_pad_zone && (out_cnt == 11'd0);
            rxo_eop_r <= w_done;
            rxo_good_r <= w_done && w_fcs_ok && w_len_ok;
            rxo_bad_r <= w_done && !(w_fcs_ok && w_len_ok);
            case (rx_cs)
                R_IDLE : begin // 清空接收延迟线有效标志，等待前导码首个 0x55。
                    
                    dlv <= 4'b0;
                    out_cnt <= 0;
                    out_num <= 0;
                    if (rx_a_valid && (rx_a_data == 8'h55)) begin
                        rx_cs <= R_PRE;
                        da_cnt <= 0;
                    end
                end
                R_PRE : begin // 识别后续 0x55 和 SFD；遇无效字节流则重新等待。
                    
                    if (!rx_a_valid) begin
                        rx_cs <= R_IDLE;
                    end else if (rx_a_data == 8'hD5) begin
                        rx_cs <= R_BODY;
                        rx_crc <= 32'hFFFFFFFF;
                        fcs_sr <= 32'h0;
                        rx_cnt <= 0;
                        out_cnt <= 0;
                        out_num <= 0;
                        da_cnt <= 0;
                        dlv <= 4'b0;
                    end else if (rx_a_data != 8'h55) begin
                        rx_cs <= R_IDLE;
                        
                    end
                end
                R_BODY : begin // 接收帧体及 FCS；延迟四字节后输出帧体并计算 CRC。
                    
                    if (rx_a_valid) begin
                        // 连续移入字节；末尾四字节留在延迟线，不作为帧体参与 CRC。
                        dl0 <= rx_a_data;
                        dl1 <= dl0;
                        dl2 <= dl1;
                        dl3 <= dl2;
                        dlv <= {dlv[2:0], 1'b1};
                        fcs_sr <= {rx_a_data, fcs_sr[31:8]};
                        rx_cnt <= rx_cnt + 1'b1;
                        if (da_cnt < 3'd6) begin
                            
                            da_sr <= {da_sr[39:0], rx_a_data};
                            da_cnt <= da_cnt + 1'b1;
                        end
                        
                        // 延迟线填满后，每个有效输入拍将最早的帧体字节计入 CRC。
                        if (dlv[3])
                        rx_crc <= f_crc32(rx_crc, dl3);
                        
                        if (w_raw_valid) begin
                            // 从以太网帧体固定偏移提取 EtherType 和 IPv4 总长度，用于填充剥离。
                            if (out_cnt == 11'd12) type_r[15:8] <= dl3;
                            if (out_cnt == 11'd13) type_r[7:0] <= dl3;
                            if (out_cnt == 11'd16) ip_len_r[15:8] <= dl3;
                            if (out_cnt == 11'd17) ip_len_r[7:0] <= dl3;
                            out_cnt <= out_cnt + 1'b1;
                        end
                        if (w_raw_valid && !w_pad_zone)
                        out_num <= out_num + 1'b1;
                    end else begin
                        rx_cs <= R_IDLE;
                        
                        if (!(w_fcs_ok && w_len_ok))
                            $display("[mac_a] %t 帧锟斤拷锟斤拷: crc_ok=%b len=%0d",
                        $time, w_fcs_ok, rx_cnt);
                    end
                end
                default : rx_cs <= R_IDLE;
            endcase
        end
    end
endmodule
