`timescale 1ns/1ns
// Synchronous byte-clock port: 8 * CLK_FREQ bit/s (clock supplied by parent). Complete TX payload -> Ethernet/IPv4/UDP/pad/SN/FCS.
// Physical RX cannot be paused. Four whole-frame slots absorb internal backpressure;
// exhausted slots drop a COMPLETE incoming frame and report overflow, never overwrite.
module afdx_packet_port #(
    parameter          [47:0] SOURCE_MAC  = 48'h020000000120,
    parameter          [31:0] SOURCE_IP   = 32'h0a000001,
    DEST_IP = 32'h0a000002,
    parameter          [15:0] SOURCE_PORT = 16'h0bb8,
    DEST_PORT = 16'h0bba,
    parameter                 RX_SLOTS    = 4,
    parameter QUEUED_TX = 0,
    parameter RX_LENGTH_EQUALIZE = 0,
    parameter MANAGEMENT_PORTS = 0, SUPPORT_FRAGMENT=0
) (
    input  wire        clk,
    input  wire        reset,
    input  wire [7:0]  s_data,
    input  wire        s_valid,
    output wire        s_ready,
    input  wire        s_sop,
    input  wire        s_eop,
    input  wire [15:0] s_length,
    input  wire [15:0] s_vlid,
    input  wire [7:0]  s_sn,
    output wire [7:0]  tx_data,
    output wire        tx_valid,
    output wire        tx_idle,
    input  wire [7:0]  rx_data,
    input  wire        rx_valid,
    output wire [7:0]  m_data,
    output wire        m_valid,
    input  wire        m_ready,
    output wire        m_sop,
    output wire        m_eop,
    output wire [15:0] m_length,
    output wire [15:0] m_vlid,
    output wire [15:0] m_frame_length,
    output wire [7:0]  m_sn,
    output reg         crc_error,
    output reg         protocol_error,
    output reg         overflow_error,
    input wire [31:0] rx_timestamp,
    output wire [31:0] m_timestamp,
    output wire [15:0] m_src_port, m_dst_port,
    output wire [31:0] m_src_ip, m_dst_ip,
    input wire s_launch_valid,
    input wire [31:0] s_launch_tick,
    output reg tx_start_pulse,
    output reg [15:0] tx_start_vlid,
    input wire s_fragment,output wire m_fragment,
    input wire s_header_valid,
    input wire [15:0] s_src_port,s_dst_port,
    input wire [31:0] s_src_ip,s_dst_ip
);
    function [31:0] crc_byte;
        input       [31:0] previous;
        input       [7:0]  value;
        reg     [31:0]           c;
        integer                  b;
        begin
            c = previous ^ {24'd0, value};
            for (b = 0; b < 8; b = b + 1) c = c[0] ? ((c >> 1) ^ 32'hedb88320) : (c >> 1);
            crc_byte = c;
        end
    endfunction

    function [15:0] ip_checksum;
        input       [15:0] payload_length;
        input [31:0] src_ip,dst_ip;
        input [15:0] identification,flags_offset;
        reg     [31:0]           sum;
        begin
            sum = 32'h4500 + payload_length + 20 + identification + flags_offset + 32'h4011 +
            src_ip[31:16] + src_ip[15:0] + dst_ip[31:16] + dst_ip[15:0];
            sum = (sum & 32'hffff) + (sum >> 16);
            sum = (sum & 32'hffff) + (sum >> 16);
            ip_checksum = ~sum[15:0];
        end
    endfunction

    // Two 16-bit end-around folds equal FFFF exactly when the halves
    // complement each other, or both are FFFF. This covers every 32-bit sum.
    function checksum_valid32;
        input [31:0] accumulated;
        begin checksum_valid32=(accumulated[15:0]==~accumulated[31:16]) || (&accumulated);end
    endfunction

    localparam                T_CAPTURE   = 0, T_PRE = 1, T_BODY = 2, T_FCS = 3, T_IFG = 4;
    reg     [2:0]            t_state;
    (* ramstyle = "M4K, no_rw_check" *) reg [7:0] tx_mem[0:4095];
    reg [7:0] tx_payload_q;
    reg     [15:0]           t_count, t_length, t_vlid, t_body_len, t_index;
    reg     [7:0]            t_sn;
    // Separate capture/read banks permit payload copy during physical transmission.
    reg                      capture_bank, transmit_bank;
    reg     [15:0]           capture_length, capture_vlid;
    reg     [7:0]            capture_sn;
    reg     [31:0]           t_crc, t_fcs;
    reg     [7:0]            body_byte;
    reg [96:0] capture_udp_header,pending_udp_header,transmit_udp_header;
    wire raw_tx=SUPPORT_FRAGMENT && transmit_udp_header[96];
    wire [15:0] tx_source_port=transmit_udp_header[95:80],tx_dest_port=transmit_udp_header[79:64];
    wire [31:0] tx_source_ip=transmit_udp_header[63:32],tx_dest_ip=transmit_udp_header[31:0];
    reg [31:0] local_tick;
    reg capture_full,pending_bank,pending_timed;
    reg [15:0] pending_length,pending_vlid;
    reg [7:0] pending_sn;
    reg [31:0] pending_tick;
    wire release_due = !pending_timed || $signed(local_tick-pending_tick)>=0;
    wire [10:0] tx_prefetch_index = t_index - (raw_tx?16'd33:16'd41);
    always @(posedge clk)
        tx_payload_q <= tx_mem[{transmit_bank,tx_prefetch_index}];
    wire    [15:0]           ip_len = t_length + (raw_tx?16'd20:16'd28), udp_len = t_length + 16'd8;
    wire    [15:0]           checksum = ip_checksum(raw_tx?t_length:t_length+16'd8,tx_source_ip,tx_dest_ip,raw_tx?tx_source_port:16'd0,raw_tx?tx_dest_port:16'h4000);
    // Commit EOP only when the previous IFG has finished. Thus complete-copy
    // remains one cycle before preamble and is still the TX core BAG anchor.
    assign s_ready = !reset && (QUEUED_TX ? !capture_full : (t_state == T_CAPTURE || !s_eop));
    assign tx_idle = t_state == T_CAPTURE && t_count == 0 && (!QUEUED_TX || !capture_full);
    assign tx_valid = !reset && (t_state == T_PRE || t_state == T_BODY || t_state == T_FCS);
    assign tx_data = (t_state == T_PRE) ? ((t_index == 7) ? 8'hd5 : 8'h55) :
    (t_state == T_BODY) ? body_byte :
    (t_state == T_FCS) ? (t_fcs >> (8 * t_index)) : 8'd0;
    always @ (*) begin
        body_byte = 0;
        case (t_index)
            0 : body_byte = 8'h03;
            1, 2, 3 : body_byte = 0;
            4 : body_byte = t_vlid[15:8];
            5 : body_byte = t_vlid[7:0];
            6 : body_byte = SOURCE_MAC[47:40];
            7 : body_byte = SOURCE_MAC[39:32];
            8 : body_byte = SOURCE_MAC[31:24];
            9 : body_byte = SOURCE_MAC[23:16];
            10 : body_byte = SOURCE_MAC[15:8];
            11 : body_byte = SOURCE_MAC[7:0];
            12 : body_byte = 8'h08;
            13 : body_byte = 0;
            14 : body_byte = 8'h45;
            15 : body_byte = 0;
            16 : body_byte = ip_len[15:8];
            17 : body_byte = ip_len[7:0];
            18 : body_byte = raw_tx?tx_source_port[15:8]:0;
            19 : body_byte = raw_tx?tx_source_port[7:0]:0;
            20 : body_byte = raw_tx?tx_dest_port[15:8]:8'h40;
            21 : body_byte = raw_tx?tx_dest_port[7:0]:0;
            22 : body_byte = 8'h40;
            23 : body_byte = 8'h11;
            24 : body_byte = checksum[15:8];
            25 : body_byte = checksum[7:0];
            26 : body_byte = tx_source_ip[31:24];
            27 : body_byte = tx_source_ip[23:16];
            28 : body_byte = tx_source_ip[15:8];
            29 : body_byte = tx_source_ip[7:0];
            30 : body_byte = tx_dest_ip[31:24];
            31 : body_byte = tx_dest_ip[23:16];
            32 : body_byte = tx_dest_ip[15:8];
            33 : body_byte = tx_dest_ip[7:0];
            34 : body_byte = tx_source_port[15:8];
            35 : body_byte = tx_source_port[7:0];
            36 : body_byte = tx_dest_port[15:8];
            37 : body_byte = tx_dest_port[7:0];
            38 : body_byte = udp_len[15:8];
            39 : body_byte = udp_len[7:0];
            40, 41 : body_byte = 0;
            // AFDX IPv4 UDP checksum disabled.
            default : begin
                // SN 位于帧体最后一字节；业务以外的间隙使用默认 0 填充。
                if (t_index == t_body_len - 1) body_byte = t_sn;
                else if (t_index >= 42 && t_index < 42 + t_length) body_byte = tx_payload_q;
            end
        endcase
        if(raw_tx && t_index>=34)begin
            body_byte=0;
            if(t_index==t_body_len-1)body_byte=t_sn;
            else if(t_index<34+t_length)body_byte=tx_payload_q;
        end
    end
    function [15:0] body_length;
        input [15:0] n;input raw;
        begin body_length=raw?(n<25?16'd60:n+16'd35):(n<17?16'd60:n+16'd43);end
    endfunction
    always @ (posedge clk or posedge reset) begin
        if (reset) begin
            capture_udp_header<={1'b0,SOURCE_PORT,DEST_PORT,SOURCE_IP,DEST_IP};
            pending_udp_header<={1'b0,SOURCE_PORT,DEST_PORT,SOURCE_IP,DEST_IP};
            transmit_udp_header<={1'b0,SOURCE_PORT,DEST_PORT,SOURCE_IP,DEST_IP};
            local_tick<=0;capture_full<=0;pending_bank<=0;pending_timed<=0;
            pending_length<=0;pending_vlid<=0;pending_sn<=0;pending_tick<=0;
            tx_start_pulse<=0;tx_start_vlid<=0;
            t_state <= T_CAPTURE;
            t_count <= 0;
            capture_bank <= 0;
            transmit_bank <= 0;
            capture_length <= 0;
            capture_vlid <= 0;
            capture_sn <= 0;
            t_length <= 0;
            t_vlid <= 0;
            t_sn <= 0;
            t_index <= 0;
            t_body_len <= 0;
            t_crc <= 32'hffffffff;
            t_fcs <= 0;
        end else begin
            local_tick<=local_tick+1'b1;
            tx_start_pulse<=t_state==T_PRE && t_index==0;
            if(t_state==T_PRE && t_index==0)tx_start_vlid<=t_vlid;
            if(QUEUED_TX && t_state==T_CAPTURE && capture_full && release_due)begin
                transmit_bank<=pending_bank;capture_full<=0;transmit_udp_header<=pending_udp_header;
                t_length<=pending_length;t_vlid<=pending_vlid;t_sn<=pending_sn;
                t_body_len<=body_length(pending_length,pending_udp_header[96]);
                t_index<=0;t_crc<=32'hffffffff;t_state<=T_PRE;
            end
            // Capture into the bank not being transmitted. A stalled EOP holds
            // the last byte upstream, so no third frame can overwrite either bank.
            if (s_valid && s_ready) begin
                if (s_sop) begin
                    if(s_header_valid)capture_udp_header<={(SUPPORT_FRAGMENT && s_fragment),s_src_port,s_dst_port,s_src_ip,s_dst_ip};
                    else capture_udp_header<={1'b0,SOURCE_PORT,DEST_PORT,SOURCE_IP,DEST_IP};
                    capture_length <= s_length;
                    capture_vlid <= s_vlid;
                    capture_sn <= s_sn;
                end
                if (t_count < 1471) tx_mem[{capture_bank,t_count[10:0]}] <= s_data;
                if (s_eop) begin
                    t_count <= 0;
                    capture_bank <= ~capture_bank;
                    if(QUEUED_TX)begin
                        if(s_sop)begin
                            if(s_header_valid)pending_udp_header<={(SUPPORT_FRAGMENT && s_fragment),s_src_port,s_dst_port,s_src_ip,s_dst_ip};
                            else pending_udp_header<={1'b0,SOURCE_PORT,DEST_PORT,SOURCE_IP,DEST_IP};
                        end else pending_udp_header<=capture_udp_header;
                        capture_full<=1;pending_bank<=capture_bank;
                        pending_length<=s_sop?s_length:capture_length;
                        pending_vlid<=s_sop?s_vlid:capture_vlid;
                        pending_sn<=s_sop?s_sn:capture_sn;
                        pending_timed<=s_launch_valid;pending_tick<=s_launch_tick;
                    end else begin
                    if(s_sop)begin
                        if(s_header_valid)transmit_udp_header<={(SUPPORT_FRAGMENT && s_fragment),s_src_port,s_dst_port,s_src_ip,s_dst_ip};
                        else transmit_udp_header<={1'b0,SOURCE_PORT,DEST_PORT,SOURCE_IP,DEST_IP};
                    end else transmit_udp_header<=capture_udp_header;
                    transmit_bank <= capture_bank;
                    t_length <= s_sop ? s_length : capture_length;
                    t_vlid <= s_sop ? s_vlid : capture_vlid;
                    t_sn <= s_sop ? s_sn : capture_sn;
                    t_index <= 0;
                    t_crc <= 32'hffffffff;
                    t_body_len <= body_length(s_sop?s_length:capture_length,s_sop?(SUPPORT_FRAGMENT && s_fragment):capture_udp_header[96]);
                    t_state <= T_PRE;
                    end
                end else t_count <= t_count + 1'b1;
            end
            case (t_state)
            T_CAPTURE : begin end
            T_PRE : if (t_index == 7) begin
                t_index <= 0;
                t_state <= T_BODY;
            end else t_index <= t_index + 1'b1;
            // 连续输出首部、业务、填充和尾部 SN；这些字节均计入 CRC。
            T_BODY : begin
                t_crc <= crc_byte(t_crc, body_byte);
                if (t_index == t_body_len - 1) begin
                    // t_crc 是旧值，需计入本拍最后字节（SN）后再取反生成完整 FCS。
                    t_fcs <= ~crc_byte(t_crc, body_byte);
                    t_index <= 0;
                    t_state <= T_FCS;
                end
                else t_index <= t_index + 1'b1;
            end
            // 连续发送 4 字节 FCS；第四字节输出后进入帧间隔。
            T_FCS : if (t_index == 3) begin
                t_index <= 0;
                t_state <= T_IFG;
            end else t_index <= t_index + 1'b1;
            // 保持 12 个字节时钟的无效间隔，再允许下一帧业务输入。
            T_IFG : if (t_index == 11) begin
                t_index <= 0;
                t_state <= T_CAPTURE;
            end else t_index <= t_index + 1'b1;
            default : t_state <= T_CAPTURE;
            endcase
        end
    end
    // Receive parser examines each incoming byte once. Only UDP business bytes
    // enter block RAM; header words and checksum are accumulated in registers.
    // There is one RAM write port and one synchronous read port per MAC.
    localparam SLOT_AW = (RX_SLOTS < 2) ? 1 : $clog2(RX_SLOTS);
    localparam SLOT_COUNT = (1 << SLOT_AW);
    localparam RX_PAYLOAD_STRIDE=1472;
    localparam RX_PAYLOAD_AW=$clog2(RX_SLOTS*RX_PAYLOAD_STRIDE);
    (* ramstyle = "M4K, no_rw_check" *) reg [7:0] rx_mem[0:RX_SLOTS*RX_PAYLOAD_STRIDE-1];
    function [RX_PAYLOAD_AW-1:0] rx_payload_storage_address;
        input [SLOT_AW-1:0] slot;
        input [10:0] byte_offset;
        reg [RX_PAYLOAD_AW-7:0] slot_units,units;
        begin
            slot_units=slot;
            units=(slot_units<<4)+(slot_units<<3)-slot_units+byte_offset[10:6];
            rx_payload_storage_address={units,byte_offset[5:0]};
        end
    endfunction
    reg [RX_SLOTS-1:0] occupied;
    // One descriptor accompanies each payload slot. Contents do not reset:
    // occupied[] alone determines validity. A synchronous read with forwarding
    // publishes the descriptor on the same cycle as its first payload byte.
    (* ramstyle = "M4K, no_rw_check" *) reg [216:0] rx_descriptors[0:SLOT_COUNT-1];
    reg [216:0] rx_descriptor_q,rx_descriptor_bypass_data;
    reg rx_descriptor_bypass;
    reg [SLOT_AW-1:0] wr_slot, rd_slot;
    reg [15:0] rx_count, read_count;
    reg [3:0] pre_count;
    reg in_frame, discard, pre_bad, header_bad;
    reg [31:0] rx_crc, ip_sum, frame_time, source_ip, dest_ip;
    reg [15:0] received_vl, ip_length, udp_length, source_port, dest_port;
    reg [15:0] ip_ident,ip_flags;
    wire raw_rx=SUPPORT_FRAGMENT && (ip_flags[13] || ip_flags[12:0]!=0);
    reg [7:0] ip_high,udp_high;
    reg [31:0] udp_sum;
    reg [15:0] udp_checksum;
    wire service_port=MANAGEMENT_PORTS && (dest_port==161 || dest_port==69 || dest_port>=49152);
    wire ports_good=(source_port==SOURCE_PORT && dest_port==DEST_PORT) || service_port;
    wire [31:0] udp_total=udp_sum+source_ip[31:16]+source_ip[15:0]+dest_ip[31:16]+dest_ip[15:0]+
        32'd17+udp_length+(udp_length[0]?{udp_high,8'd0}:16'd0);
    wire udp_good=udp_checksum==0 || checksum_valid32(udp_total);
    reg [39:0] tail;
    reg [7:0] rx_payload_q;
    wire [15:0] payload_len = raw_rx?ip_length-16'd20:udp_length-16'd8;
    wire [15:0] expected_frame_len = raw_rx?(payload_len<25?16'd64:payload_len+16'd39):(payload_len<17?16'd64:payload_len+16'd47);
    wire ip_good=checksum_valid32(ip_sum);
    wire format_good = !header_bad && ip_good &&
        (raw_rx?(ip_flags[15:14]==0 && ip_length>20 && (!ip_flags[13] || payload_len[2:0]==0)):
            (ports_good && udp_good && ip_length==udp_length+16'd20 && udp_length>=9)) && payload_len<=1471 &&
        rx_count == expected_frame_len;
    wire commit_frame = !reset && !rx_valid && in_frame && !discard &&
        !pre_bad && pre_count==8 && rx_count>=64 && rx_count<=1518 &&
        rx_crc==32'hdebb20e3 && format_good;
    // Delay short-frame publication by the payload drain-time difference.
    // This avoids variable waiting behind a preceding long host output frame.
    // All delay is real clocked waiting and remains inside host latency.
    wire [31:0] rx_release_tick = local_tick +
        (RX_LENGTH_EQUALIZE ? (32'd1471 - {16'd0,payload_len}) : 32'd0);
    wire [216:0] committed_descriptor = {raw_rx,rx_release_tick,payload_len,received_vl,rx_count,tail[39:32],
        frame_time,(raw_rx?ip_ident:source_port),(raw_rx?ip_flags:dest_port),source_ip,dest_ip};
    wire [216:0] descriptor_head = rx_descriptor_bypass?rx_descriptor_bypass_data:rx_descriptor_q;
    wire pop_last = m_valid && m_ready && m_eop;
    wire [SLOT_AW-1:0] next_rd_slot = rd_slot == RX_SLOTS-1 ? 0 : rd_slot + 1'b1;
    wire [SLOT_AW-1:0] ram_rd_slot = pop_last ? next_rd_slot : rd_slot;
    wire [10:0] ram_rd_index = pop_last ? 11'd0 :
        ((m_valid && m_ready) ? read_count[10:0] + 11'd1 : read_count[10:0]);
    wire [15:0] payload_start=raw_rx?16'd34:16'd42;
    wire [10:0] ram_wr_index=rx_count-payload_start;
    // Read-ahead preserves one byte/cycle and holds the head while stalled.
    always @(posedge clk) begin
        if (!reset && rx_valid && in_frame && pre_count == 8 && !discard &&
            rx_count >= payload_start && rx_count < payload_start + payload_len && payload_len <= 1471)
            rx_mem[rx_payload_storage_address(wr_slot,ram_wr_index)] <= rx_data;
        rx_payload_q <= rx_mem[rx_payload_storage_address(ram_rd_slot,ram_rd_index)];
        if(commit_frame)rx_descriptors[wr_slot]<=committed_descriptor;
        rx_descriptor_q<=rx_descriptors[ram_rd_slot];
    end
    always @(posedge clk or posedge reset)begin
        if(reset)begin rx_descriptor_bypass<=0;rx_descriptor_bypass_data<=0;end
        else begin
            rx_descriptor_bypass<=commit_frame && wr_slot==ram_rd_slot;
            if(commit_frame && wr_slot==ram_rd_slot)rx_descriptor_bypass_data<=committed_descriptor;
        end
    end
    wire rx_release_due = !RX_LENGTH_EQUALIZE ||
        $signed(local_tick-descriptor_head[215:184]) >= 0;
    // Keep valid asserted once published, even across a long ready stall.
    reg rx_head_released;
    always @(posedge clk or posedge reset)begin
        if(reset)rx_head_released<=0;
        else if(pop_last)rx_head_released<=0;
        else if(occupied[rd_slot] && rx_release_due)rx_head_released<=1;
    end
    assign m_fragment=descriptor_head[216];
    assign m_valid = !reset && occupied[rd_slot] && (rx_head_released || rx_release_due);
    assign m_data = rx_payload_q;
    assign m_sop = read_count == 0;
    assign m_eop = read_count + 1 == m_length;
    assign {m_length,m_vlid,m_frame_length,m_sn,m_timestamp,
        m_src_port,m_dst_port,m_src_ip,m_dst_ip}=descriptor_head[183:0];
    always @(posedge clk or posedge reset) begin
        if (reset) begin
            occupied <= 0; wr_slot <= 0; rd_slot <= 0;
            rx_count <= 0; read_count <= 0; pre_count <= 0;
            in_frame <= 0; discard <= 0; pre_bad <= 0; header_bad <= 0;
            rx_crc <= 32'hffffffff; ip_sum <= 0; ip_high <= 0;
            udp_high<=0;udp_sum<=0;udp_checksum<=0;
            frame_time <= 0; received_vl <= 0; ip_length <= 0; udp_length <= 0;
            ip_ident<=0;ip_flags<=0;source_port <= 0; dest_port <= 0; source_ip <= 0; dest_ip <= 0; tail <= 0;
            crc_error <= 0; protocol_error <= 0; overflow_error <= 0;
        end else begin
            crc_error<=0;protocol_error<=0;overflow_error<=0;
            if(m_valid && m_ready) begin
                if(m_eop) begin occupied[rd_slot]<=0;read_count<=0;rd_slot<=next_rd_slot;end
                else read_count<=read_count+1'b1;
            end
            if(rx_valid) begin
                if(!in_frame) begin
                    in_frame<=1;discard<=occupied[wr_slot];pre_bad<=rx_data!=8'h55;
                    pre_count<=1;rx_count<=0;rx_crc<=32'hffffffff;
                    header_bad<=0;ip_sum<=0;ip_high<=0;tail<=0;udp_sum<=0;udp_high<=0;udp_checksum<=0;
                    received_vl<=0;ip_length<=0;udp_length<=0;
                    ip_ident<=0;ip_flags<=0;source_port<=0;dest_port<=0;source_ip<=0;dest_ip<=0;
                    frame_time<=rx_timestamp;
                end else if(pre_count<8) begin
                    if(rx_data!=((pre_count==7)?8'hd5:8'h55))pre_bad<=1;
                    pre_count<=pre_count+1'b1;
                end else begin
                    rx_crc<=crc_byte(rx_crc,rx_data);
                    tail<={tail[31:0],rx_data};
                    if(rx_count<16'hffff)rx_count<=rx_count+1'b1;
                    if(rx_count>=14 && rx_count<34) begin
                        if(!rx_count[0])ip_high<=rx_data;
                        else ip_sum<=ip_sum+{ip_high,rx_data};
                    end
                    if(rx_count>=34 && (rx_count<42 || rx_count<34+udp_length))begin
                        if(!rx_count[0])udp_high<=rx_data;else udp_sum<=udp_sum+{udp_high,rx_data};
                    end
                    case(rx_count)
                        0:if(rx_data!=8'h03)header_bad<=1;
                        1,2,3:if(rx_data!=0)header_bad<=1;
                        4:received_vl[15:8]<=rx_data;
                        5:received_vl[7:0]<=rx_data;
                        12:if(rx_data!=8'h08)header_bad<=1;
                        13:if(rx_data!=0)header_bad<=1;
                        14:if(rx_data!=8'h45)header_bad<=1;
                        16:ip_length[15:8]<=rx_data;
                        17:ip_length[7:0]<=rx_data;
                        18:ip_ident[15:8]<=rx_data;
                        19:ip_ident[7:0]<=rx_data;
                        20:begin ip_flags[15:8]<=rx_data;if(SUPPORT_FRAGMENT?(rx_data[7] || (rx_data[6] && rx_data[5])):((rx_data & 8'hbf)!=0))header_bad<=1;end
                        21:begin ip_flags[7:0]<=rx_data;if(!SUPPORT_FRAGMENT && rx_data!=0)header_bad<=1;end
                        23:if(rx_data!=17)header_bad<=1;
                        26,27,28,29:source_ip<={source_ip[23:0],rx_data};
                        30,31,32,33:dest_ip<={dest_ip[23:0],rx_data};
                        34:source_port[15:8]<=rx_data;
                        35:source_port[7:0]<=rx_data;
                        36:dest_port[15:8]<=rx_data;
                        37:dest_port[7:0]<=rx_data;
                        38:udp_length[15:8]<=rx_data;
                        39:udp_length[7:0]<=rx_data;
                        40:udp_checksum[15:8]<=rx_data;
                        41:udp_checksum[7:0]<=rx_data;
                        default:begin end
                    endcase
                end
            end else if(in_frame) begin
                in_frame<=0;
                if(discard)overflow_error<=1;
                else if(pre_bad || pre_count!=8 || rx_count<64 || rx_count>1518 || rx_crc!=32'hdebb20e3)crc_error<=1;
                else if(!format_good)protocol_error<=1;
                else begin
                    occupied[wr_slot]<=1;
                    wr_slot<=(wr_slot==RX_SLOTS-1)?0:wr_slot+1'b1;
                end
            end
        end
    end
endmodule
