`timescale 1ns/1ns
// V2: 1 Gbit/s synchronous byte interface, clk=125 MHz, 8 bits per cycle.
// The external host may offer 100 Mbit/s payload using valid/ready.
// RTC, BAG and protocol timers derive from CLK_FREQ; no time compression.
// Indexed static schedules are optional; keep disabled for arrival-driven traffic.
// Board integration must provide the corresponding clock and PHY interface.
module AFDX_competition_top #(
    // 规模与时序参数：VL 数量、冗余最大偏斜（ms）、字节时钟频率（Hz）。
    parameter                 VL_NUM      = 2,
    // ????/?????????????? VL_NUM??????????
    parameter                 TX_VL_NUM   = 128,
    parameter                 RX_VL_NUM   = 4096,
    parameter                 SKEW_MAX_MS = 5,
    parameter                 CLK_FREQ    = 125_000_000,
    // 主机分帧及缓存参数：定长/显式帧、定长字节数、每路接收帧槽数。
    parameter                 HOST_FRAMED = 1,
    parameter                 FRAME_LEN   = 62,
    parameter                 RX_SLOTS    = 32,
    parameter RX_LENGTH_EQUALIZE=1,
    parameter TIMED_TX=1,
    // Optional host-completion experiment; not required for GMII SFD timing.
    parameter COMPENSATE_LATENCY=0,
    parameter ENABLE_HW_SNMP=1,
    parameter ENABLE_HW_615A=1,
    parameter DOWNLOAD_MAX_FILES=4, DOWNLOAD_FILE_BYTES=4096,
    parameter DOWNLOAD_DALLY_SLOTS=4, DOWNLOAD_DALLY_MS=6000,
    parameter MANAGEMENT_VL=TX_VL_NUM-1
) (
    // 全局控制：所有模块共用时钟，reset 高电平复位。
    input  wire        clk,
    input  wire        reset,

    // A/B 物理字节接口：data/valid 传输线上字节，TX ready 表示缓存空闲。
    output wire [7:0]  tx_a_data,
    input  wire [7:0]  rx_a_data,
    output wire        tx_a_valid,
    input  wire        rx_a_valid,
    output wire        tx_a_ready,
    input  wire        rx_a_ready,
    output wire [7:0]  tx_b_data,
    input  wire [7:0]  rx_b_data,
    output wire        tx_b_valid,
    input  wire        rx_b_valid,
    output wire        tx_b_ready,
    input  wire        rx_b_ready,
    // 主机加载/卸载业务流：valid && ready 时传输一个字节。
    input  wire [7:0]  host_load_data,
    input  wire        host_load_valid,
    output wire        host_load_ready,
    output wire [7:0]  host_unload_data,
    output wire        host_unload_valid,
    input  wire        host_unload_ready,
    // MIB 寄存器接口：按地址读配置及统计，wr_en 控制写入。
    input  wire [7:0]  mib_addr,
    input  wire        mib_wr_en,
    input  wire [31:0] mib_wr_data,
    output wire [31:0] mib_rd_data,
    // RTC 输出：32 位本地毫秒计数。
    output wire [31:0] rtc_timestamp,
    // 显式帧描述：SOP/EOP 标记边界，首字节提供 VLID 和业务长度。
    input  wire        host_load_sop,
    input  wire        host_load_eop,
    input  wire [15:0] host_load_vlid,
    input  wire [15:0] host_load_length,
    input wire rtc_pps_in,
    output wire rtc_sync_locked,
    output wire host_unload_sop,host_unload_eop,
    output wire mib_busy
);

    // Preserve the original pin budget. Extended IP/UDP descriptors use MIB
    // registers rather than an additional 200-bit parallel external bus.
    reg header_enable;
    reg [31:0] header_ports,header_src_ip,header_dst_ip;
    wire [31:0] core_mib_data;
    wire [15:0] rx_vlid,rx_length,rx_src_port,rx_dst_port;
    wire [31:0] rx_src_ip,rx_dst_ip;
    always @(posedge clk or posedge reset)begin
        if(reset)begin
            header_enable<=0;header_ports<=32'h0bb80bba;
            header_src_ip<=32'h0a000001;header_dst_ip<=32'h0a000002;
        end else if(mib_wr_en)case(mib_addr)
            8'h64:header_ports<=mib_wr_data;
            8'h65:header_src_ip<=mib_wr_data;
            8'h66:header_dst_ip<=mib_wr_data;
            8'h67:header_enable<=mib_wr_data[0];
            default:begin end
        endcase
    end
    assign mib_rd_data=mib_addr==8'h64 ? header_ports:
        mib_addr==8'h65 ? header_src_ip:mib_addr==8'h66 ? header_dst_ip:
        mib_addr==8'h67 ? {31'd0,header_enable}:mib_addr==8'h68 ? {rx_vlid,rx_length}:
        mib_addr==8'h69 ? {rx_src_port,rx_dst_port}:mib_addr==8'h6a ? rx_src_ip:
        mib_addr==8'h6b ? rx_dst_ip:core_mib_data;
    AFDX_top #(.VL_NUM(VL_NUM), .TX_VL_NUM(TX_VL_NUM), .RX_VL_NUM(RX_VL_NUM), .SKEW_MAX_MS(SKEW_MAX_MS), .CLK_FREQ(CLK_FREQ), .HOST_FRAMED(HOST_FRAMED), .FRAME_LEN(FRAME_LEN), .RX_SLOTS(RX_SLOTS), .RX_LENGTH_EQUALIZE(RX_LENGTH_EQUALIZE), .TIMED_TX(TIMED_TX), .COMPENSATE_LATENCY(COMPENSATE_LATENCY), .ENABLE_HW_SNMP(ENABLE_HW_SNMP), .ENABLE_HW_615A(ENABLE_HW_615A), .DOWNLOAD_MAX_FILES(DOWNLOAD_MAX_FILES), .DOWNLOAD_FILE_BYTES(DOWNLOAD_FILE_BYTES), .DOWNLOAD_DALLY_SLOTS(DOWNLOAD_DALLY_SLOTS), .DOWNLOAD_DALLY_MS(DOWNLOAD_DALLY_MS), .MANAGEMENT_VL(MANAGEMENT_VL)) core(
        .clk(clk),
        .reset(reset),
        .tx_a_data(tx_a_data),
        .rx_a_data(rx_a_data),
        .tx_a_valid(tx_a_valid),
        .rx_a_valid(rx_a_valid),
        .tx_a_ready(tx_a_ready),
        .rx_a_ready(rx_a_ready),
        .tx_b_data(tx_b_data),
        .rx_b_data(rx_b_data),
        .tx_b_valid(tx_b_valid),
        .rx_b_valid(rx_b_valid),
        .tx_b_ready(tx_b_ready),
        .rx_b_ready(rx_b_ready),
        .host_load_data(host_load_data),
        .host_load_valid(host_load_valid),
        .host_load_ready(host_load_ready),
        .host_unload_data(host_unload_data),
        .host_unload_valid(host_unload_valid),
        .host_unload_ready(host_unload_ready),
        .mib_addr(mib_addr),
        .mib_wr_en(mib_wr_en),
        .mib_wr_data(mib_wr_data),
        .mib_rd_data(core_mib_data),.mib_busy(mib_busy),
        .rtc_timestamp(rtc_timestamp),
        .host_load_sop(host_load_sop),
        .host_load_eop(host_load_eop),
        .host_load_vlid(host_load_vlid),
        .host_load_length(host_load_length),
        .rtc_sync_valid(1'b0),
        .rtc_sync_timestamp(32'd0),
        .rtc_pps_in(rtc_pps_in),
        .rtc_sync_locked(rtc_sync_locked),
        .host_unload_sop(host_unload_sop),
        .host_unload_eop(host_unload_eop),
        .host_unload_vlid(rx_vlid),
        .host_unload_length(rx_length),
        .host_unload_src_port(rx_src_port),
        .host_unload_dst_port(rx_dst_port),
        .host_unload_src_ip(rx_src_ip),
        .host_unload_dst_ip(rx_dst_ip),
        .host_load_header_valid(header_enable),
        .host_load_src_port(header_ports[31:16]),
        .host_load_dst_port(header_ports[15:0]),
        .host_load_src_ip(header_src_ip),
        .host_load_dst_ip(header_dst_ip)
    );
endmodule
