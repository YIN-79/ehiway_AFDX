`timescale 1ns / 1ns
module afdx_rx_arbiter (
    input  wire  clk, reset, a_req, b_req,
    output wire  a_grant, b_grant
);
localparam         [1:0]  OWNER_NONE = 2'd0, OWNER_A = 2'd1, OWNER_B = 2'd2;
reg [1:0] owner;
assign a_grant = a_req && ((owner == OWNER_NONE) || (owner == OWNER_A));
assign b_grant = b_req && ((owner == OWNER_B) || ((owner == OWNER_NONE) && !a_req));

always @(posedge clk or posedge reset) begin
    if (reset) begin
        owner <= OWNER_NONE;
    end
    else begin
        if (owner == OWNER_NONE) begin
            if      (a_req) owner <= OWNER_A;
            else if (b_req) owner <= OWNER_B;
        end
        else if ((owner == OWNER_A) && !a_req) owner <= OWNER_NONE;
        else if ((owner == OWNER_B) && !b_req) owner <= OWNER_NONE;
    end
end

endmodule
