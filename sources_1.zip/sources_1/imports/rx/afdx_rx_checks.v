`timescale 1ns / 1ns
// Auxiliary frame checks. Preserve the original SOP timing and A priority.
module afdx_rx_checks #(
    parameter                 VL_NUM         = 2, SKEW_MAX_MS = 5, RTC_UNIT_NS = 1000000,
    parameter          [15:0] VL_ID_BASE     = 16'd0,
    parameter                 VL_IDX_W       = 8
)(
    input  wire                clk, reset,
    input  wire [7:0]          a_payload_data, b_payload_data,
    input  wire [15:0]         a_payload_vlid, b_payload_vlid,
    input  wire                a_payload_sop, b_payload_sop,
    input  wire                a_crc_err, b_crc_err, a_sop_xfer, b_sop_xfer,
    input  wire [31:0]         rtc_timestamp,
    output wire [VL_IDX_W-1:0] a_vl_idx, b_vl_idx,
    output wire                a_vl_hit, b_vl_hit, a_crc_bad, b_crc_bad,
    output wire                a_ic_ok, b_ic_ok, a_rm_redundant, b_rm_redundant,
    output wire                a_rm_pass, b_rm_pass
);
localparam integer        SKEW_MAX_TICKS = (SKEW_MAX_MS * 1000000) / RTC_UNIT_NS;
integer                ka, kb, ki;
reg                    a_crc_flag, b_crc_flag, a_sop_d, b_sop_d;
function [7:0] sn_inc;
    input       [7:0]          s;
    begin
        sn_inc = (s == 8'd255) ? 8'd1 : (s + 8'd1);
    end
endfunction

reg     [7:0]          psn_a     [0:VL_NUM-1];                  // A 通道各 VL 的上次接收序列号
reg                    psn_a_vld [0:VL_NUM-1];                  // A 通道 PSN 有效(复位后首帧标志)
reg     [7:0]          psn_b     [0:VL_NUM-1];
reg                    psn_b_vld [0:VL_NUM-1];
//---- 冗余管理用：跨通道共享，记录【上一次放行】的帧 ----
reg     [7:0]          lp_sn     [0:VL_NUM-1];                  // 上次放行帧的 SN
reg     [31:0]         lp_time   [0:VL_NUM-1];                  // 上次放行帧的时间戳
reg                    lp_vld    [0:VL_NUM-1];                  // 上次放行记录有效
reg     [VL_IDX_W-1:0] a_vl_idx_r, b_vl_idx_r;
reg                    a_vl_hit_r, b_vl_hit_r;

always @(*) begin
    a_vl_idx_r = {VL_IDX_W{1'b0}};
    a_vl_hit_r = 1'b0;
    for (ka = 0; ka < VL_NUM; ka = ka + 1) begin
        if (a_payload_vlid == (VL_ID_BASE + ka[15:0])) begin
            a_vl_idx_r = ka[VL_IDX_W-1:0];
            a_vl_hit_r = 1'b1;
        end
    end
end

always @(*) begin
    b_vl_idx_r = {VL_IDX_W{1'b0}};
    b_vl_hit_r = 1'b0;
    for (kb = 0; kb < VL_NUM; kb = kb + 1) begin
        if (b_payload_vlid == (VL_ID_BASE + kb[15:0])) begin
            b_vl_idx_r = kb[VL_IDX_W-1:0];
            b_vl_hit_r = 1'b1;
        end
    end
end


assign a_vl_idx = a_vl_idx_r;

assign b_vl_idx = b_vl_idx_r;

assign a_vl_hit = a_vl_hit_r;

assign b_vl_hit = b_vl_hit_r;
assign a_crc_bad = a_crc_err | a_crc_flag;
assign b_crc_bad = b_crc_err | b_crc_flag;

//==============================================================================
// 组合逻辑：门 2 —— SN 完整性检查(IC)，按通道独立
//   IC 放行条件(注意含 SN == PSN)：
//     - SN=0              : 发送端复位，无条件放行
//     - 本端复位后首帧     : PSN 无效，无条件放行
//     - SN == PSN+1       : 正常递增
//     - SN == PSN+2       : 容忍单个丢帧
//     - SN == PSN         : 【重复 SN】IC 层不判非法，交给门 4 冗余管理器裁决
//                           (窗口内判冗余副本丢弃，超 SkewMax 判新帧放行)
//   ★ 为什么 SN==PSN 必须过 IC：若 IC 直接拒掉重复 SN，则同 SN 帧永远到不了
//     冗余管理器，SkewMax 偏斜窗口将成为死逻辑——这是本模块最容易写错的一点。
//     文档对"重复 SN"的定义也正是在冗余管理层(判冗余副本/丢弃)，而非 IC 层。
//==============================================================================
wire    [7:0]          a_exp1 = sn_inc(psn_a[a_vl_idx]);
wire    [7:0]          a_exp2 = sn_inc(a_exp1);
wire    [7:0]          b_exp1 = sn_inc(psn_b[b_vl_idx]);
wire    [7:0]          b_exp2 = sn_inc(b_exp1);

assign a_ic_ok = (a_payload_sop && a_vl_hit && !a_crc_bad) ?
               ((a_payload_data == 8'd0)              ? 1'b1 :   // SN=0：发送端复位
                (!psn_a_vld[a_vl_idx])                ? 1'b1 :   // 本端复位后首帧
                ((a_payload_data == a_exp1) ||
                 (a_payload_data == a_exp2) ||
                 (a_payload_data == psn_a[a_vl_idx])) ? 1'b1 : 1'b0)
               : 1'b0;

assign b_ic_ok = (b_payload_sop && b_vl_hit && !b_crc_bad) ?
               ((b_payload_data == 8'd0)              ? 1'b1 :
                (!psn_b_vld[b_vl_idx])                ? 1'b1 :
                ((b_payload_data == b_exp1) ||
                 (b_payload_data == b_exp2) ||
                 (b_payload_data == psn_b[b_vl_idx])) ? 1'b1 : 1'b0)
               : 1'b0;

//==============================================================================
// 组合逻辑：门 4 —— 冗余管理(RM)，跨通道共享 last_pass
//   A 通道优先：同拍到达时 B 参照 A 刚判决的结果，故被判为冗余副本
//==============================================================================
wire    [31:0]         a_skew = rtc_timestamp - lp_time[a_vl_idx];

assign a_rm_redundant = a_ic_ok && lp_vld[a_vl_idx] &&
                      (a_payload_data == lp_sn[a_vl_idx]) &&
                      (a_skew <= SKEW_MAX_TICKS);
assign a_rm_pass = a_ic_ok && !a_rm_redundant;

// B 判定时若 A 同拍通过且同 VL，则 B 参照 A 即将写入的 last_pass
wire                   b_lp_vld_eff = (a_sop_xfer && a_rm_pass && (a_vl_idx == b_vl_idx)) ? 1'b1
                                                              : lp_vld[b_vl_idx];
wire    [7:0]          b_lp_sn_eff  = (a_sop_xfer && a_rm_pass && (a_vl_idx == b_vl_idx)) ? a_payload_data
                                                              : lp_sn[b_vl_idx];
wire    [31:0]         b_lp_tm_eff  = (a_sop_xfer && a_rm_pass && (a_vl_idx == b_vl_idx)) ? rtc_timestamp
                                                              : lp_time[b_vl_idx];
wire    [31:0]         b_skew_eff   = rtc_timestamp - b_lp_tm_eff;

assign b_rm_redundant = b_ic_ok && b_lp_vld_eff &&
                      (b_payload_data == b_lp_sn_eff) &&
                      (b_skew_eff <= SKEW_MAX_TICKS);
assign b_rm_pass = b_ic_ok && !b_rm_redundant;

always @(posedge clk or posedge reset) begin
    if (reset) begin
        a_crc_flag <= 1'b0;
        b_crc_flag <= 1'b0;
        a_sop_d    <= 1'b0;
        b_sop_d    <= 1'b0;
    end
    else begin
        a_sop_d <= a_sop_xfer;
        b_sop_d <= b_sop_xfer;
        if      (a_crc_err)    a_crc_flag <= 1'b1;
        else if (a_sop_d)      a_crc_flag <= 1'b0;
        if      (b_crc_err)    b_crc_flag <= 1'b1;
        else if (b_sop_d)      b_crc_flag <= 1'b0;
    end
end

always @(posedge clk or posedge reset) begin
    if (reset) begin
        for (ki = 0; ki < VL_NUM; ki = ki + 1) begin
            psn_a[ki]     <= 8'd0;
            psn_a_vld[ki] <= 1'b0;
            psn_b[ki]     <= 8'd0;
            psn_b_vld[ki] <= 1'b0;
            lp_sn[ki]     <= 8'd0;
            lp_time[ki]   <= 32'd0;
            lp_vld[ki]    <= 1'b0;
        end
    end
    else begin
        //---------------- A 通道 sop 拍 ----------------
        if (a_sop_xfer && a_vl_hit && !a_crc_bad) begin
            psn_a[a_vl_idx]     <= a_payload_data;   // 含被丢弃帧：标准要求更新
            psn_a_vld[a_vl_idx] <= 1'b1;
        end
        //---------------- B 通道 sop 拍 ----------------
        if (b_sop_xfer && b_vl_hit && !b_crc_bad) begin
            psn_b[b_vl_idx]     <= b_payload_data;
            psn_b_vld[b_vl_idx] <= 1'b1;
        end
        //---------------- last_pass 更新(A 优先) ----------------
        if (a_sop_xfer && a_rm_pass) begin
            lp_sn[a_vl_idx]   <= a_payload_data;
            lp_time[a_vl_idx] <= rtc_timestamp;
            lp_vld[a_vl_idx]  <= 1'b1;
        end
        else if (b_sop_xfer && b_rm_pass) begin
            lp_sn[b_vl_idx]   <= b_payload_data;
            lp_time[b_vl_idx] <= rtc_timestamp;
            lp_vld[b_vl_idx]  <= 1'b1;
        end
    end
end

endmodule
