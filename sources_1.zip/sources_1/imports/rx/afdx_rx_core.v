`timescale 1ns/1ns
// Atomic RX: cache whole BUSINESS payload; SN/frame length/VL arrive as metadata.
// IC precedes RM. PSN is independent for every channel/VL, including IC rejects.
// Input contract: complete validated MAC frames; SOP/EOP delimit business bytes.
// rtc_timestamp is sampled at input SOP (MAC arrival timestamps are a later step).
// The previous split RX helpers remain reference files and are not instantiated.
module afdx_rx_core #(
    parameter                 VL_NUM       = 2,
    SKEW_MAX_MS = 5,
    CLK_FREQ = 12500000,
    parameter          [15:0] VL_ID_BASE   = 0,
    parameter                 RTC_UNIT_NS  = 1000000,
    parameter          [15:0] LMAX_DEFAULT = 1518,
    parameter INDEXED_LMAX = 0,
    parameter MAC_STREAMING = 0,
    parameter USE_ARRIVAL_TIMESTAMP = 0, FRAGMENT_ENABLE=0
) (
    input  wire                     clk,
    input  wire                     reset,
    input  wire [7:0]               a_payload_data,
    input  wire                     a_payload_valid,
    output wire                     a_payload_ready,
    input  wire                     a_payload_sop,
    input  wire                     a_payload_eop,
    input  wire [15:0]              a_payload_vlid,
    input  wire [7:0]               a_sn,
    input  wire [15:0]              a_length,
    input  wire [15:0]              a_frame_length,
    input  wire                     a_crc_err,
    input  wire                     a_payload_bad,
    input  wire [7:0]               b_payload_data,
    input  wire                     b_payload_valid,
    output wire                     b_payload_ready,
    input  wire                     b_payload_sop,
    input  wire                     b_payload_eop,
    input  wire [15:0]              b_payload_vlid,
    input  wire [7:0]               b_sn,
    input  wire [15:0]              b_length,
    input  wire [15:0]              b_frame_length,
    input  wire                     b_crc_err,
    input  wire                     b_payload_bad,
    input  wire [31:0]              rtc_timestamp,
    input  wire [32 * (INDEXED_LMAX ? 1 : VL_NUM) - 1:0] vl_cfg_lmax,
    output wire [7:0]               out_payload_data,
    output wire                     out_payload_valid,
    input  wire                     out_payload_ready,
    output wire                     out_payload_sop,
    output wire                     out_payload_eop,
    output wire [15:0]              out_payload_vlid,
    output wire [15:0]              out_payload_length,
    output wire  [31:0]              stat_rx_frame_cnt,
    output wire  [31:0]              stat_err_crc,
    output wire  [31:0]              stat_err_sn,
    output wire  [31:0]              stat_drop_redundant,
    output wire  [31:0]              stat_drop_oversize,
    output wire  [31:0]              stat_drop_unknown,
    output wire  [31:0]              stat_bad_length,
    output wire [15:0] lmax_index,
    input wire [15:0] indexed_lmax,
    input wire [31:0] a_arrival_timestamp,b_arrival_timestamp,
    input wire [15:0] a_src_port,a_dst_port,b_src_port,b_dst_port,
    input wire [31:0] a_src_ip,a_dst_ip,b_src_ip,b_dst_ip,
    output wire [15:0] out_src_port,out_dst_port,
    input wire a_fragment,b_fragment,output wire out_fragment,
    output wire [31:0] out_src_ip,out_dst_ip
);
    generate if(MAC_STREAMING)begin:g_stream
        afdx_rx_streaming #(.VL_NUM(VL_NUM), .SKEW_MAX_MS(SKEW_MAX_MS), .CLK_FREQ(CLK_FREQ), .VL_ID_BASE(VL_ID_BASE), .RTC_UNIT_NS(RTC_UNIT_NS), .LMAX_DEFAULT(LMAX_DEFAULT), .INDEXED_LMAX(INDEXED_LMAX), .USE_ARRIVAL_TIMESTAMP(USE_ARRIVAL_TIMESTAMP),.FRAGMENT_ENABLE(FRAGMENT_ENABLE)) implementation(
        .clk(clk),
        .reset(reset),
        .a_payload_data(a_payload_data),
        .a_payload_valid(a_payload_valid),
        .a_payload_ready(a_payload_ready),
        .a_payload_sop(a_payload_sop),
        .a_payload_eop(a_payload_eop),
        .a_payload_vlid(a_payload_vlid),
        .a_sn(a_sn),
        .a_length(a_length),
        .a_frame_length(a_frame_length),
        .a_crc_err(a_crc_err),
        .a_payload_bad(a_payload_bad),
        .b_payload_data(b_payload_data),
        .b_payload_valid(b_payload_valid),
        .b_payload_ready(b_payload_ready),
        .b_payload_sop(b_payload_sop),
        .b_payload_eop(b_payload_eop),
        .b_payload_vlid(b_payload_vlid),
        .b_sn(b_sn),
        .b_length(b_length),
        .b_frame_length(b_frame_length),
        .b_crc_err(b_crc_err),
        .b_payload_bad(b_payload_bad),
        .rtc_timestamp(rtc_timestamp),
        .vl_cfg_lmax(vl_cfg_lmax),
        .out_payload_data(out_payload_data),
        .out_payload_valid(out_payload_valid),
        .out_payload_ready(out_payload_ready),
        .out_payload_sop(out_payload_sop),
        .out_payload_eop(out_payload_eop),
        .out_payload_vlid(out_payload_vlid),
        .out_payload_length(out_payload_length),
        .stat_rx_frame_cnt(stat_rx_frame_cnt),
        .stat_err_crc(stat_err_crc),
        .stat_err_sn(stat_err_sn),
        .stat_drop_redundant(stat_drop_redundant),
        .stat_drop_oversize(stat_drop_oversize),
        .stat_drop_unknown(stat_drop_unknown),
        .stat_bad_length(stat_bad_length),
        .lmax_index(lmax_index),
        .indexed_lmax(indexed_lmax),
        .a_arrival_timestamp(a_arrival_timestamp),
        .b_arrival_timestamp(b_arrival_timestamp),
        .a_src_port(a_src_port),.a_dst_port(a_dst_port),.b_src_port(b_src_port),.b_dst_port(b_dst_port),
        .a_src_ip(a_src_ip),.a_dst_ip(a_dst_ip),.b_src_ip(b_src_ip),.b_dst_ip(b_dst_ip),
        .a_fragment(a_fragment),.b_fragment(b_fragment),.out_fragment(out_fragment),
        .out_src_port(out_src_port),.out_dst_port(out_dst_port),.out_src_ip(out_src_ip),.out_dst_ip(out_dst_ip)
        );
    end else begin:g_buffered
        assign out_fragment=0;
        afdx_rx_buffered #(.VL_NUM(VL_NUM), .SKEW_MAX_MS(SKEW_MAX_MS), .CLK_FREQ(CLK_FREQ), .VL_ID_BASE(VL_ID_BASE), .RTC_UNIT_NS(RTC_UNIT_NS), .LMAX_DEFAULT(LMAX_DEFAULT), .INDEXED_LMAX(INDEXED_LMAX), .USE_ARRIVAL_TIMESTAMP(USE_ARRIVAL_TIMESTAMP)) implementation(
        .clk(clk),
        .reset(reset),
        .a_payload_data(a_payload_data),
        .a_payload_valid(a_payload_valid),
        .a_payload_ready(a_payload_ready),
        .a_payload_sop(a_payload_sop),
        .a_payload_eop(a_payload_eop),
        .a_payload_vlid(a_payload_vlid),
        .a_sn(a_sn),
        .a_length(a_length),
        .a_frame_length(a_frame_length),
        .a_crc_err(a_crc_err),
        .a_payload_bad(a_payload_bad),
        .b_payload_data(b_payload_data),
        .b_payload_valid(b_payload_valid),
        .b_payload_ready(b_payload_ready),
        .b_payload_sop(b_payload_sop),
        .b_payload_eop(b_payload_eop),
        .b_payload_vlid(b_payload_vlid),
        .b_sn(b_sn),
        .b_length(b_length),
        .b_frame_length(b_frame_length),
        .b_crc_err(b_crc_err),
        .b_payload_bad(b_payload_bad),
        .rtc_timestamp(rtc_timestamp),
        .vl_cfg_lmax(vl_cfg_lmax),
        .out_payload_data(out_payload_data),
        .out_payload_valid(out_payload_valid),
        .out_payload_ready(out_payload_ready),
        .out_payload_sop(out_payload_sop),
        .out_payload_eop(out_payload_eop),
        .out_payload_vlid(out_payload_vlid),
        .out_payload_length(out_payload_length),
        .stat_rx_frame_cnt(stat_rx_frame_cnt),
        .stat_err_crc(stat_err_crc),
        .stat_err_sn(stat_err_sn),
        .stat_drop_redundant(stat_drop_redundant),
        .stat_drop_oversize(stat_drop_oversize),
        .stat_drop_unknown(stat_drop_unknown),
        .stat_bad_length(stat_bad_length),
        .lmax_index(lmax_index),
        .indexed_lmax(indexed_lmax),
        .a_arrival_timestamp(a_arrival_timestamp),
        .b_arrival_timestamp(b_arrival_timestamp),
        .a_src_port(a_src_port),.a_dst_port(a_dst_port),.b_src_port(b_src_port),.b_dst_port(b_dst_port),
        .a_src_ip(a_src_ip),.a_dst_ip(a_dst_ip),.b_src_ip(b_src_ip),.b_dst_ip(b_dst_ip),
        .out_src_port(out_src_port),.out_dst_port(out_dst_port),.out_src_ip(out_src_ip),.out_dst_ip(out_dst_ip)
        );
    end endgenerate
endmodule

module afdx_rx_buffered #(
    parameter                 VL_NUM       = 2,
    SKEW_MAX_MS = 5,
    CLK_FREQ = 12500000,
    parameter          [15:0] VL_ID_BASE   = 0,
    parameter                 RTC_UNIT_NS  = 1000000,
    parameter          [15:0] LMAX_DEFAULT = 1518,
    parameter INDEXED_LMAX = 0,
    parameter USE_ARRIVAL_TIMESTAMP = 0
) (
    input  wire                     clk,
    input  wire                     reset,
    input  wire [7:0]               a_payload_data,
    input  wire                     a_payload_valid,
    output wire                     a_payload_ready,
    input  wire                     a_payload_sop,
    input  wire                     a_payload_eop,
    input  wire [15:0]              a_payload_vlid,
    input  wire [7:0]               a_sn,
    input  wire [15:0]              a_length,
    input  wire [15:0]              a_frame_length,
    input  wire                     a_crc_err,
    input  wire                     a_payload_bad,
    input  wire [7:0]               b_payload_data,
    input  wire                     b_payload_valid,
    output wire                     b_payload_ready,
    input  wire                     b_payload_sop,
    input  wire                     b_payload_eop,
    input  wire [15:0]              b_payload_vlid,
    input  wire [7:0]               b_sn,
    input  wire [15:0]              b_length,
    input  wire [15:0]              b_frame_length,
    input  wire                     b_crc_err,
    input  wire                     b_payload_bad,
    input  wire [31:0]              rtc_timestamp,
    input  wire [32 * (INDEXED_LMAX ? 1 : VL_NUM) - 1:0] vl_cfg_lmax,
    output wire [7:0]               out_payload_data,
    output wire                     out_payload_valid,
    input  wire                     out_payload_ready,
    output wire                     out_payload_sop,
    output wire                     out_payload_eop,
    output wire [15:0]              out_payload_vlid,
    output wire [15:0]              out_payload_length,
    output reg  [31:0]              stat_rx_frame_cnt,
    output reg  [31:0]              stat_err_crc,
    output reg  [31:0]              stat_err_sn,
    output reg  [31:0]              stat_drop_redundant,
    output reg  [31:0]              stat_drop_oversize,
    output reg  [31:0]              stat_drop_unknown,
    output reg  [31:0]              stat_bad_length,
    output wire [15:0] lmax_index,
    input wire [15:0] indexed_lmax,
    input wire [31:0] a_arrival_timestamp,b_arrival_timestamp,
    input wire [15:0] a_src_port,a_dst_port,b_src_port,b_dst_port,
    input wire [31:0] a_src_ip,a_dst_ip,b_src_ip,b_dst_ip,
    output wire [15:0] out_src_port,out_dst_port,
    output wire [31:0] out_src_ip,out_dst_ip
);
    localparam                MAX_PAYLOAD  = 1471;
    localparam                SKEW_TICKS   = (SKEW_MAX_MS * 1000000) / RTC_UNIT_NS;
    // A legal VL sends at most once per 1 ms BAG. Retain the full skew
    // window plus two boundary entries, including coarse RTC rounding.
    localparam RM_DEPTH=SKEW_MAX_MS+2,RM_WIDTH=42*RM_DEPTH;
    reg     [7:0]          a_mem[0:MAX_PAYLOAD - 1], b_mem[0:MAX_PAYLOAD - 1];
    reg                    afull, bfull, acollect, bcollect, abad, bbad;
    reg     [15:0]         acount, bcount, alen, blen, avl, bvl, aflen, bflen, adeclared, bdeclared;
    reg     [7:0]          asn, bsn;
    reg     [31:0]         atime, btime;
    (* ramstyle = "M4K, no_rw_check" *) reg [15:0] psn_mem[0:VL_NUM-1];
    (* ramstyle = "M4K, no_rw_check" *) reg [RM_WIDTH-1:0] rm_mem[0:VL_NUM-1];
    reg [15:0] psn_q;
    reg [RM_WIDTH-1:0] rm_q;
    reg [VL_NUM-1:0] va,vb,last_valid;
    reg decision_pending,decision_b;
    reg [7:0] a_read_q,b_read_q;
    reg                    output_busy, output_b, prefer_b;
    reg     [15:0]         out_index;
    reg [95:0] a_udp_meta,b_udp_meta;
    integer                i;
    function [7:0] inc_sn;
        input       [7:0]               s;
        begin
            inc_sn = (s == 255) ? 8'd1 : s + 1'b1;
        end
    endfunction

    assign a_payload_ready = !reset && !afull;
    assign b_payload_ready = !reset && !bfull;
    assign out_payload_valid = !reset && output_busy;
    assign out_payload_data = output_b ? b_read_q : a_read_q;
    assign out_payload_sop = out_index == 0;
    assign out_payload_eop = out_index + 1 == (output_b ? blen : alen);
    assign out_payload_vlid = output_b ? bvl : avl;
    assign {out_src_port,out_dst_port,out_src_ip,out_dst_ip}=output_b?b_udp_meta:a_udp_meta;
    assign out_payload_length = output_b ? blen : alen;
    wire                   choose_b = decision_pending ? decision_b : (bfull && (!afull || prefer_b));
    wire    [15:0]         selected_vl = choose_b ? bvl : avl;
    wire    [15:0]         selected_len = choose_b ? blen : alen;
    wire    [15:0]         selected_declared = choose_b ? bdeclared : adeclared;
    wire    [15:0]         selected_flen = choose_b ? bflen : aflen;
    wire    [7:0]          selected_sn = choose_b ? bsn : asn;
    wire    [31:0]         selected_time = choose_b ? btime : atime;
    wire                   selected_bad = choose_b ? bbad : abad;
    wire                   vl_known = selected_vl >= VL_ID_BASE && selected_vl < VL_ID_BASE + VL_NUM;
    wire    [15:0]         vl_index = selected_vl - VL_ID_BASE;
    assign lmax_index = vl_index;
    wire [31:0] cfg_max = INDEXED_LMAX ? {16'd0,indexed_lmax} : (vl_known ? vl_cfg_lmax[vl_index * 32 +: 32] : 0);
    wire    [31:0]         selected_max = (cfg_max == 0) ? LMAX_DEFAULT : cfg_max;
    wire                   previous_valid = vl_known ? (choose_b ? vb[vl_index] : va[vl_index]) : 0;
    wire    [7:0]          previous_sn = vl_known ? (choose_b ? psn_q[15:8] : psn_q[7:0]) : 0;
    wire                   ic_ok = !previous_valid || selected_sn == 0 || selected_sn == inc_sn(previous_sn) || selected_sn == inc_sn(inc_sn(previous_sn));
    wire history_duplicate;
    afdx_rm_window #(.DEPTH(RM_DEPTH),.WINDOW_TICKS(SKEW_TICKS)) redundancy_window(
        .history(rm_q),.channel_b(choose_b),.sequence_number(selected_sn),
        .arrival_time(selected_time),.duplicate(history_duplicate));
    wire duplicate=vl_known && last_valid[vl_index] && history_duplicate;
    wire    [15:0]         required_flen = (selected_len < 17) ? 16'd64 : selected_len + 16'd47;
    wire [10:0] payload_read_index = !output_busy ? 11'd0 :
        out_index[10:0] + ((out_payload_valid && out_payload_ready && !out_payload_eop)?11'd1:11'd0);
    always @(posedge clk) begin
        a_read_q<=a_mem[payload_read_index];
        b_read_q<=b_mem[payload_read_index];
        if(vl_known)begin psn_q<=psn_mem[vl_index];rm_q<=rm_mem[vl_index];end
        if(!reset && decision_pending && !output_busy && vl_known && !selected_bad)begin
            psn_mem[vl_index]<=choose_b?{selected_sn,psn_q[7:0]}:{psn_q[15:8],selected_sn};
            if(ic_ok && selected_len<=MAX_PAYLOAD && selected_flen<=selected_max &&
               selected_len==selected_declared && selected_flen==required_flen && !duplicate)
                rm_mem[vl_index]<=((last_valid[vl_index] && selected_sn!=0)?
                    (rm_q<<42):{RM_WIDTH{1'b0}}) |
                    {{(RM_WIDTH-42){1'b0}},1'b1,choose_b,selected_time,selected_sn};
        end
    end
    always @ (posedge clk or posedge reset) begin
        if (reset) begin
            a_udp_meta<=0;b_udp_meta<=0;
            afull <= 0;
            bfull <= 0;
            acollect <= 0;
            bcollect <= 0;
            abad <= 0;
            bbad <= 0;
            acount <= 0;
            bcount <= 0;
            alen <= 0;
            blen <= 0;
            avl <= 0;
            bvl <= 0;
            aflen <= 0;
            bflen <= 0;
            adeclared <= 0;
            bdeclared <= 0;
            asn <= 0;
            bsn <= 0;
            atime <= 0;
            btime <= 0;
            va <= 0;
            vb <= 0;
            last_valid <= 0;
            decision_pending<=0;decision_b<=0;
            output_busy <= 0;
            output_b <= 0;
            out_index <= 0;
            prefer_b <= 0;
            stat_rx_frame_cnt <= 0;
            stat_err_crc <= 0;
            stat_err_sn <= 0;
            stat_drop_redundant <= 0;
            stat_drop_oversize <= 0;
            stat_drop_unknown <= 0;
            stat_bad_length <= 0;
        end else begin
            if (a_crc_err || b_crc_err) stat_err_crc <= stat_err_crc + {31'd0, a_crc_err} + {31'd0, b_crc_err};
            if (a_payload_valid && a_payload_ready) begin
                if (a_payload_sop) begin
                    a_udp_meta<={a_src_port,a_dst_port,a_src_ip,a_dst_ip};
                    avl <= a_payload_vlid;
                    asn <= a_sn;
                    adeclared <= a_length;
                    aflen <= a_frame_length;
                    atime <= USE_ARRIVAL_TIMESTAMP ? a_arrival_timestamp : rtc_timestamp;
                    abad <= a_payload_bad;
                    acount <= 1;
                    a_mem[0] <= a_payload_data;
                    acollect <= 1;
                    if (a_payload_eop) begin
                        afull <= 1;
                        alen <= 1;
                        acollect <= 0;
                        acount <= 0;
                    end
                end else if (acollect) begin
                    if (a_payload_bad) abad <= 1;
                    if (acount < MAX_PAYLOAD) a_mem[acount] <= a_payload_data;
                    if (acount < 16'hffff) acount <= acount + 1'b1;
                    else abad <= 1;
                    if (a_payload_eop) begin
                        afull <= 1;
                        alen <= (acount == 16'hffff) ? 16'hffff : acount + 1'b1;
                        acount <= 0;
                        acollect <= 0;
                    end
                end
            end
            if (b_payload_valid && b_payload_ready) begin
                if (b_payload_sop) begin
                    b_udp_meta<={b_src_port,b_dst_port,b_src_ip,b_dst_ip};
                    bvl <= b_payload_vlid;
                    bsn <= b_sn;
                    bdeclared <= b_length;
                    bflen <= b_frame_length;
                    btime <= USE_ARRIVAL_TIMESTAMP ? b_arrival_timestamp : rtc_timestamp;
                    bbad <= b_payload_bad;
                    bcount <= 1;
                    b_mem[0] <= b_payload_data;
                    bcollect <= 1;
                    if (b_payload_eop) begin
                        bfull <= 1;
                        blen <= 1;
                        bcollect <= 0;
                        bcount <= 0;
                    end
                end else if (bcollect) begin
                    if (b_payload_bad) bbad <= 1;
                    if (bcount < MAX_PAYLOAD) b_mem[bcount] <= b_payload_data;
                    if (bcount < 16'hffff) bcount <= bcount + 1'b1;
                    else bbad <= 1;
                    if (b_payload_eop) begin
                        bfull <= 1;
                        blen <= (bcount == 16'hffff) ? 16'hffff : bcount + 1'b1;
                        bcount <= 0;
                        bcollect <= 0;
                    end
                end
            end
            if (output_busy) begin
                if (out_payload_valid && out_payload_ready) begin
                    if (out_payload_eop) begin
                        output_busy <= 0;
                        out_index <= 0;
                        stat_rx_frame_cnt <= stat_rx_frame_cnt + 1'b1;
                        if (output_b) bfull <= 0;
                        else afull <= 0;
                    end else out_index <= out_index + 1'b1;
                end
            end else if (afull || bfull) begin
                if(!decision_pending)begin decision_pending<=1;decision_b<=choose_b;end
                else begin
                decision_pending<=0;
                prefer_b <= !choose_b;
                // Update PSN for every structurally valid, CRC-good frame, including IC/LMAX/RM rejects.
                if (vl_known && !selected_bad) begin
                    if (choose_b) begin
                        vb[vl_index] <= 1;
                    end
                    else begin
                        va[vl_index] <= 1;
                    end
                end
                if (selected_bad || !vl_known || !ic_ok || selected_len > MAX_PAYLOAD ||
                    selected_flen > selected_max || selected_len != selected_declared ||
                selected_flen != required_flen || duplicate) begin
                    if (choose_b) bfull <= 0;
                    else afull <= 0;
                    if (!selected_bad) begin
                        if (!vl_known) stat_drop_unknown <= stat_drop_unknown + 1'b1;
                        else if (!ic_ok) stat_err_sn <= stat_err_sn + 1'b1;
                        else if (selected_len > MAX_PAYLOAD || selected_flen > selected_max) stat_drop_oversize <= stat_drop_oversize + 1'b1;
                        else if (selected_len != selected_declared || selected_flen != required_flen) stat_bad_length <= stat_bad_length + 1'b1;
                        else if (duplicate) stat_drop_redundant <= stat_drop_redundant + 1'b1;
                    end
                end else begin
                    output_busy <= 1;
                    output_b <= choose_b;
                    out_index <= 0;
                    last_valid[vl_index] <= 1;
                end
                end
            end
        end
    end
endmodule

module afdx_rx_streaming #(
    parameter                 VL_NUM       = 2,
    SKEW_MAX_MS = 5,
    CLK_FREQ = 12500000,
    parameter          [15:0] VL_ID_BASE   = 0,
    parameter                 RTC_UNIT_NS  = 1000000,
    parameter          [15:0] LMAX_DEFAULT = 1518,
    parameter INDEXED_LMAX = 0,
    parameter USE_ARRIVAL_TIMESTAMP = 0, FRAGMENT_ENABLE=0
) (
    input  wire                     clk,
    input  wire                     reset,
    input  wire [7:0]               a_payload_data,
    input  wire                     a_payload_valid,
    output wire                     a_payload_ready,
    input  wire                     a_payload_sop,
    input  wire                     a_payload_eop,
    input  wire [15:0]              a_payload_vlid,
    input  wire [7:0]               a_sn,
    input  wire [15:0]              a_length,
    input  wire [15:0]              a_frame_length,
    input  wire                     a_crc_err,
    input  wire                     a_payload_bad,
    input  wire [7:0]               b_payload_data,
    input  wire                     b_payload_valid,
    output wire                     b_payload_ready,
    input  wire                     b_payload_sop,
    input  wire                     b_payload_eop,
    input  wire [15:0]              b_payload_vlid,
    input  wire [7:0]               b_sn,
    input  wire [15:0]              b_length,
    input  wire [15:0]              b_frame_length,
    input  wire                     b_crc_err,
    input  wire                     b_payload_bad,
    input  wire [31:0]              rtc_timestamp,
    input  wire [32 * (INDEXED_LMAX ? 1 : VL_NUM) - 1:0] vl_cfg_lmax,
    output wire [7:0]               out_payload_data,
    output wire                     out_payload_valid,
    input  wire                     out_payload_ready,
    output wire                     out_payload_sop,
    output wire                     out_payload_eop,
    output wire [15:0]              out_payload_vlid,
    output wire [15:0]              out_payload_length,
    output reg  [31:0]              stat_rx_frame_cnt,
    output reg  [31:0]              stat_err_crc,
    output reg  [31:0]              stat_err_sn,
    output reg  [31:0]              stat_drop_redundant,
    output reg  [31:0]              stat_drop_oversize,
    output reg  [31:0]              stat_drop_unknown,
    output reg  [31:0]              stat_bad_length,
    output wire [15:0] lmax_index,
    input wire [15:0] indexed_lmax,
    input wire [31:0] a_arrival_timestamp,b_arrival_timestamp,
    input wire [15:0] a_src_port,a_dst_port,b_src_port,b_dst_port,
    input wire [31:0] a_src_ip,a_dst_ip,b_src_ip,b_dst_ip,
    output wire [15:0] out_src_port,out_dst_port,
    input wire a_fragment,b_fragment,output wire out_fragment,
    output wire [31:0] out_src_ip,out_dst_ip
);
    // MAC slots already hold and validate complete frames. Decide IC/RM at
    // SOP, then stream accepted bytes without a second whole-frame copy.
    localparam SKEW_TICKS=(SKEW_MAX_MS*1000000)/RTC_UNIT_NS;
    localparam RM_DEPTH=SKEW_MAX_MS+2,RM_WIDTH=42*RM_DEPTH;
    localparam IDLE=0,PASS=1,DROP=2;
    reg [1:0] state_a,state_b;
    reg output_busy,output_b,prefer_b;
    reg lookup_pending,lookup_b;
    localparam INIT_AW=VL_NUM<2?1:$clog2(VL_NUM);
    reg initializing;
    reg [INIT_AW-1:0] init_index;
    (* ramstyle = "M4K, no_rw_check" *) reg [17:0] psn_mem[0:VL_NUM-1];
    (* ramstyle = "M4K, no_rw_check" *) reg [RM_WIDTH-1:0] rm_mem[0:VL_NUM-1];
    reg [17:0] psn_q;
    reg [RM_WIDTH-1:0] rm_q;
    wire candidate_a=!initializing && state_a==IDLE && a_payload_valid;
    wire candidate_b=!initializing && state_b==IDLE && b_payload_valid;
    wire choose_b=lookup_pending?lookup_b:(candidate_b && (!candidate_a || prefer_b));
    wire [15:0] selected_vl=choose_b?b_payload_vlid:a_payload_vlid;
    wire [15:0] selected_len=choose_b?b_length:a_length;
    wire [15:0] selected_flen=choose_b?b_frame_length:a_frame_length;
    wire [7:0] selected_sn=choose_b?b_sn:a_sn;
    wire selected_bad=choose_b?b_payload_bad:a_payload_bad;
    wire selected_sop=choose_b?b_payload_sop:a_payload_sop;
    wire [31:0] selected_time=USE_ARRIVAL_TIMESTAMP?
        (choose_b?b_arrival_timestamp:a_arrival_timestamp):rtc_timestamp;
    wire known=selected_vl>=VL_ID_BASE && selected_vl<VL_ID_BASE+VL_NUM;
    wire [15:0] idx=selected_vl-VL_ID_BASE;
    assign lmax_index=idx;
    wire [31:0] cfg_max=INDEXED_LMAX?{16'd0,indexed_lmax}:(known?vl_cfg_lmax[idx*32+:32]:0);
    wire [31:0] max_len=cfg_max==0?LMAX_DEFAULT:cfg_max;
    wire previous_valid=known?(choose_b?psn_q[17]:psn_q[16]):0;
    wire [7:0] previous_sn=choose_b?psn_q[15:8]:psn_q[7:0];
    function [7:0] inc_sn;
        input [7:0] v;
        begin inc_sn=v==255?8'd1:v+1'b1;end
    endfunction
    wire ic_ok=!previous_valid || selected_sn==0 || selected_sn==inc_sn(previous_sn) || selected_sn==inc_sn(inc_sn(previous_sn));
    // A late opposite-path copy can follow several newer accepted frames.
    // Comparing only the last accepted SN would deliver that copy again.
    wire history_duplicate;
    afdx_rm_window #(.DEPTH(RM_DEPTH),.WINDOW_TICKS(SKEW_TICKS)) redundancy_window(
        .history(rm_q),.channel_b(choose_b),.sequence_number(selected_sn),
        .arrival_time(selected_time),.duplicate(history_duplicate));
    wire duplicate=known && history_duplicate;
    wire selected_fragment=FRAGMENT_ENABLE && (choose_b?b_fragment:a_fragment);
    assign out_fragment=FRAGMENT_ENABLE && (output_b?b_fragment:a_fragment);
    wire oversize=selected_len>1471 || selected_flen>max_len;
    wire bad_length=selected_len==0 || selected_flen!=(selected_fragment?(selected_len<25?16'd64:selected_len+16'd39):(selected_len<17?16'd64:selected_len+16'd47)) || !selected_sop;
    wire rejected=selected_bad || !known || !ic_ok || oversize || bad_length || duplicate;
    wire decide=lookup_pending && (rejected || !output_busy);
    always @(posedge clk)begin
        if(known)begin psn_q<=psn_mem[idx[INIT_AW-1:0]];rm_q<=rm_mem[idx[INIT_AW-1:0]];end
        if(!reset && initializing)begin
            psn_mem[init_index]<=0;rm_mem[init_index]<=0;
        end else if(!reset && decide && known && !selected_bad)begin
            psn_mem[idx[INIT_AW-1:0]]<=choose_b?{1'b1,psn_q[16],selected_sn,psn_q[7:0]}:
                {psn_q[17],1'b1,psn_q[15:8],selected_sn};
            if(!rejected)rm_mem[idx[INIT_AW-1:0]]<=
                (selected_sn==0?{RM_WIDTH{1'b0}}:(rm_q<<42)) |
                {{(RM_WIDTH-42){1'b0}},1'b1,choose_b,selected_time,selected_sn};
        end
    end
    assign a_payload_ready=!reset && (state_a==DROP || (state_a==PASS && out_payload_ready));
    assign b_payload_ready=!reset && (state_b==DROP || (state_b==PASS && out_payload_ready));
    assign out_payload_valid=!reset && output_busy && (output_b?b_payload_valid:a_payload_valid);
    assign out_payload_data=output_b?b_payload_data:a_payload_data;
    assign out_payload_sop=output_b?b_payload_sop:a_payload_sop;
    assign out_payload_eop=output_b?b_payload_eop:a_payload_eop;
    assign out_payload_vlid=output_b?b_payload_vlid:a_payload_vlid;
    assign out_src_port=output_b?b_src_port:a_src_port;
    assign out_dst_port=output_b?b_dst_port:a_dst_port;
    assign out_src_ip=output_b?b_src_ip:a_src_ip;
    assign out_dst_ip=output_b?b_dst_ip:a_dst_ip;
    assign out_payload_length=output_b?b_length:a_length;
    always @(posedge clk or posedge reset)begin
        if(reset)begin
            state_a<=IDLE;state_b<=IDLE;output_busy<=0;output_b<=0;prefer_b<=0;
            lookup_pending<=0;lookup_b<=0;initializing<=1;init_index<=0;
            stat_rx_frame_cnt<=0;stat_err_crc<=0;stat_err_sn<=0;
            stat_drop_redundant<=0;stat_drop_oversize<=0;stat_drop_unknown<=0;stat_bad_length<=0;
        end else begin
            if(initializing)begin
                if(init_index==VL_NUM-1)begin initializing<=0;init_index<=0;end
                else init_index<=init_index+1'b1;
            end
            if(a_crc_err || b_crc_err)stat_err_crc<=stat_err_crc+{31'd0,a_crc_err}+{31'd0,b_crc_err};
            if(a_payload_valid && a_payload_ready && a_payload_eop)state_a<=IDLE;
            if(b_payload_valid && b_payload_ready && b_payload_eop)state_b<=IDLE;
            if(out_payload_valid && out_payload_ready && out_payload_eop)begin
                output_busy<=0;stat_rx_frame_cnt<=stat_rx_frame_cnt+1'b1;
            end
            if(!lookup_pending)begin
                if(candidate_a || candidate_b)begin lookup_pending<=1;lookup_b<=choose_b;end
            end else if(decide)begin
                lookup_pending<=0;prefer_b<=!choose_b;
                if(rejected)begin
                    if(choose_b)state_b<=DROP;else state_a<=DROP;
                    if(!selected_bad)begin
                        if(!known)stat_drop_unknown<=stat_drop_unknown+1'b1;
                        else if(!ic_ok)stat_err_sn<=stat_err_sn+1'b1;
                        else if(oversize)stat_drop_oversize<=stat_drop_oversize+1'b1;
                        else if(bad_length)stat_bad_length<=stat_bad_length+1'b1;
                        else if(duplicate)stat_drop_redundant<=stat_drop_redundant+1'b1;
                    end
                end else begin
                    if(choose_b)state_b<=PASS;else state_a<=PASS;
                    output_busy<=1;output_b<=choose_b;
                end
            end
        end
    end
endmodule

// Each entry is {valid, network, 32-bit arrival timestamp, 8-bit SN}.
// Use full timestamps so long idle periods cannot alias a truncated timer.
module afdx_rm_window #(
    parameter DEPTH=7, WINDOW_TICKS=5
) (
    input wire [42*DEPTH-1:0] history,
    input wire channel_b,
    input wire [7:0] sequence_number,
    input wire [31:0] arrival_time,
    output reg duplicate
);
    integer h;
    reg [31:0] delta,skew;
    always @*begin
        duplicate=0;delta=0;skew=0;
        for(h=0;h<DEPTH;h=h+1)begin
            // Handles servicing out of arrival order and timestamp wrap.
            delta=arrival_time-history[h*42+8+:32];
            skew=delta[31]?(32'd0-delta):delta;
            if(history[h*42+41] && history[h*42+40]!=channel_b &&
               history[h*42+:8]==sequence_number && skew<=WINDOW_TICKS)
                duplicate=1;
        end
    end
endmodule
