`timescale 1ns / 1ns
module afdx_rx_stats (
    input  wire        clk, reset,
    input  wire        p_a_rx, p_b_rx,
    input  wire        p_a_crc, p_b_crc,
    input  wire        p_a_sn, p_b_sn,
    input  wire        p_a_red, p_b_red,
    input  wire        p_a_ovs, p_b_ovs,
    output reg  [31:0] stat_rx_frame_cnt,
    output reg  [31:0] stat_err_crc,
    output reg  [31:0] stat_err_sn,
    output reg  [31:0] stat_drop_redundant,
    output reg  [31:0] stat_drop_oversize
);
always @(posedge clk or posedge reset) begin
    if (reset) begin
        stat_rx_frame_cnt   <= 32'd0;
        stat_err_crc        <= 32'd0;
        stat_err_sn         <= 32'd0;
        stat_drop_redundant <= 32'd0;
        stat_drop_oversize  <= 32'd0;
    end
    else begin
        if (p_a_rx  || p_b_rx)  stat_rx_frame_cnt   <= stat_rx_frame_cnt   + 32'd1;
        if (p_a_crc || p_b_crc) stat_err_crc        <= stat_err_crc        + 32'd1;
        if (p_a_sn  || p_b_sn)  stat_err_sn         <= stat_err_sn         + 32'd1;
        if (p_a_red || p_b_red) stat_drop_redundant <= stat_drop_redundant + 32'd1;
        if (p_a_ovs || p_b_ovs) stat_drop_oversize  <= stat_drop_oversize  + 32'd1;
    end
end

endmodule
