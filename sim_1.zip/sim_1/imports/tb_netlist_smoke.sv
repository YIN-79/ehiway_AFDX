`timescale 1ns/1ps
// External-port-only smoke test shared by RTL and the existing full VQM.
module tb_netlist_smoke #(parameter TX_DIAGNOSTIC=0,
    BYTE_NS=8,CYCLES_PER_MS=125000,
    STARTUP_CYCLES=6000,SCHEDULE_PHASE=10000,GUARD_CYCLES=125000);
    reg clk=0; always #(BYTE_NS/2) clk=~clk;
    reg reset=1,lv=0,ls=0,le=0,wr=0;
    reg [7:0] ld=0,addr=0;
    reg [31:0] wd=0;
    wire [7:0] a,b,ud;
    wire av,bv,ar,br,lr,uv,us,ue,busy,locked;
    wire [31:0] rd,rtc;
    integer accepted=0,received=0,frames=0,af=0,bf=0;
    reg prev_a=0,prev_b=0;
    time input_first,output_first;
    localparam N=81;
    AFDX_competition_top dut(
        .clk(clk),.reset(reset),
        .tx_a_data(a),.tx_a_valid(av),.tx_a_ready(ar),
        .rx_a_data(a),.rx_a_valid(av),.rx_a_ready(1'b1),
        .tx_b_data(b),.tx_b_valid(bv),.tx_b_ready(br),
        .rx_b_data(b),.rx_b_valid(bv),.rx_b_ready(1'b1),
        .host_load_data(ld),.host_load_valid(lv),.host_load_ready(lr),
        .host_load_sop(ls),.host_load_eop(le),.host_load_vlid(16'd0),.host_load_length(16'd81),
        .host_unload_data(ud),.host_unload_valid(uv),.host_unload_ready(1'b1),
        .host_unload_sop(us),.host_unload_eop(ue),
        .mib_addr(addr),.mib_wr_en(wr),.mib_wr_data(wd),.mib_rd_data(rd),.mib_busy(busy),
        .rtc_timestamp(rtc),.rtc_pps_in(1'b0),.rtc_sync_locked(locked));
    task write_reg(input [7:0] address,input [31:0] value);
        @(negedge clk); while(busy!==1'b0) @(negedge clk);
        addr=address;wd=value;wr=1;
        @(negedge clk);wr=0;
    endtask
    task read_check(input [7:0] address,input [31:0] value);
        @(negedge clk);addr=address;
        repeat(2)@(negedge clk);
        $display("SMOKE MIB time_ns=%0d address=%h value=%h expected=%h",$time,address,rd,value);
        if(rd!==value)$fatal(1,"SMOKE MIB readback failed address=%h",address);
    endtask
    always @(posedge clk) if(!reset) begin
        if(lv && lr)begin
            if(accepted==0)input_first=$time;
            accepted++;
        end
        if(av && !prev_a)af++;
        if(bv && !prev_b)bf++;
        prev_a=av;prev_b=bv;
        if(uv===1'b1)begin
            if(received>=N)$fatal(1,"SMOKE duplicate/extra application data");
            if(ud!==((received*17+8'h35)&255))$fatal(1,"SMOKE payload byte=%0d got=%h",received,ud);
            if(us!==(received==0) || ue!==(received==N-1))$fatal(1,"SMOKE SOP/EOP byte=%0d",received);
            if(received==0)output_first=$time;
            received++;
            if(ue)frames++;
        end
    end
    initial begin
        repeat(8)@(negedge clk);reset=0;
        // Allow all 4096 RX entries to initialize before traffic.
        repeat(16)@(negedge clk);
        if($isunknown({lr,uv,av,bv,ar,br,busy,rtc}))$fatal(1,"SMOKE persistent unknown controls after initialization");
        $display("SMOKE initialized time_ns=%0d",$time);
        @(negedge clk);addr=8'h4a;repeat(2)@(negedge clk);
        $display("SMOKE scheduler_tick=%0d time_ns=%0d",rd,$time);
        if(rd===32'd0 || $isunknown(rd))$fatal(1,"SMOKE scheduler tick is not running");
        if(!TX_DIAGNOSTIC)begin
            if(STARTUP_CYCLES<4096)$fatal(1,"SMOKE RX startup must cover 4096 entries");
            repeat(STARTUP_CYCLES-16)@(negedge clk);
        end
        write_reg(8'h40,0);write_reg(8'h41,1);write_reg(8'h42,1518);
        write_reg(8'h45,CYCLES_PER_MS);write_reg(8'h46,TX_DIAGNOSTIC?256:SCHEDULE_PHASE);write_reg(8'h47,1);
        read_check(8'h45,CYCLES_PER_MS);read_check(8'h46,TX_DIAGNOSTIC?256:SCHEDULE_PHASE);
        read_check(8'h47,1);read_check(8'h49,0);
        for(integer j=0;j<N;j++)begin
            @(negedge clk);lv=1;ls=(j==0);le=(j==N-1);ld=(j*17+8'h35)&255;
            @(posedge clk);while(lr!==1'b1)@(posedge clk);
        end
        @(negedge clk);lv=0;ls=0;le=0;
        $display("SMOKE submitted bytes=%0d time_ns=%0d",accepted,$time);
        if(TX_DIAGNOSTIC)begin
            repeat(500)@(negedge clk);
            read_check(8'h20,1);read_check(8'h28,0);read_check(8'h29,0);
            if(af!=1 || bf!=1)$fatal(1,"TX DIAGNOSTIC missing wire frames A=%0d B=%0d",af,bf);
            $display("TX DIAGNOSTIC PASS accepted=%0d A=%0d B=%0d (RX initialization deliberately not awaited)",accepted,af,bf);
            $finish;
        end
        wait(frames==1);
        // Continue observing after both redundant copies, catching duplicates.
        repeat(GUARD_CYCLES)@(negedge clk);
        if(accepted!=N || received!=N || frames!=1 || af!=1 || bf!=1)
            $fatal(1,"SMOKE totals accepted=%0d received=%0d frames=%0d A=%0d B=%0d",accepted,received,frames,af,bf);
        $display("SMOKE PASS accepted=%0d received=%0d frames=%0d A=%0d B=%0d first_byte_latency_ns=%0d",accepted,received,frames,af,bf,output_first-input_first);
        $finish;
    end
    initial begin #5000000;$fatal(1,"SMOKE watchdog accepted=%0d received=%0d A=%0d B=%0d",accepted,received,af,bf);end
endmodule
