`timescale 1ns/1ps
module afdx_joint_traffic(
    input wire clk,reset,start,
    output reg [7:0] s_data=0,output reg s_valid=0,output reg s_sop=0,s_eop=0,
    output reg [15:0] s_length=0,s_vlid=0,input wire s_ready,
    input wire [7:0] m_data,input wire m_valid,m_ready,m_sop,m_eop,
    input wire [15:0] m_length,m_vlid,
    output reg submitted=0,output integer business_frames=0,capacity_frames=0,
    output integer business_bytes=0,overlap_frames=0,input wire download_busy
);
    integer received[0:126];bit [4095:0] rx_seen=0;
    integer position=0,current_vl=0,current_round=0,wanted=0;
    function integer payload_size(input integer v,input integer r);
        case((v+r)%4)0:return 1;1:return 81;2:return 465;default:return 1471;endcase
    endfunction
    initial begin
        for(integer v=0;v<127;v++)received[v]=0;
        wait(!reset && start);
        for(integer r=0;r<4;r++)for(integer v=0;v<127;v++)begin
            @(negedge clk);s_length=payload_size(v,r);s_vlid=v;
            for(integer b=0;b<s_length;b++)begin
                s_data=(v*17+r*29+b)&255;s_valid=1;s_sop=b==0;s_eop=b==s_length-1;
                @(posedge clk);while(!s_ready)@(posedge clk);
                @(negedge clk);
            end
            s_valid=0;s_sop=0;s_eop=0;
        end
        submitted=1;
    end
    always @(posedge clk)if(!reset && m_valid && m_ready)begin
        if(m_sop)begin
            if(position)$fatal(1,"JOINT business nested SOP");
            current_vl=m_vlid;
            if(current_vl<127)begin
                current_round=received[current_vl];
                if(current_round>=4)$fatal(1,"JOINT duplicate business delivery VL=%0d",current_vl);
                wanted=payload_size(current_vl,current_round);
            end else if(current_vl>=128 && current_vl<4096)begin
                if(rx_seen[current_vl])$fatal(1,"JOINT duplicate capacity delivery");wanted=1;
            end else $fatal(1,"JOINT unexpected business VL %0d",current_vl);
            if(m_length!=wanted)$fatal(1,"JOINT business descriptor length");
        end
        if(current_vl<127)begin
            if(m_data!==((current_vl*17+current_round*29+position)&255))$fatal(1,"JOINT business payload VL=%0d byte=%0d",current_vl,position);
            business_bytes++;
        end else if(m_data!==((current_vl^8'ha5)&255))$fatal(1,"JOINT capacity payload");
        position++;
        if(m_eop)begin
            if(position!=wanted)$fatal(1,"JOINT business payload boundary");
            rx_seen[current_vl]=1;
            if(current_vl<127)begin
                received[current_vl]++;business_frames++;if(download_busy)overlap_frames++;
            end else capacity_frames++;
            position=0;
        end
    end
    task wait_business;
        wait(submitted && business_frames==508);
    endtask
    task finish_check;
        wait(capacity_frames==3968);
        if(!overlap_frames)$fatal(1,"JOINT no concurrent business and 615A traffic");
        for(integer v=0;v<127;v++)if(received[v]!=4)$fatal(1,"JOINT per-VL frame coverage");
        for(integer v=0;v<4096;v++)if(v!=127 && !rx_seen[v])$fatal(1,"JOINT RX VL coverage missing %0d",v);
        $display("JOINT BUSINESS SUMMARY frames=%0d bytes=%0d vls=127 rounds=4 capacity_frames=%0d overlap_frames=%0d",business_frames,business_bytes,capacity_frames,overlap_frames);
    endtask
endmodule
