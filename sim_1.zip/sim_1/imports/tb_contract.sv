`timescale 1ns/1ps
// Independent wire and host scoreboards. SN is checked independently of round.
// Timing scope includes application first-byte acceptance and first-byte delivery.
// Default TWO_ENDPOINTS=1 measures two endpoints through test-only channels.
// Set TWO_ENDPOINTS=0 explicitly for the original local-loopback diagnostics.
// SFD boundary results apply to that channel model, not an unknown real PHY.
module tb_contract #(
    parameter VL_COUNT=128, ROUNDS=4, MODE=0, FIXED_PAYLOAD_BYTES=1471,
    parameter PERIOD_CYCLES=4000000, FIRST_CYCLE=1500000,
    parameter SLOT_CYCLES=20000, LEAD_CYCLES=1250000, BAG_MS=32,
    parameter STALL_PERIOD_CYCLES=10000, STALL_CYCLES=1000,
    parameter SEED=32'h13579bdf,
    // 0: legacy fixed arrival; 1: random bounded arrival; 2: reversed
    // neighboring requests; 3: simultaneous requests; 4: window extremes;
    // 5: submit one entire VL cohort before its first scheduled transmission.
    parameter ARRIVAL_MODE=5, LEAD_MIN_CYCLES=56250, LEAD_MAX_CYCLES=58750,
    parameter HOST_PAUSE_CYCLES=640, COMPENSATE_LATENCY=0,
    parameter ALTERNATE_COHORT_ORDER=1,
    // Host timers are diagnostic; they are not the user's GMII SFD timers.
    parameter HOST_TIMING_CHECKS=0,
    parameter REQUIRE_LENGTH_COVERAGE=(MODE!=2),
    parameter MIN_CONCURRENT_VLS=(VL_COUNT>1?2:1),
    parameter REQUIRE_ALL_QUEUED=(ARRIVAL_MODE==5 && VL_COUNT>1),
    parameter TWO_ENDPOINTS=1, GMII_BYTE_NS=8,
    parameter LINK_A_BASE_NS=10000, LINK_A_SPREAD_NS=20000,
    parameter LINK_B_BASE_NS=20000, LINK_B_SPREAD_NS=10000,
    parameter LINK_DROP_FRAME=-1, parameter longint WATCHDOG_NS=600000000
);
    reg clk=0; always #(GMII_BYTE_NS/2) clk=~clk;
    reg reset=1, lv=0, ls=0, le=0, wr=0;
    reg [7:0] ld=0, addr=0;
    reg [15:0] vl=0, len=0;
    reg [31:0] wd=0;
    wire lr, uv, us, ue, av, bv;
    wire [7:0] ud, ad, bd;
    wire [15:0] uvl, ulen;
    wire [31:0] rd;
    wire [7:0] local_ud,remote_ud,link_ad,link_bd;
    wire local_uv,local_us,local_ue,remote_uv,remote_us,remote_ue,link_av,link_bv;
    wire [15:0] local_uvl,local_ulen,remote_uvl,remote_ulen;
    wire [31:0] remote_rd;
    wire [31:0] gmii_frames_a,gmii_frames_b,gmii_pending_a,gmii_pending_b;
    wire [31:0] gmii_errors_a,gmii_errors_b;
    wire [63:0] gmii_latency_a,gmii_latency_b,gmii_jitter_a,gmii_jitter_b;
    assign ud=TWO_ENDPOINTS?remote_ud:local_ud;
    assign uv=TWO_ENDPOINTS?remote_uv:local_uv;
    assign us=TWO_ENDPOINTS?remote_us:local_us;
    assign ue=TWO_ENDPOINTS?remote_ue:local_ue;
    assign uvl=TWO_ENDPOINTS?remote_uvl:local_uvl;
    assign ulen=TWO_ENDPOINTS?remote_ulen:local_ulen;
    integer cycle=0, errors=0, received_frames=0, received_bytes=0;
    integer rx_count[0:VL_COUNT-1], wire_seen[0:1][0:VL_COUNT-1];
    integer sizes[0:ROUNDS-1][0:VL_COUNT-1];
    time accepted[0:ROUNDS-1][0:VL_COUNT-1];
    time requested[0:ROUNDS-1][0:VL_COUNT-1];
    time source_sfd_times[0:ROUNDS-1][0:VL_COUNT-1];
    time receive_boundary,source_processing,receive_processing;
    time worst_source_processing_ns=0,worst_receive_processing_ns=0;
    time event_due[0:ROUNDS*VL_COUNT-1];
    integer event_vl[0:ROUNDS*VL_COUNT-1],event_round[0:ROUNDS*VL_COUNT-1];
    time previous_start[0:1][0:VL_COUNT-1];
    time minimum_interval[0:1][0:VL_COUNT-1], maximum_interval[0:1][0:VL_COUNT-1];
    time epoch, target, latency, first_byte_latency, input_interval;
    time minimum_input_interval=64'hffffffffffffffff,maximum_input_interval=0;
    time interval_ns, planned, slot_late;
    time worst_latency=0, worst_jitter=0, worst_slot_late=0;
    time worst_first_byte_latency=0;
    time worst_interval_jitter=0,worst_accepted_jitter=0,e2e_spread,accepted_spread;
    time minimum_latency_by_vl[0:VL_COUNT-1],maximum_latency_by_vl[0:VL_COUNT-1];
    time minimum_request_by_vl[0:VL_COUNT-1],maximum_request_by_vl[0:VL_COUNT-1];
    integer jitter_violations=0;
    integer first_byte_jitter_violations=0;
    time worst_request_latency=0,worst_source_wait=0,request_latency,source_wait;
    time minimum_request_latency=64'hffffffffffffffff;
    integer wire_count[0:1], wire_frames[0:1], gap[0:1];
    reg was_valid[0:1];
    reg [7:0] packet[0:1][0:1525];
    time wire_start[0:1];
    integer rx_vl=0, rx_round=0, rx_position=0, total, id, round_no, n;
    integer expected_sn, first_sn_seen=0, wrap_seen=0;
    // Wire lengths include DA through FCS, excluding preamble/SFD and IFG.
    reg [3:0] length_coverage[0:1][0:VL_COUNT-1];
    integer frame64[0:1],frame128[0:1],frame512[0:1],frame1518[0:1];
    integer queued_vls=0,peak_queued_vls=0,concurrency_cycles=0,coverage_bin,ip_sum;
    reg [VL_COUNT-1:0] concurrent_vls_seen=0;
    reg receiving=0, held=0;
    reg [41:0] held_data;
    reg [31:0] rng;
    integer reordered_requests=0,simultaneous_requests=0;
    integer selected_event,swap_vl,swap_round,event_index,lead_cycles;
    time swap_due;
    wire ur=(cycle%STALL_PERIOD_CYCLES)>=STALL_CYCLES;

    initial begin
        if(GMII_BYTE_NS<2 || GMII_BYTE_NS%2)
            $fatal(1,"GMII byte period must be a positive even number of ns");
        else if(1000000000%GMII_BYTE_NS)
            $fatal(1,"GMII byte period must divide 1 second in ns");
    end
    AFDX_top #(.HOST_FRAMED(1),.TX_VL_NUM(VL_COUNT),.RX_VL_NUM(4096),
        .CLK_FREQ(1000000000/GMII_BYTE_NS),
        .TIMED_TX(1),.COMPENSATE_LATENCY(COMPENSATE_LATENCY),.RX_SLOTS(32),.ENABLE_HW_SNMP(0)) dut (
        .clk(clk),.reset(reset),.tx_a_data(ad),.tx_a_valid(av),.tx_a_ready(),
        .tx_b_data(bd),.tx_b_valid(bv),.tx_b_ready(),
        .rx_a_data(TWO_ENDPOINTS?8'd0:ad),.rx_a_valid(TWO_ENDPOINTS?1'b0:av),.rx_a_ready(1'b1),
        .rx_b_data(TWO_ENDPOINTS?8'd0:bd),.rx_b_valid(TWO_ENDPOINTS?1'b0:bv),.rx_b_ready(1'b1),
        .host_load_data(ld),.host_load_valid(lv),.host_load_ready(lr),
        .host_load_sop(ls),.host_load_eop(le),.host_load_vlid(vl),.host_load_length(len),
        .host_unload_data(local_ud),.host_unload_valid(local_uv),.host_unload_ready(TWO_ENDPOINTS?1'b1:ur),
        .host_unload_sop(local_us),.host_unload_eop(local_ue),.host_unload_vlid(local_uvl),.host_unload_length(local_ulen),
        .host_unload_src_port(),.host_unload_dst_port(),.host_unload_src_ip(),.host_unload_dst_ip(),
        .host_load_header_valid(1'b0),.host_load_src_port(16'd0),.host_load_dst_port(16'd0),
        .host_load_src_ip(32'd0),.host_load_dst_ip(32'd0),
        .mib_addr(addr),.mib_wr_en(wr),.mib_wr_data(wd),.mib_rd_data(rd),.mib_busy(),
        .rtc_timestamp(),.rtc_sync_valid(1'b0),.rtc_sync_timestamp(32'd0),
        .rtc_pps_in(1'b0),.rtc_sync_locked());

    generate if(TWO_ENDPOINTS)begin:g_network
        afdx_test_link #(.BASE_NS(LINK_A_BASE_NS),.SPREAD_NS(LINK_A_SPREAD_NS),
            .COHORT(VL_COUNT),.BYTE_NS(GMII_BYTE_NS),.DROP_FRAME(LINK_DROP_FRAME)) link_a(
            .reset(reset),.source_data(ad),.source_valid(av),
            .destination_data(link_ad),.destination_valid(link_av),.queue_adjustments());
        afdx_test_link #(.BASE_NS(LINK_B_BASE_NS),.SPREAD_NS(LINK_B_SPREAD_NS),
            .COHORT(VL_COUNT),.BYTE_NS(GMII_BYTE_NS),.DROP_FRAME(LINK_DROP_FRAME)) link_b(
            .reset(reset),.source_data(bd),.source_valid(bv),
            .destination_data(link_bd),.destination_valid(link_bv),.queue_adjustments());
        AFDX_top #(.HOST_FRAMED(1),.TX_VL_NUM(1),.RX_VL_NUM(4096),
            .CLK_FREQ(1000000000/GMII_BYTE_NS),
            .RX_SLOTS(32),.ENABLE_HW_SNMP(0)) receiver(
            .clk(clk),.reset(reset),
            .tx_a_data(),.tx_a_valid(),.tx_a_ready(),.tx_b_data(),.tx_b_valid(),.tx_b_ready(),
            .rx_a_data(link_ad),.rx_a_valid(link_av),.rx_a_ready(1'b1),
            .rx_b_data(link_bd),.rx_b_valid(link_bv),.rx_b_ready(1'b1),
            .host_load_data(8'd0),.host_load_valid(1'b0),.host_load_ready(),
            .host_load_sop(1'b0),.host_load_eop(1'b0),.host_load_vlid(16'd0),.host_load_length(16'd0),
            .host_load_header_valid(1'b0),.host_load_src_port(16'd0),.host_load_dst_port(16'd0),
            .host_load_src_ip(32'd0),.host_load_dst_ip(32'd0),
            .host_unload_data(remote_ud),.host_unload_valid(remote_uv),.host_unload_ready(ur),
            .host_unload_sop(remote_us),.host_unload_eop(remote_ue),
            .host_unload_vlid(remote_uvl),.host_unload_length(remote_ulen),
            .host_unload_src_port(),.host_unload_dst_port(),.host_unload_src_ip(),.host_unload_dst_ip(),
            .mib_addr(addr),.mib_wr_en(1'b0),.mib_wr_data(32'd0),.mib_rd_data(remote_rd),.mib_busy(),
            .rtc_timestamp(),.rtc_sync_valid(1'b0),.rtc_sync_timestamp(32'd0),
            .rtc_pps_in(1'b0),.rtc_sync_locked());
    end else begin:g_loopback_only
        assign link_ad=0;assign link_bd=0;assign link_av=0;assign link_bv=0;
        assign remote_ud=0;assign remote_uv=0;assign remote_us=0;assign remote_ue=0;
        assign remote_uvl=0;assign remote_ulen=0;assign remote_rd=0;
    end endgenerate
    gmii_sfd_monitor #(.VL_COUNT(VL_COUNT),.BYTE_NS(GMII_BYTE_NS),.LANE(0),
        .SFD_START_TO_START(1)) sfd_a(
        .clk(clk),.reset(reset),.source_data(ad),.source_valid(av && TWO_ENDPOINTS),
        .destination_data(link_ad),.destination_valid(link_av),
        .checked_frames(gmii_frames_a),.pending_frames(gmii_pending_a),.errors(gmii_errors_a),
        .worst_latency_ns(gmii_latency_a),.worst_jitter_ns(gmii_jitter_a));
    gmii_sfd_monitor #(.VL_COUNT(VL_COUNT),.BYTE_NS(GMII_BYTE_NS),.LANE(1),
        .SFD_START_TO_START(1)) sfd_b(
        .clk(clk),.reset(reset),.source_data(bd),.source_valid(bv && TWO_ENDPOINTS),
        .destination_data(link_bd),.destination_valid(link_bv),
        .checked_frames(gmii_frames_b),.pending_frames(gmii_pending_b),.errors(gmii_errors_b),
        .worst_latency_ns(gmii_latency_b),.worst_jitter_ns(gmii_jitter_b));

    function automatic [31:0] random_next(input [31:0] state);
        reg [31:0] x;
        begin x=state^(state<<13);x=x^(x>>17);random_next=x^(x<<5);end
    endfunction
    function automatic [7:0] payload(input integer v,input integer r,input integer pos);
        payload=(v*17+r*53+pos*7+(SEED&255))&255;
    endfunction
    function automatic [31:0] reference_crc(input integer port,input integer last);
        reg [31:0] c; reg feedback;
        begin
            c=32'hffffffff;
            for(integer j=8;j<=last;j++)for(integer b=0;b<8;b++)begin
                feedback=c[0]^packet[port][j][b];c=c>>1;
                if(feedback)c=c^32'hedb88320;
            end
            reference_crc=~c;
        end
    endfunction
    task check(input bit good,input string message);
        if(good!==1'b1)begin
            errors++;$display("CONTRACT FAIL time=%0t %s",$time,message);
            if(errors>=10)$fatal(1,"contract error limit");
        end
    endtask
    task write_reg(input integer address,input integer value);
        @(negedge clk);addr=address;wd=value;wr=1;
        @(negedge clk);wr=0;
    endtask
    task read_check(input integer address,input integer value,input bit remote=0);
        @(negedge clk);addr=address;#1;
        check((remote?remote_rd:rd)===value,
            $sformatf("MIB receiver=%0d %02h expected %0d got %0d",remote,address,value,remote?remote_rd:rd));
    endtask
    task send_frame(input integer r,input integer v);
        integer waited;
        @(negedge clk);vl=v;len=sizes[r][v];
        for(integer j=0;j<sizes[r][v];j++)begin
            @(negedge clk);lv=1;ls=j==0;le=j==sizes[r][v]-1;ld=payload(v,r,j);
            @(posedge clk);waited=0;
            while(lr!==1'b1 && waited<500000)begin waited++;@(posedge clk);end
            if(waited==500000)$fatal(1,"load handshake timeout");
            if(j==0)begin
                accepted[r][v]=$time;
                if(r>0)begin
                    input_interval=accepted[r][v]-accepted[r-1][v];
                    if(input_interval<minimum_input_interval)minimum_input_interval=input_interval;
                    if(input_interval>maximum_input_interval)maximum_input_interval=input_interval;
                    if(!ALTERNATE_COHORT_ORDER)
                        check(input_interval>=BAG_MS*1000000,
                            "per-VL application first-byte interval is shorter than BAG");
                end
            end
            // Bound the time the host itself pauses inside a complete frame.
            // Pauses and ready waits remain inside the request-to-delivery timer.
            if(HOST_PAUSE_CYCLES>0 && j==sizes[r][v]/2 && j<sizes[r][v]-1)begin
                @(negedge clk);lv=0;
                repeat(HOST_PAUSE_CYCLES-1)@(negedge clk);
            end
        end
        @(negedge clk);lv=0;ls=0;le=0;
    endtask

    // Observe complete per-VL queues after the RTL's clocked updates settle.
    // This distinguishes actual concurrent buffering from sequential VL use.
    always @(negedge clk)if(!reset)begin
        queued_vls=$countones(dut.u_afdx_tx_core.queued);
        if(queued_vls>peak_queued_vls)peak_queued_vls=queued_vls;
        if(queued_vls>=2)begin
            concurrency_cycles++;
            concurrent_vls_seen=concurrent_vls_seen|dut.u_afdx_tx_core.queued;
        end
    end

    always @(posedge clk)if(!reset)begin
        cycle++;
        if(held)check(uv && {us,ue,uvl,ulen,ud}===held_data,"RX changes during backpressure");
        held=uv&&!ur;held_data={us,ue,uvl,ulen,ud};
        if(uv && ur)begin
            if(!receiving)begin
                check(us && uvl<VL_COUNT,"RX SOP and VLID");
                rx_vl=uvl;rx_round=rx_count[rx_vl];rx_position=0;receiving=1;
                if(rx_round>=ROUNDS)$fatal(1,"extra RX frame");
                first_byte_latency=$time-accepted[rx_round][rx_vl];
                if(HOST_TIMING_CHECKS)
                    check(first_byte_latency<2000000,"application first-byte latency >=2ms");
                if(first_byte_latency>worst_first_byte_latency)
                    worst_first_byte_latency=first_byte_latency;
                if(first_byte_latency<minimum_latency_by_vl[rx_vl])
                    minimum_latency_by_vl[rx_vl]=first_byte_latency;
                if(first_byte_latency>maximum_latency_by_vl[rx_vl])
                    maximum_latency_by_vl[rx_vl]=first_byte_latency;
            end else check(!us,"nested RX SOP");
            check(uvl==rx_vl && ulen==sizes[rx_round][rx_vl],"RX descriptor");
            check(ud===payload(rx_vl,rx_round,rx_position),"RX payload");
            check(ue==(rx_position==sizes[rx_round][rx_vl]-1),"RX EOP");
            rx_position++;received_bytes++;
            if(ue)begin
                if(TWO_ENDPOINTS)begin
                    receive_boundary='1;
                    if(sfd_a.frames_by_vl[rx_vl]==rx_round+1)
                        receive_boundary=sfd_a.last_destination_end_by_vl[rx_vl];
                    if(sfd_b.frames_by_vl[rx_vl]==rx_round+1 &&
                       sfd_b.last_destination_end_by_vl[rx_vl]<receive_boundary)
                        receive_boundary=sfd_b.last_destination_end_by_vl[rx_vl];
                    check(receive_boundary!='1,"host delivery without a matching receive SFD");
                    source_processing=source_sfd_times[rx_round][rx_vl]-accepted[rx_round][rx_vl];
                    receive_processing=$time-receive_boundary;
                    if(source_processing>worst_source_processing_ns)worst_source_processing_ns=source_processing;
                    if(receive_processing>worst_receive_processing_ns)worst_receive_processing_ns=receive_processing;
                end
                latency=$time-accepted[rx_round][rx_vl];
                if(latency>worst_latency)worst_latency=latency;
                if(HOST_TIMING_CHECKS)check(latency<1000000,"host-first-byte to host-last-byte >=1ms");
                request_latency=$time-requested[rx_round][rx_vl];
                if(request_latency>worst_request_latency)worst_request_latency=request_latency;
                if(request_latency<minimum_request_latency)minimum_request_latency=request_latency;
                if(request_latency<minimum_request_by_vl[rx_vl])minimum_request_by_vl[rx_vl]=request_latency;
                if(request_latency>maximum_request_by_vl[rx_vl])maximum_request_by_vl[rx_vl]=request_latency;
                source_wait=accepted[rx_round][rx_vl]-requested[rx_round][rx_vl];
                if(source_wait>worst_source_wait)worst_source_wait=source_wait;
                if(HOST_TIMING_CHECKS)check(request_latency<1000000,"request-to-delivery >=1ms (includes host queue and ready)");
                rx_count[rx_vl]++;received_frames++;receiving=0;
            end
        end
        for(integer p=0;p<2;p++)begin
            if(p?bv:av)begin
                if(!was_valid[p])begin
                    check(gap[p]>=12,"IFG <12 bytes");wire_start[p]=$time;
                end
                if(wire_count[p]>=1526)$fatal(1,"wire frame >1518 plus preamble");
                packet[p][wire_count[p]]=p?bd:ad;wire_count[p]++;gap[p]=0;
            end else begin
                gap[p]++;
                if(was_valid[p])begin
                    total=wire_count[p];id={packet[p][12],packet[p][13]};
                    if(id>=VL_COUNT)$fatal(1,"wire VLID out of range");
                    round_no=wire_seen[p][id];
                    if(round_no>=ROUNDS)$fatal(1,"extra wire frame");
                    n=sizes[round_no][id];expected_sn=1+(round_no%255);
                    source_sfd_times[round_no][id]=wire_start[p]+7*GMII_BYTE_NS;
                    check(packet[p][total-5]===expected_sn,"wire SN must be 1..255 then 1");
                    if(round_no==0)first_sn_seen++;
                    if(round_no==255)wrap_seen++;
                    check(total==((n<17)?72:n+55),"wire length and padding");
                    check(total>=72 && total<=1526,"complete frame outside 64..1518 bytes");
                    check($time-wire_start[p]==total*GMII_BYTE_NS,"GMII continuous-byte serialization");
                    coverage_bin=-1;
                    case(total-8)
                        64:begin frame64[p]++;coverage_bin=0;end
                        128:begin frame128[p]++;coverage_bin=1;end
                        512:begin frame512[p]++;coverage_bin=2;end
                        1518:begin frame1518[p]++;coverage_bin=3;end
                    endcase
                    if(coverage_bin>=0)length_coverage[p][id][coverage_bin]=1;
                    for(integer j=0;j<7;j++)check(packet[p][j]===8'h55,"preamble");
                    check(packet[p][7]===8'hd5,"SFD");
                    check({packet[p][8],packet[p][9],packet[p][10],packet[p][11]}===32'h03000000,"destination MAC prefix");
                    check({packet[p][20],packet[p][21]}===16'h0800,"IPv4 EtherType");
                    check({packet[p][24],packet[p][25]}==n+28,"IPv4 length");
                    check({packet[p][46],packet[p][47]}==n+8,"UDP length");
                    ip_sum=0;
                    for(integer j=22;j<42;j+=2)ip_sum+={packet[p][j],packet[p][j+1]};
                    ip_sum=(ip_sum&65535)+(ip_sum>>16);
                    ip_sum=(ip_sum&65535)+(ip_sum>>16);
                    check(ip_sum==65535,"IPv4 header checksum");
                    for(integer j=0;j<n;j++)check(packet[p][50+j]===payload(id,round_no,j),"wire payload");
                    for(integer j=50+n;j<total-5;j++)check(packet[p][j]===8'h00,"zero Ethernet padding");
                    check({packet[p][total-1],packet[p][total-2],packet[p][total-3],packet[p][total-4]}===reference_crc(p,total-5),"wire FCS");
                    planned=epoch+GMII_BYTE_NS*(FIRST_CYCLE+SLOT_CYCLES*id+PERIOD_CYCLES*round_no);
                    if(COMPENSATE_LATENCY)
                        planned=planned+GMII_BYTE_NS*(2997-((n<17?64:n+47)+8+n));
                    check(wire_start[p]>=planned,"early slot launch");
                    slot_late=wire_start[p]-planned;
                    if(slot_late>worst_slot_late)worst_slot_late=slot_late;
                    check(slot_late<=50000,"slot lateness >50us");
                    if(round_no>0)begin
                        interval_ns=wire_start[p]-previous_start[p][id];
                        check(interval_ns>=BAG_MS*1000000,"wire BAG violation");
                        if(interval_ns<minimum_interval[p][id])minimum_interval[p][id]=interval_ns;
                        if(interval_ns>maximum_interval[p][id])maximum_interval[p][id]=interval_ns;
                    end
                    previous_start[p][id]=wire_start[p];wire_seen[p][id]++;
                    wire_frames[p]++;wire_count[p]=0;
                end
            end
            was_valid[p]=p?bv:av;
        end
    end

    initial begin
        if(TWO_ENDPOINTS)begin
            $display("TIMING SCOPE source_TX_SFD_start_to_destination_RX_SFD_start; GMII_SFD_ACCEPTANCE=CHANNEL_MODEL_ONLY");
            $display("LINK MODEL A_base_ns=%0d A_spread_ns=%0d B_base_ns=%0d B_spread_ns=%0d",LINK_A_BASE_NS,LINK_A_SPREAD_NS,LINK_B_BASE_NS,LINK_B_SPREAD_NS);
        end else
            $display("TIMING SCOPE host_request_to_host_last_byte; GMII_SFD_ACCEPTANCE=NOT_MEASURED (direct loopback)");
        if(ROUNDS<3 || VL_COUNT<1 || VL_COUNT>128 || MODE<0 || MODE>2 ||
           ARRIVAL_MODE<0 || ARRIVAL_MODE>5 || MIN_CONCURRENT_VLS<1 ||
           MIN_CONCURRENT_VLS>VL_COUNT || FIXED_PAYLOAD_BYTES<1 ||
           FIXED_PAYLOAD_BYTES>1471)$fatal(1,"invalid test dimensions");
        if(ROUNDS>255 && MODE!=2)
            $fatal(1,"more than 255 rounds requires fixed 1471-byte payload mode");
        if(REQUIRE_LENGTH_COVERAGE && ROUNDS<4)$fatal(1,"four rounds required for per-VL length coverage");
        rng=SEED;
        for(integer v=0;v<VL_COUNT;v++)begin
            rx_count[v]=0;
            minimum_latency_by_vl[v]=64'hffffffffffffffff;maximum_latency_by_vl[v]=0;
            minimum_request_by_vl[v]=64'hffffffffffffffff;maximum_request_by_vl[v]=0;
            for(integer r=0;r<ROUNDS;r++)begin
                rng=random_next(rng);
                if(MODE==2)sizes[r][v]=FIXED_PAYLOAD_BYTES;
                else if(MODE==1 && r>=4)sizes[r][v]=1+rng%1471;
                else case((v+r)%4)
                    // This RTL adds 47 bytes; short frames are padded to 64.
                    // payload 1/81/465/1471 -> frame 64/128/512/1518.
                    0:sizes[r][v]=1;1:sizes[r][v]=81;
                    2:sizes[r][v]=465;3:sizes[r][v]=1471;
                endcase
            end
        end
        for(integer p=0;p<2;p++)begin
            wire_count[p]=0;wire_frames[p]=0;gap[p]=100;was_valid[p]=0;
            frame64[p]=0;frame128[p]=0;frame512[p]=0;frame1518[p]=0;
            for(integer v=0;v<VL_COUNT;v++)begin
                length_coverage[p][v]=0;
                wire_seen[p][v]=0;previous_start[p][v]=0;
                minimum_interval[p][v]=64'hffffffffffffffff;maximum_interval[p][v]=0;
            end
        end
        repeat(4)@(negedge clk);reset=0;epoch=$time;
        for(integer v=0;v<VL_COUNT;v++)begin
            write_reg(8'h40,v);write_reg(8'h41,BAG_MS);write_reg(8'h42,1518);
            write_reg(8'h45,PERIOD_CYCLES);write_reg(8'h46,FIRST_CYCLE+SLOT_CYCLES*v);write_reg(8'h47,1);
        end
        if(ARRIVAL_MODE==5)begin
            if(FIRST_CYCLE<=LEAD_CYCLES)$fatal(1,"burst starts before reset release");
            for(integer r=0;r<ROUNDS;r++)begin
                target=epoch+GMII_BYTE_NS*(FIRST_CYCLE-LEAD_CYCLES+PERIOD_CYCLES*r);
                for(integer v=0;v<VL_COUNT;v++)requested[r][v]=target;
                while($time<target)@(negedge clk);
                // Alternate host submission order; wire scheduling must still
                // preserve each VL's own frame order, phase and BAG.
                for(integer k=0;k<VL_COUNT;k++)
                    send_frame(r,ALTERNATE_COHORT_ORDER && r[0]?VL_COUNT-1-k:k);
                check($time<epoch+GMII_BYTE_NS*(FIRST_CYCLE+PERIOD_CYCLES*r-1480),
                    "VL cohort not fully loaded before first MAC prefetch");
                if((r+1)%16==0 || r==ROUNDS-1)
                    $display("CONTRACT PROGRESS rounds=%0d/%0d frames_submitted=%0d sim_time_ns=%0d",
                        r+1,ROUNDS,(r+1)*VL_COUNT,$time);
            end
        end else if(ARRIVAL_MODE==0)begin
            for(integer r=0;r<ROUNDS;r++)begin
                for(integer v=0;v<VL_COUNT;v++)begin
                    target=epoch+GMII_BYTE_NS*(FIRST_CYCLE-LEAD_CYCLES+SLOT_CYCLES*v+PERIOD_CYCLES*r);
                    requested[r][v]=target;
                    while($time<target)@(negedge clk);
                    check($time<=target+2*GMII_BYTE_NS,"source misses its arrival contract");
                    send_frame(r,v);
                end
                if((r+1)%16==0 || r==ROUNDS-1)
                    $display("CONTRACT PROGRESS rounds=%0d/%0d frames_submitted=%0d sim_time_ns=%0d",
                        r+1,ROUNDS,(r+1)*VL_COUNT,$time);
            end
        end else begin
            if(LEAD_MIN_CYCLES<1 || LEAD_MAX_CYCLES<LEAD_MIN_CYCLES ||
               FIRST_CYCLE<=LEAD_MAX_CYCLES)$fatal(1,"invalid random arrival window");
            // Requests exist independently of the one-byte host interface. Sort
            // by application request time, then submit FIFO; an older request is
            // NOT moved later just because the driver is busy or ready is low.
            for(integer r=0;r<ROUNDS;r++)for(integer v=0;v<VL_COUNT;v++)begin
                rng=random_next(rng);
                if(ARRIVAL_MODE==1)lead_cycles=LEAD_MIN_CYCLES+rng%(LEAD_MAX_CYCLES-LEAD_MIN_CYCLES+1);
                else if(ARRIVAL_MODE==2)lead_cycles=v[0]?LEAD_MAX_CYCLES:LEAD_MIN_CYCLES;
                else if(ARRIVAL_MODE==3)lead_cycles=LEAD_MIN_CYCLES+(v[0]?SLOT_CYCLES:0);
                else lead_cycles=r[0]?LEAD_MAX_CYCLES:LEAD_MIN_CYCLES;
                check(lead_cycles>=LEAD_MIN_CYCLES && lead_cycles<=LEAD_MAX_CYCLES,"request outside admitted arrival window");
                event_index=r*VL_COUNT+v;
                event_due[event_index]=epoch+GMII_BYTE_NS*(FIRST_CYCLE+SLOT_CYCLES*v+PERIOD_CYCLES*r-lead_cycles);
                requested[r][v]=event_due[event_index];event_vl[event_index]=v;event_round[event_index]=r;
            end
            for(integer e=0;e<ROUNDS*VL_COUNT;e++)begin
                selected_event=e;
                for(integer k=e+1;k<ROUNDS*VL_COUNT;k++)
                    if(event_due[k]<event_due[selected_event] ||
                       (event_due[k]==event_due[selected_event] && event_vl[k]>event_vl[selected_event]))selected_event=k;
                swap_due=event_due[e];swap_vl=event_vl[e];swap_round=event_round[e];
                event_due[e]=event_due[selected_event];event_vl[e]=event_vl[selected_event];event_round[e]=event_round[selected_event];
                event_due[selected_event]=swap_due;event_vl[selected_event]=swap_vl;event_round[selected_event]=swap_round;
            end
            for(integer e=0;e<ROUNDS*VL_COUNT;e++)begin
                if(e>0)begin
                    if(event_round[e]==event_round[e-1] && event_vl[e]<event_vl[e-1])reordered_requests++;
                    if(event_due[e]==event_due[e-1])simultaneous_requests++;
                end
                while($time<event_due[e])@(negedge clk);
                send_frame(event_round[e],event_vl[e]);
            end
            if(ARRIVAL_MODE==2 && LEAD_MAX_CYCLES-LEAD_MIN_CYCLES>SLOT_CYCLES)
                check(reordered_requests>0,"adversarial requests did not reverse slot order");
            if(ARRIVAL_MODE==3)check(simultaneous_requests>0,"simultaneous requests not exercised");
        end
        wait(received_frames==ROUNDS*VL_COUNT);
        // A fast network may complete host delivery well before the last
        // redundant copy arrives on the slower network.
        if(TWO_ENDPOINTS)wait(gmii_frames_a==ROUNDS*VL_COUNT && gmii_frames_b==ROUNDS*VL_COUNT);
        repeat(5000)@(negedge clk);
        for(integer p=0;p<2;p++)begin
            check(wire_frames[p]==ROUNDS*VL_COUNT,"wire frame total");
            for(integer v=0;v<VL_COUNT;v++)begin
                check(rx_count[v]==ROUNDS && wire_seen[p][v]==ROUNDS,"per-VL coverage");
                if(REQUIRE_LENGTH_COVERAGE)
                    check(length_coverage[p][v]===4'b1111,
                        $sformatf("port %0d VL %0d missing 64/128/512/1518-byte frame",p,v));
                interval_ns=maximum_interval[p][v]-minimum_interval[p][v];
                if(interval_ns>worst_interval_jitter)worst_interval_jitter=interval_ns;
            end
        end
        for(integer v=0;v<VL_COUNT;v++)begin
            e2e_spread=maximum_request_by_vl[v]-minimum_request_by_vl[v];
            accepted_spread=maximum_latency_by_vl[v]-minimum_latency_by_vl[v];
            if(e2e_spread>worst_jitter)worst_jitter=e2e_spread;
            if(accepted_spread>worst_accepted_jitter)worst_accepted_jitter=accepted_spread;
            if(e2e_spread>50000)jitter_violations++;
            if(accepted_spread>50000)first_byte_jitter_violations++;
            if(ROUNDS>255)
                $display("APPLICATION VL vl=%0d frames=%0d min_first_byte_ns=%0d max_first_byte_ns=%0d jitter_ns=%0d",
                    v,rx_count[v],minimum_latency_by_vl[v],maximum_latency_by_vl[v],accepted_spread);
            $display("HOST E2E VL vl=%0d frames=%0d minimum_ns=%0d maximum_ns=%0d jitter_ns=%0d",v,rx_count[v],minimum_request_by_vl[v],maximum_request_by_vl[v],e2e_spread);
        end
        if(HOST_TIMING_CHECKS)begin
            check(jitter_violations==0,"per-VL request-to-delivery delay variation >50us");
            check(first_byte_jitter_violations==0,"per-VL accepted-first-byte to delivered-first-byte jitter >50us");
        end
        check(peak_queued_vls>=MIN_CONCURRENT_VLS,"insufficient simultaneous complete VL queues");
        if(REQUIRE_ALL_QUEUED)begin
            check(peak_queued_vls==VL_COUNT,"not all VLs queued concurrently");
            check(concurrent_vls_seen=={VL_COUNT{1'b1}},"missing VL in concurrent queue coverage");
        end
        check(first_sn_seen==2*VL_COUNT,"first SN checked on every VL and port");
        if(ROUNDS>255)check(wrap_seen==2*VL_COUNT,"255-to-1 wrap checked");
        read_check(8'h20,ROUNDS*VL_COUNT);read_check(8'h21,ROUNDS*VL_COUNT,TWO_ENDPOINTS);
        read_check(8'h24,ROUNDS*VL_COUNT,TWO_ENDPOINTS);read_check(8'h49,0);read_check(8'h48,0);
        for(integer a=8'h22;a<=8'h2b;a++)if(a!=8'h24)read_check(a,0,TWO_ENDPOINTS && a!=8'h28 && a!=8'h29);
        if(TWO_ENDPOINTS)begin
            read_check(8'h21,0);
            sfd_a.finish_check(ROUNDS);sfd_b.finish_check(ROUNDS);
            check(gmii_errors_a==0 && gmii_errors_b==0,"GMII SFD timing or frame matching errors");
            check(gmii_frames_a==ROUNDS*VL_COUNT && gmii_frames_b==ROUNDS*VL_COUNT,"GMII matched frame coverage");
            $display("GMII SUMMARY matched_a=%0d matched_b=%0d pending_a=%0d pending_b=%0d errors_a=%0d errors_b=%0d worst_latency_a_ns=%0d worst_latency_b_ns=%0d worst_jitter_a_ns=%0d worst_jitter_b_ns=%0d",gmii_frames_a,gmii_frames_b,gmii_pending_a,gmii_pending_b,gmii_errors_a,gmii_errors_b,gmii_latency_a,gmii_latency_b,gmii_jitter_a,gmii_jitter_b);
            $display("ENDPOINT SUMMARY worst_source_processing_ns=%0d worst_receive_processing_ns=%0d",worst_source_processing_ns,worst_receive_processing_ns);
        end
        $display("CONTRACT SUMMARY fail=%0d frames=%0d bytes=%0d vl=%0d rounds=%0d mode=%0d worst_frame_completion_ns=%0d worst_request_jitter_ns=%0d worst_slot_late_ns=%0d first_sn_checks=%0d wrap_checks=%0d",errors,received_frames,received_bytes,VL_COUNT,ROUNDS,MODE,worst_latency,worst_jitter,worst_slot_late,first_sn_seen,wrap_seen);
        $display("APPLICATION TIMING SUMMARY metric=accepted_first_byte_to_delivered_first_byte worst_latency_ns=%0d worst_same_vl_jitter_ns=%0d",worst_first_byte_latency,worst_accepted_jitter);
        $display("APPLICATION INPUT SUMMARY min_same_vl_interval_ns=%0d max_same_vl_interval_ns=%0d configured_bag_ns=%0d",
            minimum_input_interval,maximum_input_interval,BAG_MS*1000000);
        $display("ARRIVAL SUMMARY arrival_mode=%0d worst_request_latency_ns=%0d minimum_request_latency_ns=%0d worst_source_wait_ns=%0d reordered_requests=%0d simultaneous_requests=%0d host_pause_cycles=%0d",ARRIVAL_MODE,worst_request_latency,minimum_request_latency,worst_source_wait,reordered_requests,simultaneous_requests,HOST_PAUSE_CYCLES);
        $display("JITTER SUMMARY worst_request_to_last_byte_jitter_ns=%0d worst_accepted_first_byte_jitter_ns=%0d request_violating_vls=%0d first_byte_violating_vls=%0d worst_interval_jitter_ns=%0d",worst_jitter,worst_accepted_jitter,jitter_violations,first_byte_jitter_violations,worst_interval_jitter);
        $display("COVERAGE SUMMARY frame64_a=%0d frame128_a=%0d frame512_a=%0d frame1518_a=%0d frame64_b=%0d frame128_b=%0d frame512_b=%0d frame1518_b=%0d peak_queued_vls=%0d concurrency_cycles=%0d length_coverage_required=%0d host_timing_checks=%0d",frame64[0],frame128[0],frame512[0],frame1518[0],frame64[1],frame128[1],frame512[1],frame1518[1],peak_queued_vls,concurrency_cycles,REQUIRE_LENGTH_COVERAGE,HOST_TIMING_CHECKS);
        if(errors)$fatal(1,"CONTRACT FAIL");
        $display("===== CONTRACT PASS =====");$finish;
    end
    initial begin #(WATCHDOG_NS);
        $fatal(1,"contract watchdog: missing host delivery or incomplete frame; GMII pending A=%0d B=%0d",gmii_pending_a,gmii_pending_b);
    end
endmodule
