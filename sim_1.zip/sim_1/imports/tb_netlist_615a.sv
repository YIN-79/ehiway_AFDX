`timescale 1ns/1ps
// External loader BFM. Target is the exact fixed-parameter synthesis top.
// No RTL target substitute, hierarchical reads, force, or compressed DUT timers.
module tb_netlist_615a #(parameter LONG_RETRY=0);
    localparam INTEGRATED=1,LIMITS=0,DALLY_TEST=0,JOINT=0;
    reg clk=0;always #4 clk=~clk;
    reg reset=1,cw=0;reg [7:0] ca=0;reg [31:0] cd=0;
    wire [31:0] cr;wire mib_busy;
    reg [7:0] rdbyte=0;reg rv=0;
    wire [7:0] ta,tb;wire tav,tbv,leak;
    reg busy=0;reg [15:0] status=0;
    reg [31:0] completed=0,failed=0,retries=0,ce=0;
    reg [15:0] vl=0;reg [31:0] sip=32'h0a000002,dip=32'h0a000001;
    integer fail=0,packets=0,consumed=0,output_length=0;
    reg [7:0] request[0:1023],output_packet[0:515],assembled[0:4095];
    reg [15:0] output_source,output_destination;
    integer sizes[0:7],delivered_files=0,delivered_bytes=0,status_files=0,list_files=0;
    integer final_status=0,init_tid=0,control_tid=0,source_counter=51000;
    integer drop_block=0,dropped=0;
    bit abort_next_file=0,exhaust_next_file=0,selection_active=0;
    // Timer-driven lost-ACK/exhaustion tests need >=1s at the actual DUT defaults.
    // This normal-flow suite explicitly avoids claiming those long tests ran.
    bit init_ack_loss_tested=1,status_query_tested=0,parallel_query_tested=1;
    reg [7:0] saved_final[0:515],saved_snapshot[0:515];
    integer saved_snapshot_length,saved_length,saved_tid,saved_block,dally_checks=0;
    reg [7:0] txframe[0:1599],bframe[0:1599],inframe[0:1599];integer txpos=0,sn=0;
    reg last_valid=0;time tx_start;
    AFDX_competition_top target(
        .clk(clk),.reset(reset),.tx_a_data(ta),.tx_a_valid(tav),.tx_a_ready(),
        .tx_b_data(tb),.tx_b_valid(tbv),.tx_b_ready(),
        .rx_a_data(rdbyte),.rx_a_valid(rv),.rx_a_ready(1'b1),
        .rx_b_data(rdbyte),.rx_b_valid(rv),.rx_b_ready(1'b1),
        .host_load_data(8'd0),.host_load_valid(1'b0),.host_load_sop(1'b0),.host_load_eop(1'b0),
        .host_load_vlid(16'd0),.host_load_length(16'd0),.host_load_ready(),
        .host_unload_data(),.host_unload_valid(leak),.host_unload_ready(1'b1),
        .host_unload_sop(),.host_unload_eop(),
        .mib_addr(ca),.mib_wr_en(cw),.mib_wr_data(cd),.mib_rd_data(cr),.mib_busy(mib_busy),
        .rtc_pps_in(1'b0),.rtc_timestamp(),.rtc_sync_locked());
    function [31:0] crc_byte(input [31:0] prior,input [7:0] d);
        reg [31:0] c;c=prior;
        for(integer k=0;k<8;k++)c=(c[0]^d[k])?((c>>1)^32'hedb88320):(c>>1);
        return c;
    endfunction
    task write_config(input [7:0] address,input [31:0] val);
        @(negedge clk);while(mib_busy!==0)@(negedge clk);
        ca=address;cd=val;cw=1;@(negedge clk);cw=0;
    endtask
    task read_mib(input [7:0] address,output reg [31:0] val);
        @(negedge clk);ca=address;repeat(2)@(negedge clk);
        if($isunknown(cr))$fatal(1,"615A unknown MIB %h",address);val=cr;
    endtask
    task poll_status;
        reg [31:0] v;
        read_mib(8'hb7,v);busy=v[16];status=v[15:0];
        read_mib(8'hb8,completed);read_mib(8'hb9,failed);
        read_mib(8'hba,retries);read_mib(8'hbb,ce);
    endtask
    task take;
        integer count;count=0;
        while(packets==consumed && count<(LONG_RETRY?250000000:500000))begin @(negedge clk);count++;end
        if(packets==consumed)$fatal(1,"615A missing wire response");consumed++;
    endtask
    task joint_controls;endtask
    task send(input integer n,input integer sport,input integer dport);
        integer total,sum;reg [15:0] ck;reg [31:0] c;
        if(n>1024)$fatal(1,"loader request too large");
        total=(n<17?64:n+47)+8;
        for(integer j=0;j<total;j++)inframe[j]=0;
        for(integer j=0;j<7;j++)inframe[j]=8'h55;
        inframe[7]=8'hd5;inframe[8]=3;inframe[12]=vl>>8;inframe[13]=vl;
        inframe[14]=2;inframe[19]=8'h20;inframe[20]=8'h08;inframe[22]=8'h45;
        inframe[24]=(n+28)>>8;inframe[25]=n+28;inframe[28]=8'h40;inframe[30]=8'h40;inframe[31]=17;
        for(integer j=0;j<4;j++)begin inframe[34+j]=sip>>(24-j*8);inframe[38+j]=dip>>(24-j*8);end
        inframe[42]=sport>>8;inframe[43]=sport;inframe[44]=dport>>8;inframe[45]=dport;
        inframe[46]=(n+8)>>8;inframe[47]=n+8;
        sum=0;for(integer j=22;j<42;j+=2)sum+={inframe[j],inframe[j+1]};
        sum=(sum&65535)+(sum>>16);sum=(sum&65535)+(sum>>16);ck=~sum[15:0];
        inframe[32]=ck>>8;inframe[33]=ck;
        for(integer j=0;j<n;j++)inframe[50+j]=request[j];
        sn=sn==255?1:sn+1;inframe[total-5]=sn;c=32'hffffffff;
        for(integer j=8;j<total-4;j++)c=crc_byte(c,inframe[j]);c=~c;
        for(integer j=0;j<4;j++)inframe[total-4+j]=c>>(8*j);
        @(negedge clk);
        for(integer j=0;j<total;j++)begin rv=1;rdbyte=inframe[j];@(negedge clk);end
        rv=0;repeat(12)@(negedge clk);
    endtask
    always @(posedge clk)if(!reset)begin
        if(leak)$fatal(1,"615A management packet leaked to application");
        if(tav!==tbv)$fatal(1,"615A A/B valid alignment");
        if(tav)begin
            if(txpos==0)tx_start=$time;
            if(txpos>=1600)$fatal(1,"615A wire overflow");txframe[txpos]=ta;bframe[txpos]=tb;txpos++;
        end
        if(last_valid && !tav)begin
            capture_response();txpos=0;
        end
        last_valid=tav;
    end
    task capture_response;
        reg [31:0] c;integer n,sum;
        if(packets!=consumed)$fatal(1,"loader response buffer overrun");
        if(txpos<72 || txpos>1526 || txframe[7]!=8'hd5)$fatal(1,"615A wire length/SFD");
        c=32'hffffffff;for(integer j=8;j<txpos;j++)c=crc_byte(c,txframe[j]);
        if(c!==32'hdebb20e3)$fatal(1,"615A response FCS");
        c=32'hffffffff;for(integer j=8;j<txpos;j++)c=crc_byte(c,bframe[j]);
        if(c!==32'hdebb20e3)$fatal(1,"615A B response FCS");
        for(integer j=50;j<txpos-4;j++)if(txframe[j]!==bframe[j])$fatal(1,"615A A/B payload/SN mismatch");
        sum=0;for(integer j=22;j<42;j+=2)sum+={txframe[j],txframe[j+1]};
        sum=(sum&65535)+(sum>>16);sum=(sum&65535)+(sum>>16);
        if(sum!=65535 || {txframe[12],txframe[13]}!=127)$fatal(1,"615A response IP/VL");
        n={txframe[46],txframe[47]}-8;
        if(n<4 || n>516)$fatal(1,"615A UDP response length");
        if({txframe[34],txframe[35],txframe[36],txframe[37]}!=32'h0a000001 ||
           {txframe[38],txframe[39],txframe[40],txframe[41]}!=32'h0a000002)$fatal(1,"615A response IP addresses");
        output_length=n;output_source={txframe[42],txframe[43]};output_destination={txframe[44],txframe[45]};
        for(integer j=0;j<n;j++)output_packet[j]=txframe[50+j];packets++;
    endtask
    task check(input bit good,input string message);
        if(!good)begin fail++;$fatal(1,"615A FAIL: %s status=%h",message,status);end
    endtask
    function string file_name(input integer id);
        string text;
        if(LIMITS)begin text="abcdefghijklmnopqrstuvwxyzABCDE0";text.putc(31,"0"+id);end
        else if(id==0)text="a.bin";else if(id==1)text="b.bin";else text="c.bin";
        return text;
    endfunction
    task ack(input integer block_id,input integer from_port,input integer to_port);
        request[0]=0;request[1]=4;request[2]=block_id>>8;request[3]=block_id;
        send(4,from_port,to_port);
    endtask
    task request_file(input bit writing,input string name,input integer source_port);
        integer p;
        request[0]=0;request[1]=writing?2:1;p=2;
        for(integer b=0;b<name.len();b++)begin request[p]=name.getc(b);p++;end
        request[p]=0;request[p+1]="o";request[p+2]="c";request[p+3]="t";request[p+4]="e";request[p+5]="t";request[p+6]=0;
        send(p+7,source_port,69);
    endtask
    task receive_push;
        string name;
        integer p,client,loader,block_id,last_block,total,n,id,reader;
        bit done,aborted;
        check(output_packet[0]==0 && output_packet[1]==2,"expected target WRQ");
        name="";p=2;
        while(p<output_length && output_packet[p]!=0)begin name={name,output_packet[p]};p++;end
        check(output_destination==69,"target starts TFTP at loader port 69");
        client=output_source;source_counter++;loader=source_counter;total=0;last_block=0;done=0;aborted=0;
        if(name=="TARGET.LNL" && !parallel_query_tested)begin
            // Hold the list's ACK0 while independently polling status. Also
            // lose the snapshot ACK to exercise both independent retry timers.
            request_file(0,"TARGET.LNS",50003);take();reader=output_source;
            check(output_packet[1]==3 && output_packet[8]=="A" && output_packet[9]=="3","status read while LNL push is pending");
            saved_snapshot_length=output_length;
            for(integer b=0;b<output_length;b++)saved_snapshot[b]=output_packet[b];
            request_file(0,"TARGET.LNS",50003);take();
            check(output_source==reader && output_packet[1]==3,"repeated status RRQ keeps snapshot TID");
            check(output_length==saved_snapshot_length,"repeated snapshot length stays fixed");
            for(integer b=0;b<saved_snapshot_length;b++)
                check(output_packet[b]===saved_snapshot[b],$sformatf("repeated snapshot byte %0d",b));
            take();
            while(output_source==client && output_packet[1]==2)take();
            check(output_source==reader && output_packet[1]==3,"snapshot retransmits after lost ACK");
            check(output_length==saved_snapshot_length,"retried snapshot length stays fixed");
            for(integer b=0;b<saved_snapshot_length;b++)
                check(output_packet[b]===saved_snapshot[b],$sformatf("retried snapshot byte %0d",b));
            ack(1,50003,reader);parallel_query_tested=1;
        end
        if(exhaust_next_file && name=="c.bin")begin
            exhaust_next_file=0;aborted=1;done=1;
            for(integer attempt=0;attempt<(INTEGRATED?5:2);attempt++)begin
                take();check(output_source==client && output_packet[1]==2,"WRQ retries before exhaustion");
            end
        end else if(abort_next_file && name=="c.bin")begin
            abort_next_file=0;aborted=1;done=1;
            request[0]=0;request[1]=5;request[2]=0;request[3]=0;
            request[4]="A";request[5]="B";request[6]="O";request[7]="R";request[8]="T";request[9]=":";
            request[10]="1";request[11]="0";request[12]="0";request[13]="5";request[14]=0;
            send(15,loader,client);
        end else ack(0,loader,client);
        while(!done)begin
            take();
            check(output_source==client && output_destination==loader,"TFTP transfer IDs");
            check(output_packet[0]==0 && output_packet[1]==3,"expected target DATA");
            block_id={output_packet[2],output_packet[3]};n=output_length-4;
            if(block_id!=last_block)begin
                check(block_id==(last_block==65535?1:last_block+1),"TFTP block order");
                for(integer b=0;b<n;b++)assembled[total+b]=output_packet[4+b];
                total+=n;last_block=block_id;
            end
            if(name=="c.bin" && block_id==drop_block && !dropped)begin
                dropped=1;
            end else begin ack(block_id,loader,client);if(n<512)done=1;end
        end
        if(!aborted)begin
            if(name=="TARGET.LNS")begin
                status_files++;final_status={assembled[6],assembled[7]};
                check({assembled[0],assembled[1],assembled[2],assembled[3]}==total && assembled[4]=="A" && assembled[5]=="3","LNS binary header");
                n=15+assembled[8];
                if(final_status==3)check({assembled[n],assembled[n+1],assembled[n+2]}==24'h313030,"completed load ratio 100");
                if(final_status>=16'h1000)check(assembled[8]>1,"failure status includes a reason");
                n=19+assembled[8];id=assembled[n];p=n+1;
                check(id<=(LIMITS?8:3),"status selected file count is bounded");
                for(integer f=0;f<id;f++)begin
                    n=assembled[p];p++;name="";
                    check(n>=2 && n<=33 && p+n+4<=total,"status filename bounds");
                    for(integer b=0;b<n-1;b++)begin name={name,assembled[p]};p++;end
                    check(name==file_name(f) && assembled[p]==0,"status selected filename and terminator");
                    p++;
                    check(assembled[p+2]==1 && assembled[p+3]==0,"status file description terminator");p+=4;
                end
                check(p==total,"status entries consume the complete file");
            end else if(name=="TARGET.LNL")begin
                list_files++;check({assembled[6],assembled[7]}==(LIMITS?8:3),"operator list export count");
                p=8;
                for(integer f=0;f<(LIMITS?8:3);f++)begin
                    n=assembled[p];p++;name="";
                    check(n>=2 && n<=33 && p+n+2<=total,"list filename bounds");
                    for(integer b=0;b<n-1;b++)begin name={name,assembled[p]};p++;end
                    check(name==file_name(f) && assembled[p]==0,"list export filename and terminator");
                    check(assembled[p+1]==1 && assembled[p+2]==0,"list file description terminator");p+=3;
                end
                check(p==total,"list entries consume the complete file");
            end else begin
                id=-1;for(integer f=0;f<(LIMITS?8:3);f++)if(name==file_name(f))id=f;
                if(id<0)$fatal(1,"615A unexpected export name %s",name);
                check(total==sizes[id],$sformatf("file %s size",name));
                for(integer b=0;b<total;b++)if(assembled[b]!==((id*53+b)&255))$fatal(1,"615A file data mismatch %s byte=%0d actual=%h",name,b,assembled[b]);
                delivered_files++;delivered_bytes+=total;
            end
        end
    endtask
    task pump;
        integer quiet,limit;
        quiet=0;limit=0;
        while(limit<(LONG_RETRY?250000000:2000000))begin
            if(packets!=consumed)begin take();receive_push();quiet=0;end
            else begin @(negedge clk);quiet++;limit++;end
            if(quiet>=150000)begin
                poll_status();
                if(!selection_active || !busy)return;
                quiet=0;
            end
        end
        $fatal(1,"615A operation did not finish");
    endtask
    task initialize(input bit operator_defined);
        request_file(0,operator_defined?"TARGET.LNO":"TARGET.LND",50000);
        take();init_tid=output_source;
        check(output_packet[1]==3 && output_packet[3]==1 && output_length==14,"initialization DATA1");
        request_file(0,operator_defined?"TARGET.LNO":"TARGET.LND",50000);
        take();check(output_source==init_tid && output_packet[1]==3,"lost initialization DATA retry keeps TID");
        if(!init_ack_loss_tested)begin
            take();check(output_source==init_tid && output_packet[1]==3,"lost initialization ACK triggers target DATA retry");
            init_ack_loss_tested=1;
        end
        ack(1,50000,init_tid);selection_active=0;pump();
        check(busy && status==1,"initialized operation awaits selection");
        if(!status_query_tested)begin
            request_file(0,"TARGET.LNS",50002);take();
            check(output_packet[1]==3 && output_source!=69 && output_packet[8]=="A" && output_packet[9]=="3","status RRQ uses an independent TID");
            ack(1,50002,output_source);pump();status_query_tested=1;
        end
    endtask
    task selection(input bit operator_defined,input integer count,input bit malformed);
        integer p,n;
        reg [7:0] payload[0:1023];string name;
        selection_active=1;request_file(1,operator_defined?"TARGET.LNA":"TARGET.LNR",50001);
        take();control_tid=output_source;
        check(output_packet[1]==4 && output_packet[3]==0,"selection WRQ ACK0");
        p=8;payload[4]="A";payload[5]="3";payload[6]=0;payload[7]=count;
        for(integer f=0;f<count;f++)begin
            if(malformed)name="missing.bin";
            else name=file_name(f);
            payload[p]=name.len()+1;p++;
            for(integer b=0;b<name.len();b++)begin payload[p]=name.getc(b);p++;end
            payload[p]=0;p++;
        end
        if(!operator_defined)begin
            // 8 maximum-length names plus 231 user bytes makes exactly
            // 512 bytes: TFTP must finish with a separate zero-length DATA2.
            n=LIMITS?((DALLY_TEST==1)?231:255):0;
            payload[p]=n;p++;
            for(integer b=0;b<n;b++)begin payload[p]=b;p++;end
        end
        payload[0]=p>>24;payload[1]=p>>16;payload[2]=p>>8;payload[3]=p;
        for(integer offset=0;offset<p || (offset==p && p%512==0);offset+=512)begin
            n=p-offset;if(n>512)n=512;
            request[0]=0;request[1]=3;request[2]=0;request[3]=offset/512+1;
            for(integer b=0;b<n;b++)request[b+4]=payload[offset+b];
            send(n+4,50001,control_tid);take();
            check(output_packet[1]==(malformed?5:4),"selection accepted or rejected");
            if(n<512 && !malformed)begin
                saved_length=n+4;saved_tid=control_tid;saved_block=offset/512+1;
                for(integer b=0;b<saved_length;b++)saved_final[b]=request[b];
                // Retain a copy so the loader can retry its final DATA even
                // after the target has completed the requested file pushes.
            end
        end
        pump();
        if(JOINT && !DALLY_TEST && !malformed && final_status==3)begin
            replay_final();send(saved_length,50001,saved_tid);check_final_ack();
            check(!busy,"duplicate final DATA cannot restart a completed operation");
        end
    endtask
    task replay_final;
        for(integer b=0;b<saved_length;b++)request[b]=saved_final[b];
    endtask
    task expect_quiet;
        integer before_packets;
        before_packets=packets;
        repeat(INTEGRATED?1250000:100)@(negedge clk);
        check(packets==before_packets,"unrelated or malformed packet cannot trigger a final ACK");
        dally_checks++;
    endtask
    task check_final_ack;
        take();
        check(output_length==4 && output_source==saved_tid && output_destination==50001 &&
            output_packet[1]==4 && {output_packet[2],output_packet[3]}==saved_block,
            "retained final ACK preserves original transfer IDs and block");
        dally_checks++;
    endtask
    initial begin
        string name;
        sizes[0]=0;sizes[1]=512;sizes[2]=1700;
        if(LONG_RETRY)begin init_ack_loss_tested=0;drop_block=2;end
        repeat(8)@(negedge clk);reset=0;repeat(4200)@(negedge clk);
        for(integer f=0;f<3;f++)begin
            write_config(8'hb0,f);write_config(8'hb2,sizes[f]);name=file_name(f);
            for(integer b=0;b<name.len();b++)write_config(8'hb4,name.getc(b));
            write_config(8'hb4,0);
            for(integer b=0;b<sizes[f];b++)write_config(8'hb5,(f*53+b)&255);
            write_config(8'hb6,1);
        end
        initialize(0);selection(0,3,0);
        check(!busy && final_status==3 && completed==1 && delivered_files==3,"media operation complete with empty/512B/1700B files");
        replay_final();send(saved_length,50001,saved_tid);check_final_ack();poll_status();
        check(completed==1 && !busy,"duplicate final control DATA replays ACK without restarting unload");
        initialize(1);selection(1,3,0);
        check(!busy && final_status==3 && completed==2 && delivered_files==6 && list_files==1,"operator list and file unload complete");
        initialize(0);selection(0,1,1);
        check(!busy && final_status==16'h1000 && failed==1,"unknown file denied");
        initialize(0);abort_next_file=1;selection(0,3,0);
        check(!busy && final_status==16'h1005 && failed==2,"loader abort terminates operation");
        initialize(0);selection(0,3,0);
        check(!busy && completed==3 && final_status==3,"new operation succeeds after failure");
        if(LONG_RETRY)begin
            check(retries>=2,"initialization and DATA lost-ACK timer retransmissions");
            initialize(0);exhaust_next_file=1;selection(0,3,0);
            check(!busy && final_status==16'h1004 && failed==3,"real-time retry exhaustion");
            initialize(0);selection(0,3,0);
            check(!busy && completed==4 && final_status==3,"recovery after retry exhaustion");
        end
        check(ce==0,"no configuration errors");
        $display("NETLIST 615A SUMMARY fail=%0d completed=%0d failed_expected=%0d files=%0d bytes=%0d lists=%0d statuses=%0d",fail,completed,failed,delivered_files,delivered_bytes,list_files,status_files);
        if(fail)$fatal(1,"615A external workflow failed");
        $display("===== NETLIST 615A PASS =====");$finish;
    end
    initial begin #(LONG_RETRY?64'd30000000000:64'd500000000);$fatal(1,"615A external workflow watchdog");end
initial forever begin #1000000;$display("615A PROGRESS time_ns=%0d packets=%0d consumed=%0d files=%0d bytes=%0d status=%h",$time,packets,consumed,delivered_files,delivered_bytes,status);end
endmodule
