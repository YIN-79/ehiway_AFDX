`timescale 1ns/1ps
// Actual top-level integration, 128 TX VL / 4096 RX VL, byte-clock physical input.
module tb_full_capacity;
    reg clk=0;always #4 clk=~clk;
    reg reset=1,load_valid=0,load_sop=0,load_eop=0;
    reg [7:0] load_data=0,addr=0,physical_data=0;
    reg [15:0] load_vl=0,load_length=1;
    reg wr=0,injecting=0,physical_valid=0;
    reg [31:0] wd=0;
    wire [31:0] rd,rtc;
    wire load_ready,unload_valid,txav,txbv,txai,txbi;
    wire [7:0] unload_data,txa,txb;
    reg [7:0] expected[0:8191],packet[0:1525];
    integer wanted=0,received=0,errors=0,packets_a=0,packets_b=0;
    reg previous_a=0,previous_b=0;
    AFDX_top #(.HOST_FRAMED(1),.TX_VL_NUM(128),.RX_VL_NUM(4096)) dut (
        .clk(clk),.reset(reset),.tx_a_data(txa),.tx_a_valid(txav),.tx_a_ready(txai),
        .rx_a_data(injecting?physical_data:txa),.rx_a_valid(injecting?physical_valid:txav),.rx_a_ready(1'b1),
        .tx_b_data(txb),.tx_b_valid(txbv),.tx_b_ready(txbi),
        .rx_b_data(txb),.rx_b_valid(injecting?1'b0:txbv),.rx_b_ready(1'b1),
        .host_load_data(load_data),.host_load_valid(load_valid),.host_load_ready(load_ready),
        .host_load_sop(load_sop),.host_load_eop(load_eop),.host_load_vlid(load_vl),.host_load_length(load_length),
        .host_unload_data(unload_data),.host_unload_valid(unload_valid),.host_unload_ready(1'b1),
        .mib_addr(addr),.mib_wr_en(wr),.mib_wr_data(wd),.mib_rd_data(rd),.rtc_timestamp(rtc)
    );
    task check(input bit ok,input string label_text);
        if(ok!==1'b1)begin errors++;$display("[FULL CAPACITY FAIL] %s read=%h",label_text,rd);end
        else $display("[FULL CAPACITY PASS] %s",label_text);
    endtask
    always @(posedge clk)if(!reset)begin
        if(txav&&!previous_a)packets_a++;
        if(txbv&&!previous_b)packets_b++;
        previous_a=txav;previous_b=txbv;
        if(unload_valid)begin
            if(received>=wanted||unload_data!==expected[received])begin
                errors++;$display("[FULL CAPACITY FAIL] byte index=%0d expected=%h actual=%h",received,expected[received],unload_data);
            end
            received++;
        end
    end
    task write_reg(input [7:0] address,input [31:0] value);
        @(negedge clk);addr=address;wd=value;wr=1;
        @(negedge clk);wr=0;#1;
    endtask
    task read_check(input [7:0] address,input [31:0] value,input string label_text);
        @(negedge clk);addr=address;#1;check(rd===value,label_text);
    endtask
    task drain;
        integer w;
        w=0;
        while(received<wanted&&w<5000)begin @(negedge clk);w++;end
        if(received!=wanted)$fatal(1,"full-capacity receive timeout wanted=%0d got=%0d",wanted,received);
        repeat(20)@(negedge clk);
    endtask
    task send_host(input integer id,input integer n,input bit deliver);
        integer w;
        @(negedge clk);load_vl=id;load_length=n;
        if(deliver)for(integer j=0;j<n;j++)begin expected[wanted]=(id+j)&255;wanted++;end
        for(integer j=0;j<n;j++)begin
            @(negedge clk);load_data=id+j;load_valid=1;load_sop=j==0;load_eop=j==n-1;
            w=0;@(posedge clk);while(load_ready!==1'b1&&w<20000)begin w++;@(posedge clk);end
            if(w==20000)$fatal(1,"full-capacity TX input timeout");
        end
        @(negedge clk);load_valid=0;load_sop=0;load_eop=0;
        if(deliver)drain();else repeat(300)@(negedge clk);
        wait(txai&&txbi);repeat(15)@(negedge clk);
    endtask
    // Independent physical frame construction, not a call into the MAC encoder.
    task inject(input integer id,input integer seq,input integer n,input bit deliver);
        integer frame_bytes,total,ip_length,udp_length,sum;
        reg [31:0] c;reg feedback;reg [15:0] checksum;
        @(negedge clk);
        frame_bytes=(n<17)?64:n+47;total=frame_bytes+8;
        for(integer j=0;j<total;j++)packet[j]=0;
        for(integer j=0;j<7;j++)packet[j]=8'h55;
        packet[7]=8'hd5;packet[8]=8'h03;packet[12]=id>>8;packet[13]=id;
        packet[14]=8'h02;packet[19]=8'h20;
        packet[20]=8'h08;packet[22]=8'h45;
        ip_length=n+28;udp_length=n+8;
        packet[24]=ip_length>>8;packet[25]=ip_length;
        packet[28]=8'h40;packet[30]=8'h40;packet[31]=17;
        packet[34]=10;packet[37]=1;packet[38]=10;packet[41]=2;
        packet[42]=8'h0b;packet[43]=8'hb8;packet[44]=8'h0b;packet[45]=8'hba;
        packet[46]=udp_length>>8;packet[47]=udp_length;
        sum=0;
        for(integer j=22;j<42;j+=2)sum+={packet[j],packet[j+1]};
        sum=(sum&65535)+(sum>>16);sum=(sum&65535)+(sum>>16);
        checksum=~sum[15:0];packet[32]=checksum[15:8];packet[33]=checksum[7:0];
        for(integer j=0;j<n;j++)begin
            packet[50+j]=(id^8'ha5)+j;
            if(deliver)begin expected[wanted]=packet[50+j];wanted++;end
        end
        packet[total-5]=seq;
        c=32'hffffffff;
        for(integer j=8;j<total-4;j++)for(integer bitno=0;bitno<8;bitno++)begin
            feedback=c[0]^packet[j][bitno];c=c>>1;if(feedback)c=c^32'hedb88320;
        end
        c=~c;
        for(integer j=0;j<4;j++)packet[total-4+j]=c>>(8*j);
        for(integer j=0;j<total;j++)begin
            physical_data=packet[j];physical_valid=1;@(negedge clk);
        end
        physical_valid=0;repeat(12)@(negedge clk);
        if(deliver)drain();else repeat(100)@(negedge clk);
    endtask
    initial begin
        repeat(4)@(negedge clk);reset=0;
        check(dut.u_afdx_tx_core.VL_NUM==128&&dut.u_afdx_rx_core.VL_NUM==4096,"real top core dimensions 128TX/4096RX");
        for(integer id=0;id<128;id++)send_host(id,1,1);
        read_check(8'h20,128,"128 TX frames submitted through top");
        read_check(8'h21,128,"128 loopback business frames delivered once");
        read_check(8'h24,128,"A/B redundant copies suppressed");
        check(packets_a==128&&packets_b==128,"128 wire frames on each port");
        injecting=1;
        for(integer id=0;id<4096;id++)begin
            // TX loopback has already consumed SN=1 on the first 128 VLs.
            inject(id,id<128?2:1,1,1);
            if(id%512==511)$display("[FULL CAPACITY] RX completed VL0..%0d",id);
        end
        read_check(8'h21,4224,"all 4096 receive VLs delivered through physical MAC and host FIFO");
        inject(4096,1,1,0);read_check(8'h2a,1,"VL4096 rejected as unknown");
        write_reg(8'h43,4095);write_reg(8'h44,64);
        inject(4095,2,17,1);inject(4095,3,18,0);
        read_check(8'h25,1,"indexed RX4095 LMAX rejects complete 65-byte frame");
        // Exercise the maximum legal physical frame on the highest RX VL.
        write_reg(8'h44,1518);inject(4095,4,1471,1);
        read_check(8'h21,4226,"high RX VL boundary and recovery");
        injecting=0;
        write_reg(8'h40,127);write_reg(8'h42,64);
        send_host(127,18,0);read_check(8'h28,1,"indexed TX127 LMAX affects real TX rejection");
        read_check(8'h20,128,"rejected TX frame not counted or emitted");
        read_check(8'h22,0,"no CRC errors");read_check(8'h23,0,"no SN errors");
        read_check(8'h26,0,"no protocol errors");read_check(8'h27,0,"no RX overflow");
        read_check(8'h29,0,"no descriptor errors");read_check(8'h2b,0,"no RX length errors");
        check(received==wanted,"entire top-level byte scoreboard");
        $display("FULL CAPACITY SUMMARY fail=%0d bytes=%0d TX_VL=128 RX_VL=4096",errors,received);
        $display("[LIMIT] full-count functional coverage; not sustained aggregate worst-load, independent timing guarantee, or FPGA resource fit.");
        if(errors)$fatal(1,"FULL CAPACITY FAIL");
        else begin $display("===== FULL CAPACITY FUNCTIONAL PASS =====");$finish;end
    end
    initial begin #200000000;$fatal(1,"full-capacity watchdog");end
endmodule
