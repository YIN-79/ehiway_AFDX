`timescale 1ns/1ps
// eLinx simulation top. All application traffic shares the same two real
// AFDX endpoints and the same four directed network channels.
module tb_joint #(parameter FAULT_MODE=0,LIMITS=0,DALLY_TEST=0,
    A_BASE_NS=10000,A_SPREAD_NS=20000,B_BASE_NS=20000,B_SPREAD_NS=10000);
    tb_615a_service #(.INTEGRATED(1),.JOINT(1),.NETWORK(1),.FAULT_MODE(FAULT_MODE),
        .LIMITS(LIMITS),.DALLY_TEST(DALLY_TEST),
        .A_BASE_NS(A_BASE_NS),.A_SPREAD_NS(A_SPREAD_NS),.B_BASE_NS(B_BASE_NS),.B_SPREAD_NS(B_SPREAD_NS)) test();
    wire clk=test.clk,reset=test.reset,busy=test.busy;
    wire [31:0] errors=test.fail,completed=test.completed,failed=test.failed;
    wire [31:0] files=test.delivered_files,bytes=test.delivered_bytes,retries=test.retries;
endmodule
