`timescale 1ns/1ps
// Passive, common-byte-clock observer. No link-delay parameters enter this
// monitor. Match complete frames, then use the previously captured SFD times.
module gmii_sfd_monitor #(
    parameter VL_COUNT=128, MAX_PENDING=64, BYTE_NS=8,
    parameter LATENCY_LIMIT_NS=2000000, JITTER_LIMIT_NS=50000,
    parameter LANE=0, SFD_START_TO_START=0
) (
    input wire clk,reset,
    input wire [7:0] source_data,destination_data,
    input wire source_valid,destination_valid,
    output integer checked_frames=0,pending_frames=0,errors=0,
    output time worst_latency_ns=0,worst_jitter_ns=0
);
    byte unsigned packet[0:1][0:1525];
    byte unsigned stored[0:MAX_PENDING-1][0:1525];
    integer count[0:1],stored_length[0:MAX_PENDING-1];
    integer stored_vl[0:MAX_PENDING-1],stored_sn[0:MAX_PENDING-1];
    bit occupied[0:MAX_PENDING-1];
    time sfd_start[0:1],sfd_end[0:1],stored_start[0:MAX_PENDING-1];
    integer frames_by_vl[0:VL_COUNT-1];
    time minimum_by_vl[0:VL_COUNT-1],maximum_by_vl[0:VL_COUNT-1];
    time last_destination_end_by_vl[0:VL_COUNT-1];
    integer vl,sn,slot,matched,match_count;
    bit equal_bytes;
    time delay_ns,spread_ns;

    task fail(input string message);
        errors++;
        $display("GMII FAIL lane=%0d time=%0t %s",LANE,$time,message);
    endtask

    task finish_check(input integer expected_per_vl);
        if(pending_frames!=0 || count[0]!=0 || count[1]!=0)
            fail("missing or incomplete destination frame");
        for(integer v=0;v<VL_COUNT;v++)begin
            if(frames_by_vl[v]!=expected_per_vl)
                fail($sformatf("VL %0d sample coverage %0d expected %0d",v,frames_by_vl[v],expected_per_vl));
            $display("GMII VL lane=%0d vl=%0d samples=%0d minimum_ns=%0d maximum_ns=%0d jitter_ns=%0d",LANE,v,frames_by_vl[v],minimum_by_vl[v],maximum_by_vl[v],maximum_by_vl[v]-minimum_by_vl[v]);
        end
    endtask

    always @(posedge clk)begin
        if(reset)begin
            checked_frames=0;pending_frames=0;errors=0;
            worst_latency_ns=0;worst_jitter_ns=0;
            for(integer p=0;p<2;p++)begin count[p]=0;sfd_start[p]=0;sfd_end[p]=0;end
            for(integer q=0;q<MAX_PENDING;q++)occupied[q]=0;
            for(integer v=0;v<VL_COUNT;v++)begin
                frames_by_vl[v]=0;minimum_by_vl[v]='1;maximum_by_vl[v]=0;
                last_destination_end_by_vl[v]=0;
            end
        end else begin
            // Source first also supports a zero-delay wire without an ordering
            // race between two always blocks at the end of the same frame.
            for(integer p=0;p<2;p++)begin
                if(p?destination_valid:source_valid)begin
                    if(count[p]>=1526)$fatal(1,"GMII monitor frame overflow");
                    packet[p][count[p]]=p?destination_data:source_data;
                    if(count[p]==7)sfd_start[p]=$time;
                    // The next byte boundary is the END of the SFD byte.
                    if(count[p]==8)sfd_end[p]=$time;
                    count[p]++;
                end else if(count[p]!=0)begin
                    if(count[p]<72 || count[p]>1526 || packet[p][7]!==8'hd5)
                        $fatal(1,"GMII FAIL invalid frame or SFD");
                    for(integer j=0;j<7;j++)
                        if(packet[p][j]!==8'h55)$fatal(1,"GMII FAIL invalid preamble");
                    if(sfd_end[p]-sfd_start[p]!=BYTE_NS)
                        fail("SFD byte duration differs from byte clock");
                    vl={packet[p][12],packet[p][13]};sn=packet[p][count[p]-5];
                    if(vl>=VL_COUNT || sn==0)$fatal(1,"GMII FAIL invalid VL/SN");
                    if(p==0)begin
                        slot=-1;
                        for(integer q=0;q<MAX_PENDING;q++)if(!occupied[q] && slot<0)slot=q;
                        if(slot<0)$fatal(1,"GMII FAIL monitor pending capacity exceeded");
                        occupied[slot]=1;stored_length[slot]=count[p];
                        stored_vl[slot]=vl;stored_sn[slot]=sn;stored_start[slot]=sfd_start[p];
                        for(integer j=0;j<count[p];j++)stored[slot][j]=packet[p][j];
                        pending_frames++;
                    end else begin
                        matched=-1;match_count=0;
                        for(integer q=0;q<MAX_PENDING;q++)begin
                            if(occupied[q] && stored_length[q]==count[p] && stored_vl[q]==vl && stored_sn[q]==sn)begin
                                equal_bytes=1;
                                for(integer j=0;j<count[p];j++)
                                    if(stored[q][j]!==packet[p][j])equal_bytes=0;
                                if(equal_bytes)begin matched=q;match_count++;end
                            end
                        end
                        if(match_count!=1)fail("unmatched, altered, duplicate or ambiguous destination frame");
                        else begin
                            if(sfd_end[p]<stored_start[matched])fail("negative SFD latency");
                            delay_ns=(SFD_START_TO_START?sfd_start[p]:sfd_end[p])-stored_start[matched];
                            if(delay_ns>LATENCY_LIMIT_NS)
                                fail($sformatf("SFD latency >2ms: %0d ns",delay_ns));
                            if(delay_ns>worst_latency_ns)worst_latency_ns=delay_ns;
                            if(delay_ns<minimum_by_vl[vl])minimum_by_vl[vl]=delay_ns;
                            if(delay_ns>maximum_by_vl[vl])maximum_by_vl[vl]=delay_ns;
                            spread_ns=maximum_by_vl[vl]-minimum_by_vl[vl];
                            if(spread_ns>worst_jitter_ns)worst_jitter_ns=spread_ns;
                            if(spread_ns>JITTER_LIMIT_NS)
                                fail($sformatf("same-VL SFD delay variation >50us: VL %0d %0d ns",vl,spread_ns));
                            frames_by_vl[vl]++;checked_frames++;
                            last_destination_end_by_vl[vl]=sfd_end[p];
                            occupied[matched]=0;pending_frames--;
                        end
                    end
                    count[p]=0;
                end
            end
        end
    end
endmodule
