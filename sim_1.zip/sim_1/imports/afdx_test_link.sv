`timescale 1ns/1ps
// Testbench-only transport of the complete wire byte stream. No routing,
// switching fabric, address lookup, or deployed PHY implementation.
// Alternate delay by cohort so every VL experiences both window extremes.
// Preserve stream order/IFG if a shorter requested delay would cause overlap.
module afdx_test_link #(
    parameter BASE_NS=10000, SPREAD_NS=20000, COHORT=128,
    parameter BYTE_NS=8, DROP_FRAME=-1
) (
    input wire reset,
    input wire [7:0] source_data,
    input wire source_valid,
    output reg [7:0] destination_data=0,
    output reg destination_valid=0,
    output integer queue_adjustments=0
);
    bit in_frame=0,drop=0;
    integer frame_index=0;
    time offset_ns=0,desired_start,last_end=0;
    initial begin
        if(BASE_NS<0 || SPREAD_NS<0 || COHORT<1 || BASE_NS%BYTE_NS || SPREAD_NS%BYTE_NS)
            $fatal(1,"test link delays must be nonnegative whole byte clocks");
    end
    always @(source_data or source_valid or reset)begin
        if(reset)begin
            // The integration TB resets once before traffic. Reject a later
            // reset rather than allowing already scheduled events to leak.
            if(frame_index!=0 || in_frame)$fatal(1,"test link does not support reset with pending traffic");
            destination_valid<=0;destination_data<=0;
            in_frame=0;last_end=0;queue_adjustments=0;
        end else if(source_valid)begin
            if(!in_frame)begin
                desired_start=$time+BASE_NS+((frame_index/COHORT)%2)*SPREAD_NS;
                if(last_end!=0 && desired_start<last_end+12*BYTE_NS)begin
                    desired_start=last_end+12*BYTE_NS;queue_adjustments++;
                end
                offset_ns=desired_start-$time;
                drop=frame_index==DROP_FRAME;in_frame=1;
            end
            if(!drop)begin
                destination_data<=#(offset_ns) source_data;
                destination_valid<=#(offset_ns) 1'b1;
            end
        end else if(in_frame)begin
            if(!drop)begin
                destination_valid<=#(offset_ns) 1'b0;
                last_end=$time+offset_ns;
            end
            in_frame=0;frame_index++;
        end
    end
endmodule
