`timescale 1ns/1ps
module tb_fragmentation;
    reg clk=0;always #4 clk=~clk;
    reg reset=1,lv=0,ls=0,le=0,ready=1;
    reg [7:0] ld=0;reg [15:0] vl=0,len=0;
    wire [7:0] a,b,ud;wire av,bv,lr,uv,us,ue;
    reg lane_a=1,lane_b=1;
    AFDX_competition_top dut(
        .clk(clk),.reset(reset),.host_load_data(ld),.host_load_valid(lv),.host_load_ready(lr),
        .host_load_sop(ls),.host_load_eop(le),.host_load_vlid(vl),.host_load_length(len),
        .host_unload_data(ud),.host_unload_valid(uv),.host_unload_ready(ready),
        .host_unload_sop(us),.host_unload_eop(ue),
        .tx_a_data(a),.tx_a_valid(av),.tx_a_ready(),.rx_a_data(a),.rx_a_valid(av&&lane_a),.rx_a_ready(1'b1),
        .tx_b_data(b),.tx_b_valid(bv),.tx_b_ready(),.rx_b_data(b),.rx_b_valid(bv&&lane_b),.rx_b_ready(1'b1),
        .mib_addr(8'd0),.mib_wr_en(1'b0),.mib_wr_data(32'd0),.mib_rd_data(),.mib_busy(),
        .rtc_timestamp(),.rtc_pps_in(1'b0),.rtc_sync_locked());
    integer expected_length[0:15],expected_vl[0:15];
    integer queued=0,delivered=0,out_pos=0,wire_msg=0,wire_offset=0,frames=0;
    reg [7:0] packet[0:1599];integer n=0;reg prev=0;
    integer cycle=0;reg [7:0] held;reg held_sop,held_eop,was_stalled=0;
    time last_frame[0:127],frame_start;integer seq[0:127];integer wire_ident=-1;
    function [7:0] value(input integer message,input integer index);
        return (message*37+index*13+(index>>8))&255;
    endfunction
    function [31:0] crc_byte(input [31:0] old_crc,input [7:0] d);
        reg [31:0] c;c=old_crc^d;
        for(integer k=0;k<8;k++)c=c[0]?(c>>1)^32'hedb88320:c>>1;
        return c;
    endfunction
    task check_packet;
        integer ipn,flags,off,piece,id,v,sn,sum,absolute,expected,total;
        reg fragmented,more;reg [31:0] crc;
        if(wire_msg>=queued)$fatal(1,"unexpected wire message");
        if(n<72 || n>1526)$fatal(1,"wire length %0d",n);
        for(integer j=0;j<7;j++)if(packet[j]!=8'h55)$fatal(1,"preamble");
        if(packet[7]!=8'hd5)$fatal(1,"SFD");
        crc=32'hffffffff;for(integer j=8;j<n;j++)crc=crc_byte(crc,packet[j]);
        if(crc!=32'hdebb20e3)$fatal(1,"FCS");
        sum=0;for(integer j=22;j<42;j+=2)sum+=packet[j]*256+packet[j+1];
        sum=(sum&65535)+(sum>>16);sum=(sum&65535)+(sum>>16);
        if(sum!=65535)$fatal(1,"IP checksum");
        ipn=packet[24]*256+packet[25];id=packet[26]*256+packet[27];
        flags=packet[28]*256+packet[29];off=(flags&8191)*8;more=(flags&8192)!=0;
        fragmented=expected_length[wire_msg]>1471;
        v=packet[12]*256+packet[13];sn=packet[n-5];
        if(v!=expected_vl[wire_msg])$fatal(1,"wire VL");
        if(sn!=(seq[v]==255?1:seq[v]+1))$fatal(1,"per-fragment SN");seq[v]=sn;
        if(last_frame[v]!=0 && frame_start-last_frame[v]<1000000)$fatal(1,"fragment BAG");
        last_frame[v]=frame_start;
        if(fragmented)begin
            total=expected_length[wire_msg]+8;piece=total-wire_offset>1464?1464:total-wire_offset;
            if(off!=wire_offset || more!=(wire_offset+piece<total) || flags[15:14]!=0 || ipn!=piece+20)
                $fatal(1,"fragment fields off=%0d expected=%0d ipn=%0d piece=%0d",off,wire_offset,ipn,piece);
            if(wire_offset==0)wire_ident=id;else if(id!=wire_ident)$fatal(1,"Identification changed");
            for(integer j=0;j<piece;j++)begin
                absolute=wire_offset+j;
                if(absolute<8)case(absolute)
                    0:expected=11;1:expected=184;2:expected=11;3:expected=186;
                    4:expected=total>>8;5:expected=total&255;default:expected=0;
                endcase
                else expected=value(wire_msg,absolute-8);
                if(packet[42+j]!==8'(expected))$fatal(1,"wire fragment data msg=%0d absolute=%0d got=%h expected=%h",wire_msg,absolute,packet[42+j],8'(expected));
            end
            wire_offset+=piece;if(wire_offset==total)begin wire_offset=0;wire_msg++;end
        end else begin
            if(flags!=16'h4000 || ipn!=expected_length[wire_msg]+28)$fatal(1,"short-message wire regression");
            for(integer j=0;j<expected_length[wire_msg];j++)
                if(packet[50+j]!==value(wire_msg,j))$fatal(1,"short-message wire data");
            wire_msg++;
        end
        frames++;
    endtask
    always @(posedge clk)if(!reset)begin
        cycle++;
        if(was_stalled && (!uv || ud!==held || us!==held_sop || ue!==held_eop))$fatal(1,"unstable output under backpressure");
        was_stalled=uv&&!ready;held=ud;held_sop=us;held_eop=ue;
        if(uv && ready)begin
            if(delivered>=queued || ud!==value(delivered,out_pos))$fatal(1,"reassembly byte msg=%0d pos=%0d got=%h expected=%h",delivered,out_pos,ud,value(delivered,out_pos));
            if(us!==(out_pos==0) || ue!==(out_pos+1==expected_length[delivered]))$fatal(1,"message boundaries");
            if(dut.core.host_unload_length!==16'(expected_length[delivered]) || dut.core.host_unload_vlid!==16'(expected_vl[delivered]))$fatal(1,"reassembled application descriptor");
            if(ue)begin delivered++;out_pos=0;end else out_pos++;
        end
        if(av)begin if(!prev)frame_start=$time;packet[n]=a;n++;end
        if(!av&&prev)begin check_packet();n=0;end
        prev=av;
    end
    always @(negedge clk)if(!reset)ready=(cycle%11<7);
    task send(input integer length,input integer id);
        integer message;message=queued;
        expected_length[queued]=length;expected_vl[queued]=id;queued++;
        for(integer j=0;j<length;j++)begin
            @(negedge clk);lv=1;ls=j==0;le=j==length-1;ld=value(message,j);vl=id;len=length;
            @(posedge clk);while(lr!==1)@(posedge clk);
        end
        @(negedge clk);lv=0;ls=0;le=0;
        wait(delivered==queued);repeat(50)@(negedge clk);
        $display("FRAGMENTATION message=%0d length=%0d vl=%0d PASS",message,length,id);
    endtask
    task send_bad(input integer declared,input integer actual,input bit has_sop);
        for(integer j=0;j<actual;j++)begin
            @(negedge clk);lv=1;ls=has_sop&&j==0;le=j==actual-1;ld=j;vl=0;len=declared;
            @(posedge clk);while(lr!==1)@(posedge clk);
        end
        @(negedge clk);lv=0;ls=0;le=0;repeat(200)@(negedge clk);
    endtask
    initial begin
        for(integer i=0;i<128;i++)begin last_frame[i]=0;seq[i]=0;end
        repeat(8)@(negedge clk);reset=0;repeat(4300)@(negedge clk);
        send(81,0);send(1471,0);send(1472,0);send(2920,1);send(2921,1);
        lane_b=0;send(8192,2);lane_b=1;lane_a=0;send(8192,3);lane_a=1;
        send_bad(8193,8193,1);send_bad(1600,1599,1);send_bad(1600,1601,1);send_bad(1600,1600,0);
        send(97,4);
        if(dut.core.reassembly_completed!=5 || dut.core.reassembly_rejected!=0 || dut.core.fragment_bad!=4)
            $fatal(1,"reassembly counters completed=%0d rejected=%0d txbad=%0d",dut.core.reassembly_completed,dut.core.reassembly_rejected,dut.core.fragment_bad);
        if(wire_msg!=queued)$fatal(1,"wire completion");
        $display("FRAGMENTATION PASS messages=%0d wire_frames=%0d max_message=8192 full_top=128TX_4096RX",delivered,frames);$finish;
    end
    initial begin #50000000;$fatal(1,"fragmentation watchdog delivered=%0d queued=%0d",delivered,queued);end
endmodule
