`timescale 1ns/1ps
// External ports only: the DUT is the unmodified, full-size synthesis top.
// CASE_ID: 0 smoke, 1 100Mbps, 2 mixed lengths, 3 A/B faults, 4 SN wrap,
//          5 SNMP/RTC, 7 81B overload, 8 8VL/73.7Mbps. No DUT parameter overrides.
module tb_netlist_acceptance #(
    parameter CASE_ID=0, ROUNDS=4,
    parameter LATENCY_LIMIT_NS=2000000, JITTER_LIMIT_NS=50000
);
    localparam VLS=CASE_ID==8?8:(CASE_ID==0 || CASE_ID==4)?1:128;
    localparam NR=CASE_ID==0?1:CASE_ID==3?4:CASE_ID==4?260:CASE_ID==7?12:ROUNDS;
    localparam RATE=CASE_ID==8?737:CASE_ID==2?252:1000; // tenths of Mbps
    reg clk=0; always #4 clk=~clk;
    reg reset=1,lv=0,ls=0,le=0,wr=0,pps=0;
    reg [7:0] ld=0,addr=0; reg [31:0] wd=0;
    reg [15:0] vl=0,length=0;
    wire [7:0] a,b,ud; wire av,bv,ar,br,lr,uv,us,ue,busy,locked;
    wire [31:0] rd,rtc;
    reg lane_a=1,lane_b=1,inject=0,iv=0; reg [7:0] idata=0;
    // A/B simultaneous loopback is used normally. Fault case tests A-only,
    // B-only, simultaneous copies, and a delayed B copy separately.
    wire [7:0] ra=inject?idata:a;
    wire rav=inject?iv:(av && lane_a);
    reg [7:0] delay_data[0:2499]; reg delay_valid[0:2499];
    integer delay_ptr=0,phase=0;
    wire [7:0] delayed_data=delay_data[delay_ptr];
    wire delayed_valid=delay_valid[delay_ptr];
    wire [7:0] rb=(CASE_ID==3 && phase==3)?delayed_data:b;
    wire rbv=!inject && lane_b && ((CASE_ID==3 && phase==3)?delayed_valid:bv);
    AFDX_competition_top dut(
        .clk(clk),.reset(reset),.tx_a_data(a),.tx_a_valid(av),.tx_a_ready(ar),
        .rx_a_data(ra),.rx_a_valid(rav),.rx_a_ready(1'b1),
        .tx_b_data(b),.tx_b_valid(bv),.tx_b_ready(br),
        .rx_b_data(rb),.rx_b_valid(rbv),.rx_b_ready(1'b1),
        .host_load_data(ld),.host_load_valid(lv),.host_load_ready(lr),
        .host_load_sop(ls),.host_load_eop(le),.host_load_vlid(vl),.host_load_length(length),
        .host_unload_data(ud),.host_unload_valid(uv),.host_unload_ready(1'b1),
        .host_unload_sop(us),.host_unload_eop(ue),
        .mib_addr(addr),.mib_wr_en(wr),.mib_wr_data(wd),.mib_rd_data(rd),.mib_busy(busy),
        .rtc_timestamp(rtc),.rtc_pps_in(pps),.rtc_sync_locked(locked));
    integer accepted=0,delivered=0,received=0,stalls=0,af=0,bf=0;
    integer sent[0:127],got[0:127],wire_count[0:127];
    integer samples[0:127][0:3];
    time first_in[0:127][0:259],min_latency[0:127][0:3],max_latency[0:127][0:3];
    time last_wire[0:127],worst_latency=0,worst_jitter=0,start_time,end_time;
    integer out_vl=0,out_round=0,out_pos=0,out_n=0;
    time latency; integer cls;
    reg prev_a=0,prev_b=0;
    reg [7:0] wire_a[0:1599],wire_b[0:1599];
    integer na=0,nb=0,management_replies=0;
    reg [7:0] request[0:255],packet[0:1599];
    integer packet_n=0;
    function integer payload_n(input integer v,input integer r);
        if(CASE_ID==0 || CASE_ID==7) return 81;
        else if(CASE_ID==2)case((v+r/2)%4)0:return 1;1:return 81;2:return 465;default:return 1471;endcase
        else if(CASE_ID==3 || CASE_ID==4)return 97;
        else return 1471;
    endfunction
    function [7:0] value(input integer v,input integer r,input integer p);
        return (v*17+r*29+p)&255;
    endfunction
    function integer size_class(input integer n);
        case(n)1:return 0;81:return 1;465:return 2;default:return 3;endcase
    endfunction
    function [31:0] crc_byte(input [31:0] old_crc,input [7:0] d);
        reg [31:0] c; c=old_crc;
        for(integer k=0;k<8;k++)begin
            if(c[0]^d[k])c=(c>>1)^32'hedb88320;else c=c>>1;
        end
        return c;
    endfunction
    task write_reg(input [7:0] address,input [31:0] data);
        @(negedge clk);while(busy!==0)@(negedge clk);
        addr=address;wd=data;wr=1;@(negedge clk);wr=0;
    endtask
    task read_check(input [7:0] address,input [31:0] expected);
        @(negedge clk);while(busy!==0)@(negedge clk);
        addr=address;repeat(2)@(negedge clk);
        if(rd!==expected)$fatal(1,"MIB address=%h got=%h expected=%h",address,rd,expected);
    endtask
    task automatic wait_frames(input integer expected);
        fork: delivery_wait
            begin wait(delivered==expected);end
            begin
                #(LATENCY_LIMIT_NS+50000);
                $fatal(1,"missing application delivery expected=%0d got=%0d",expected,delivered);
            end
        join_any
        disable delivery_wait;
    endtask
    // Independent wire-format checker: preamble/SFD, length, IPv4 checksum,
    // UDP length, FCS, VLID, SN 1..255, and per-VL BAG at actual wire start.
    task check_wire(input bit lane,input integer n);
        reg [31:0] c; integer v,sn,ipn,udpn,sum; time t;
        c=32'hffffffff;
        if(n<72 || n>1526)$fatal(1,"wire frame length %0d",n);
        for(integer j=0;j<7;j++)if((lane?wire_b[j]:wire_a[j])!==8'h55)$fatal(1,"preamble");
        if((lane?wire_b[7]:wire_a[7])!==8'hd5)$fatal(1,"SFD");
        for(integer j=8;j<n-4;j++)c=crc_byte(c,lane?wire_b[j]:wire_a[j]);
        c=~c;
        for(integer j=0;j<4;j++)if((lane?wire_b[n-4+j]:wire_a[n-4+j])!==((c>>(8*j))&255))$fatal(1,"wire FCS");
        if(!lane)begin
            if(wire_a[20]!==8'h08 || wire_a[21]!==0 || wire_a[22]!==8'h45 || wire_a[31]!==17)$fatal(1,"IPv4/UDP header");
            sum=0;for(integer j=22;j<42;j+=2)sum+=({wire_a[j],wire_a[j+1]});
            sum=(sum&65535)+(sum>>16);sum=(sum&65535)+(sum>>16);
            if(sum!=65535)$fatal(1,"IPv4 header checksum");
            v={wire_a[12],wire_a[13]}; sn=wire_a[n-5];
            ipn={wire_a[24],wire_a[25]};udpn={wire_a[46],wire_a[47]};
            if(v>=128 || sn==0 || ipn!=udpn+20)$fatal(1,"wire VL/SN/length");
            if(CASE_ID!=5)begin
                if(sn!=(wire_count[v]%255)+1)$fatal(1,"SN sequence VL=%0d got=%0d",v,sn);
                t=$time-(n-1)*8;
                if(wire_count[v] && t-last_wire[v]<1000000)$fatal(1,"BAG violation VL=%0d interval_ns=%0d",v,t-last_wire[v]);
                last_wire[v]=t;wire_count[v]++;
            end else begin
                if({wire_a[42],wire_a[43]}!=161 || {wire_a[44],wire_a[45]}!=50010 || v!=127)$fatal(1,"SNMP response routing");
                check_snmp(udpn-8);
                management_replies++;
            end
        end
    endtask
    function integer ber_start(input integer p);
        return p+2+(wire_a[p+1][7]?(wire_a[p+1]&127):0);
    endfunction
    function integer ber_size(input integer p);
        if(wire_a[p+1]<128)return wire_a[p+1];
        if(wire_a[p+1]==8'h81)return wire_a[p+2];
        if(wire_a[p+1]==8'h82)return {wire_a[p+2],wire_a[p+3]};
        $fatal(1,"BER length");return 0;
    endfunction
    function integer ber_next(input integer p);return ber_start(p)+ber_size(p);endfunction
    task check_snmp(input integer n);
        integer p,q; reg [63:0] oid; reg [119:0] name_text;
        if(wire_a[50]!==8'h30 || ber_next(50)!=50+n)$fatal(1,"SNMP outer BER");
        p=ber_start(50);p=ber_next(p);p=ber_next(p);
        if(wire_a[p]!==8'ha2)$fatal(1,"SNMP response PDU");
        p=ber_start(p);
        if(ber_size(p)!=1 || wire_a[ber_start(p)]!=55)$fatal(1,"SNMP request ID");
        p=ber_next(p);if(wire_a[ber_start(p)]!=0)$fatal(1,"SNMP error status");
        p=ber_next(p);if(wire_a[ber_start(p)]!=0)$fatal(1,"SNMP error index");
        p=ber_next(p);p=ber_start(p);p=ber_start(p);
        if(wire_a[p]!=6 || ber_size(p)!=8)$fatal(1,"SNMP OID encoding");
        oid=0;q=ber_start(p);for(integer j=0;j<8;j++)oid=(oid<<8)|wire_a[q+j];
        if(oid!==64'h2b06010201010500)$fatal(1,"SNMP OID");
        p=ber_next(p);if(wire_a[p]!=4 || ber_size(p)!=15)$fatal(1,"SNMP sysName type/length");
        name_text=0;q=ber_start(p);for(integer j=0;j<15;j++)name_text=(name_text<<8)|wire_a[q+j];
        if(name_text!==120'h414644585f656e645f73797374656d)$fatal(1,"SNMP sysName value");
    endtask
    always @(posedge clk)begin
        if(reset)begin delay_ptr=0;for(integer j=0;j<2500;j++)begin delay_valid[j]=0;delay_data[j]=0;end end
        else begin
            delay_data[delay_ptr]<=b;delay_valid[delay_ptr]<=bv;
            delay_ptr<=delay_ptr==2499?0:delay_ptr+1;
            if(lv && lr)begin
                if(ls)begin first_in[vl][sent[vl]]=$time;accepted++;end
                if(le)sent[vl]++;
            end
            if(lv && lr!==1'b1)stalls++;
            if(av)begin if(na>=1600)$fatal(1,"oversize A");wire_a[na]=a;na++;end
            if(bv)begin if(nb>=1600)$fatal(1,"oversize B");wire_b[nb]=b;nb++;end
            if(prev_a && !av)begin check_wire(0,na);af++;na=0;end
            if(prev_b && !bv)begin check_wire(1,nb);bf++;nb=0;end
            prev_a=av;prev_b=bv;
            if(uv===1'b1)begin
                if(CASE_ID==5)$fatal(1,"management request leaked to application");
                if(us)begin
                    if(out_pos!=0)$fatal(1,"nested SOP");
                    if(addr!==8'h68 || $isunknown(rd))$fatal(1,"RX descriptor MIB unavailable");
                    out_vl=rd[31:16];out_n=rd[15:0];
                    if(out_vl>=VLS)$fatal(1,"unexpected RX VL %0d",out_vl);
                    out_round=got[out_vl];
                    if(out_round>=NR || out_n!=payload_n(out_vl,out_round))$fatal(1,"duplicate or wrong RX length");
                    latency=$time-first_in[out_vl][out_round];
                    if(CASE_ID!=7 && latency>=LATENCY_LIMIT_NS)$fatal(1,"application latency ns=%0d VL=%0d",latency,out_vl);
                    if(latency>worst_latency)worst_latency=latency;
                    cls=size_class(out_n);samples[out_vl][cls]++;
                    if(latency<min_latency[out_vl][cls])min_latency[out_vl][cls]=latency;
                    if(latency>max_latency[out_vl][cls])max_latency[out_vl][cls]=latency;
                end else if(out_pos==0)$fatal(1,"missing SOP");
                if(ud!==value(out_vl,out_round,out_pos))$fatal(1,"payload mismatch VL=%0d frame=%0d byte=%0d",out_vl,out_round,out_pos);
                if(ue!==(out_pos==out_n-1))$fatal(1,"EOP boundary");
                out_pos++;received++;
                if(ue)begin got[out_vl]++;delivered++;out_pos=0;end
            end
        end
    end
    task send_frame(input integer v,input integer r,input time base,input integer offered);
        integer n;time target;
        n=payload_n(v,r);
        for(integer j=0;j<n;j++)begin
            target=base+((64'(offered+j)*10000+RATE-1)/RATE)*8;
            @(negedge clk);while($time<target)@(negedge clk);
            vl=v;length=n;ld=value(v,r,j);lv=1;ls=j==0;le=j==n-1;
            @(posedge clk);while(lr!==1'b1)@(posedge clk);
            @(negedge clk);lv=0;ls=0;le=0;
        end
    endtask
    // Independent physical frame builder for management requests.
    task inject_request(input integer n,input integer seq);
        integer total,sum;reg [31:0] c;reg [15:0] check;
        total=(n<17?64:n+47)+8;
        for(integer j=0;j<total;j++)packet[j]=0;
        for(integer j=0;j<7;j++)packet[j]=8'h55;
        packet[7]=8'hd5;packet[8]=3;packet[13]=127;packet[14]=2;packet[19]=8'h20;
        packet[20]=8'h08;packet[22]=8'h45;packet[24]=(n+28)>>8;packet[25]=n+28;
        packet[28]=8'h40;packet[30]=8'h40;packet[31]=17;
        packet[34]=10;packet[37]=2;packet[38]=10;packet[41]=1;
        packet[42]=50010>>8;packet[43]=50010&255;packet[45]=161;
        packet[46]=(n+8)>>8;packet[47]=n+8;
        sum=0;for(integer j=22;j<42;j+=2)sum+={packet[j],packet[j+1]};
        sum=(sum&65535)+(sum>>16);sum=(sum&65535)+(sum>>16);check=~sum[15:0];
        packet[32]=check>>8;packet[33]=check;
        for(integer j=0;j<n;j++)packet[50+j]=request[j];
        packet[total-5]=seq;c=32'hffffffff;
        for(integer j=8;j<total-4;j++)c=crc_byte(c,packet[j]);c=~c;
        for(integer j=0;j<4;j++)packet[total-4+j]=c>>(8*j);
        @(negedge clk);inject=1;
        for(integer j=0;j<total;j++)begin idata=packet[j];iv=1;@(negedge clk);end
        iv=0;repeat(12)@(negedge clk);
    endtask
    integer offered=0;time next_round;real mbps;reg [319:0] message;
    reg [31:0] before_rtc;
    initial begin
        if(CASE_ID<0 || CASE_ID>8 || CASE_ID==6 || ROUNDS<1 || ROUNDS>260)$fatal(1,"invalid case/round count");
        for(integer v=0;v<128;v++)begin
            sent[v]=0;got[v]=0;wire_count[v]=0;last_wire[v]=0;
            for(integer c=0;c<4;c++)begin samples[v][c]=0;min_latency[v][c]='1;max_latency[v][c]=0;end
        end
        repeat(8)@(negedge clk);reset=0;repeat(4200)@(negedge clk);
        if($isunknown({lr,uv,av,bv,ar,br,busy,rtc,locked}))$fatal(1,"unknown controls after initialization");
        if(CASE_ID==7)$display("LOAD_APPLICABILITY offered_same_VL_interval_ns=829440 BAG_ns=1000000 overload=1 timing_limits_diagnostic_only=1");
        $display("ACCEPTANCE CONFIG case=%0d clk_ns=8 tx_vls=128 rx_vls=4096 app_latency_limit_ns=%0d same_vl_same_length_jitter_limit_ns=%0d",CASE_ID,LATENCY_LIMIT_NS,JITTER_LIMIT_NS);
        if(CASE_ID==5)begin
            write_reg(8'h60,32'h12345678);repeat(4)@(negedge clk);
            if(rtc!==32'h12345678 || locked!==1)$fatal(1,"RTC absolute sync");
            read_check(8'h62,1);
            before_rtc=rtc;repeat(125000)@(negedge clk);
            if(rtc!==before_rtc+1)$fatal(1,"RTC millisecond tick");
            @(negedge clk);pps=1;repeat(8)@(negedge clk);pps=0;
            if(locked!==1)$fatal(1,"RTC PPS lock");
            message=320'h302602010104067075626c6963a019020137020100020100300e300c06082b060102010105000500;
            for(integer j=0;j<40;j++)request[j]=message>>((39-j)*8);
            inject_request(40,1);
            fork: snmp_wait
                begin wait(management_replies==1);end
                begin #2000000;$fatal(1,"missing SNMP response");end
            join_any
            disable snmp_wait;
            read_check(8'h90,1);read_check(8'h91,1);read_check(8'h92,0);
            request[0]=8'h31;inject_request(40,2);repeat(20000)@(negedge clk);
            read_check(8'h92,1);
            if(management_replies!=1)$fatal(1,"malformed SNMP produced a response");
            $display("ACCEPTANCE PASS case=5 SNMP_GET_sysName=1 malformed_rejected=1 RTC_absolute_tick_PPS=1");$finish;
        end
        for(integer v=0;v<VLS;v++)begin
            write_reg(8'h40,v);write_reg(8'h41,1);write_reg(8'h42,1518);
            write_reg(8'h47,0);
        end
        @(negedge clk);addr=8'h68;
        start_time=$time;next_round=start_time;
        for(integer r=0;r<NR;r++)begin
            if(CASE_ID==3)begin
                phase=r;lane_a=r!=1;lane_b=r!=0;
            end
            if(CASE_ID==3 || CASE_ID==4)begin
                while($time<next_round)@(negedge clk);
                next_round=$time+1100000;
            end
            for(integer v=0;v<VLS;v++)begin
                send_frame(v,r,start_time,offered);offered+=payload_n(v,r);
            end
            if(CASE_ID==3)begin wait_frames((r+1)*VLS);repeat(5000)@(negedge clk);end
            if(r%16==15 || r==NR-1)$display("ACCEPTANCE PROGRESS case=%0d round=%0d/%0d accepted=%0d delivered=%0d time_ns=%0d",CASE_ID,r+1,NR,accepted,delivered,$time);
        end
        // Include the final offered-byte period; avoid inflating short-run rate.
        end_time=start_time+((64'(offered)*10000+RATE-1)/RATE)*8;
        if($time>end_time)end_time=$time;
        wait_frames(VLS*NR);
        // Fault case must await the delayed lane; direct simultaneous copies
        // have already reached the RX checker by application EOP.
        repeat(CASE_ID==3?5000:256)@(negedge clk);
        for(integer v=0;v<VLS;v++)begin
            if(sent[v]!=NR || got[v]!=NR || wire_count[v]!=NR)$fatal(1,"per-VL count VL=%0d",v);
            for(integer c=0;c<4;c++)if(samples[v][c]>1)begin
                if(max_latency[v][c]-min_latency[v][c]>worst_jitter)worst_jitter=max_latency[v][c]-min_latency[v][c];
            end
        end
        if(af!=VLS*NR || bf!=VLS*NR)$fatal(1,"A/B transmit count");
        if(worst_jitter>JITTER_LIMIT_NS && CASE_ID!=3 && CASE_ID!=7)$fatal(1,"same VL/length jitter ns=%0d",worst_jitter);
        mbps=offered*8000.0/(end_time-start_time);
        if(CASE_ID==7 && stalls==0)$fatal(1,"over-BAG stress expected input backpressure");
        if((CASE_ID==1 || CASE_ID==2 || CASE_ID==8) && stalls!=0)$fatal(1,"compliant load input blocked cycles=%0d",stalls);
        if(CASE_ID==1 && mbps<99.99)$fatal(1,"accepted throughput %.6f Mbps",mbps);
        read_check(8'h20,VLS*NR);read_check(8'h21,VLS*NR);
        if(CASE_ID!=3)read_check(8'h24,VLS*NR);else read_check(8'h24,2*VLS);
        read_check(8'h22,0);read_check(8'h23,0);read_check(8'h25,0);read_check(8'h26,0);
        read_check(8'h27,0);read_check(8'h28,0);read_check(8'h29,0);read_check(8'h2a,0);read_check(8'h2b,0);
        $display("ACCEPTANCE SUMMARY case=%0d accepted_frames=%0d delivered_frames=%0d payload_bytes=%0d input_Mbps=%.6f stalls=%0d app_max_latency_ns=%0d same_vl_same_length_jitter_ns=%0d A=%0d B=%0d",CASE_ID,accepted,delivered,offered,mbps,stalls,worst_latency,worst_jitter,af,bf);
        $display("ACCEPTANCE PASS case=%0d",CASE_ID);$finish;
    end
    initial begin #600000000;$fatal(1,"ACCEPTANCE watchdog case=%0d accepted=%0d delivered=%0d",CASE_ID,accepted,delivered);end
    initial forever begin #(CASE_ID==0?10000:1000000);$display("ACCEPTANCE HEARTBEAT case=%0d time_ns=%0d delivered=%0d",CASE_ID,$time,delivered);end
endmodule
