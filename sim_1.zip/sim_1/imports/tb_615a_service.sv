`timescale 1ns/1ps
// External loader BFM only. The DUT contains all protocol state and file RAM.
module tb_615a_service #(parameter INTEGRATED=0,LIMITS=0,TIMEOUTS=0,DALLY_TEST=0,
    NETWORK=0,JOINT=0,FAULT_MODE=0,
    A_BASE_NS=10000,A_SPREAD_NS=20000,B_BASE_NS=20000,B_SPREAD_NS=10000);
    localparam MANAGEMENT_VL=JOINT?127:1;
    reg clk=0;always #4 clk=~clk;
    reg reset=1,sv=0,ss=0,se=0,cw=0;
    reg [7:0] sd=0,ca=0;reg [31:0] cd=0;
    reg [15:0] sl=0,sp=50000,dp=69,vl=0;
    reg [31:0] sip=32'h0a000002,dip=32'h0a000001;
    wire sr,mv,ms,me,busy,owns;wire [7:0] md;
    wire [15:0] ml,mvl,msp,mdp,status;wire [31:0] msi,mdi,cr,completed,failed,retries,ce;
    integer cycle=0,fail=0,packets=0,consumed=0,output_length=0;
    wire mr=cycle%13>=4;
    reg [7:0] request[0:1023],output_packet[0:515],assembled[0:4095];
    reg [15:0] output_source,output_destination;
    reg held=0;reg [121:0] held_bus;
    integer sizes[0:7];integer delivered_files=0,delivered_bytes=0,status_files=0,list_files=0;
    integer final_status=0,init_tid=0,control_tid=0,source_counter=51000;
    integer drop_block=0,dropped=0;
    bit abort_next_file=0;
    bit exhaust_next_file=0;
    bit init_ack_loss_tested=0,status_query_tested=0,parallel_query_tested=0;
    reg [7:0] saved_final[0:515];
    reg [7:0] saved_snapshot[0:515];
    integer saved_snapshot_length;
    integer saved_length,saved_tid,saved_block,dally_checks=0;
    bit joint_controls_tested=0;
    wire [4:0] debug_state;
    wire debug_master,debug_dirty,debug_list,debug_committed,debug_initialized;
    generate if(!INTEGRATED)begin:g_direct
    afdx_615a_service #(.MAX_FILES(LIMITS?8:4),.CYCLES_PER_MS(10),.TIMEOUT_MS(100),.MAX_RETRIES(2),
        .DALLY_SLOTS(DALLY_TEST?1:4),.DALLY_MS(DALLY_TEST?10000:300),
        .SELECTION_TIMEOUT_MS(DALLY_TEST?30000:(TIMEOUTS?500:3000)),.OPERATION_TIMEOUT_MS(30000)) dut(
        .clk(clk),.reset(reset),.s_data(sd),.s_valid(sv),.s_ready(sr),.s_sop(ss),.s_eop(se),
        .s_length(sl),.s_vlid(vl),.s_src_port(sp),.s_dst_port(dp),.s_src_ip(sip),.s_dst_ip(dip),.owns_udp_port(owns),
        .m_data(md),.m_valid(mv),.m_ready(mr),.m_sop(ms),.m_eop(me),.m_length(ml),.m_vlid(mvl),
        .m_src_port(msp),.m_dst_port(mdp),.m_src_ip(msi),.m_dst_ip(mdi),
        .cfg_write(cw),.cfg_addr(ca),.cfg_data(cd),.cfg_read(cr),.busy(busy),.operation_status(status),
        .completed_operations(completed),.failed_operations(failed),.retransmissions(retries),.config_errors(ce));
        assign debug_state=dut.state;assign debug_master=dut.master_outstanding;
        assign debug_dirty=dut.status_dirty;assign debug_list=dut.list_pending;
        assign debug_committed=dut.selection_committed;assign debug_initialized=dut.initialized;
    end else begin:g_system
        wire [7:0] ta,tb,pa,pb;wire tav,tbv,pav,pbv,host_leak;
        wire [7:0] to_la,to_lb,to_ta,to_tb,raw_md,business_data,probe_data;
        wire to_lav,to_lbv,to_tav,to_tbv,raw_mv,business_valid,business_sop,business_eop,business_ready;
        wire [15:0] business_length,business_vlid;
        wire probe_active,probe_valid;
        reg rtc_sync=0;
        wire [31:0] rtc_value;wire rtc_locked;
        wire [31:0] mib_rdata;
        AFDX_top #(.HOST_FRAMED(1),.TX_VL_NUM(JOINT?128:2),.RX_VL_NUM(JOINT?4096:4),.MANAGEMENT_VL(MANAGEMENT_VL),.TIMED_TX(JOINT),.RX_SLOTS(JOINT?32:4),
            .DOWNLOAD_MAX_FILES(LIMITS?8:4),.ENABLE_HW_615A(1),.ENABLE_HW_SNMP(1),.DOWNLOAD_TIMEOUT_MS(5),
            .DOWNLOAD_DALLY_SLOTS(DALLY_TEST?1:4),.DOWNLOAD_DALLY_MS(DALLY_TEST?200:120)) target(
            .clk(clk),.reset(reset),.tx_a_data(ta),.tx_a_valid(tav),.tx_a_ready(),
            .tx_b_data(tb),.tx_b_valid(tbv),.tx_b_ready(),
            .rx_a_data(to_ta),.rx_a_valid(to_tav),.rx_a_ready(1'b1),.rx_b_data(to_tb),.rx_b_valid(to_tbv),.rx_b_ready(1'b1),
            .host_load_valid(business_valid),.host_load_data(business_data),.host_load_ready(business_ready),
            .host_load_sop(business_sop),.host_load_eop(business_eop),.host_load_vlid(business_vlid),.host_load_length(business_length),
            .host_load_header_valid(1'b1),.host_load_src_port(16'd60000),.host_load_dst_port(16'd60001),
            .host_load_src_ip(32'h0a000001),.host_load_dst_ip(32'h0a000002),
            .host_unload_data(),.host_unload_valid(host_leak),.host_unload_ready(1'b1),
            .host_unload_sop(),.host_unload_eop(),.host_unload_vlid(),.host_unload_length(),
            .host_unload_src_port(),.host_unload_dst_port(),.host_unload_src_ip(),.host_unload_dst_ip(),
            .mib_addr(ca),.mib_wr_en(cw),.mib_wr_data(cd),.mib_rd_data(mib_rdata),.mib_busy(),
            .rtc_sync_valid(rtc_sync),.rtc_sync_timestamp(32'h12345678),.rtc_pps_in(1'b0),.rtc_timestamp(rtc_value),.rtc_sync_locked(rtc_locked));
        AFDX_top #(.HOST_FRAMED(1),.TX_VL_NUM(2),.RX_VL_NUM(JOINT?4096:4),.RX_SLOTS(JOINT?32:4),.ENABLE_HW_615A(0),.ENABLE_HW_SNMP(0)) loader_port(
            .clk(clk),.reset(reset),.tx_a_data(pa),.tx_a_valid(pav),.tx_a_ready(),
            .tx_b_data(pb),.tx_b_valid(pbv),.tx_b_ready(),
            .rx_a_data(to_la),.rx_a_valid(to_lav),.rx_a_ready(1'b1),.rx_b_data(to_lb),.rx_b_valid(to_lbv),.rx_b_ready(1'b1),
            .host_load_data(sd),.host_load_valid(sv),.host_load_ready(sr),
            .host_load_sop(ss),.host_load_eop(se),.host_load_vlid(vl),.host_load_length(sl),
            .host_load_header_valid(1'b1),.host_load_src_port(sp),.host_load_dst_port(dp),
            .host_load_src_ip(sip),.host_load_dst_ip(dip),
            .host_unload_data(raw_md),.host_unload_valid(raw_mv),.host_unload_ready(mr),
            .host_unload_sop(ms),.host_unload_eop(me),.host_unload_vlid(mvl),.host_unload_length(ml),
            .host_unload_src_port(msp),.host_unload_dst_port(mdp),.host_unload_src_ip(msi),.host_unload_dst_ip(mdi),
            .mib_addr(8'd0),.mib_wr_en(1'b0),.mib_wr_data(32'd0),.mib_rd_data(),.mib_busy(),
            .rtc_sync_valid(1'b0),.rtc_sync_timestamp(32'd0),.rtc_pps_in(1'b0),.rtc_timestamp(),.rtc_sync_locked());
        assign md=raw_md;
        assign mv=raw_mv && !(JOINT && (msp==60000 || msp==161));
        if(NETWORK)begin:g_network
            afdx_joint_network #(.FAULT_MODE(FAULT_MODE),.A_BASE_NS(A_BASE_NS),.A_SPREAD_NS(A_SPREAD_NS),
                .B_BASE_NS(B_BASE_NS),.B_SPREAD_NS(B_SPREAD_NS)) network(
                .clk(clk),.reset(reset),
                .target_a(probe_active?probe_data:ta),.target_b(probe_active?probe_data:tb),
                .target_av(probe_active?probe_valid:tav),.target_bv(probe_active?probe_valid:tbv),
                .loader_a(pa),.loader_b(pb),.loader_av(pav),.loader_bv(pbv),
                .to_loader_a(to_la),.to_loader_b(to_lb),.to_loader_av(to_lav),.to_loader_bv(to_lbv),
                .to_target_a(to_ta),.to_target_b(to_tb),.to_target_av(to_tav),.to_target_bv(to_tbv));
        end else begin:g_direct_wires
            assign to_la=ta;assign to_lb=tb;assign to_lav=tav;assign to_lbv=tbv;
            assign to_ta=pa;assign to_tb=pb;assign to_tav=pav;assign to_tbv=pbv;
        end
        if(JOINT)begin:g_joint
            wire submitted;wire [31:0] business_frames,capacity_frames,business_bytes,overlap_frames;
            integer queued=0,peak_queued=0;
            reg [127:0] concurrent_seen=0;
            integer snmp_position=0,snmp_replies=0;
            byte unsigned snmp_packet[0:255];
            localparam [63:0] SYSNAME_OID=64'h2b06010201010500;
            localparam [119:0] SYSNAME_TEXT="AFDX_end_system";
            function integer ber_value(input integer p);
                return p+2+(snmp_packet[p+1][7]?(snmp_packet[p+1]&127):0);
            endfunction
            function integer ber_size(input integer p);
                integer n;
                n=snmp_packet[p+1];
                if(n<128)return n;
                if(n==8'h81)return snmp_packet[p+2];
                if(n==8'h82)return {snmp_packet[p+2],snmp_packet[p+3]};
                $fatal(1,"JOINT SNMP invalid BER length");return 0;
            endfunction
            function integer ber_next(input integer p);return ber_value(p)+ber_size(p);endfunction
            afdx_joint_traffic traffic(.clk(clk),.reset(reset),.start(debug_initialized),
                .s_data(business_data),.s_valid(business_valid),.s_sop(business_sop),.s_eop(business_eop),
                .s_length(business_length),.s_vlid(business_vlid),.s_ready(business_ready),
                .m_data(raw_md),.m_valid(raw_mv && msp==60000),.m_ready(mr),.m_sop(ms),.m_eop(me),
                .m_length(ml),.m_vlid(mvl),.submitted(submitted),.business_frames(business_frames),
                .capacity_frames(capacity_frames),.business_bytes(business_bytes),.overlap_frames(overlap_frames),.download_busy(busy));
            afdx_joint_probe probe(.clk(clk),.active(probe_active),.data(probe_data),.valid(probe_valid));
            always @(target.u_afdx_tx_core.queued)if(!reset)begin
                queued=0;for(integer v=0;v<128;v++)if(target.u_afdx_tx_core.queued[v])queued++;
                if(queued>peak_queued)peak_queued=queued;
                if(queued>1)concurrent_seen|=target.u_afdx_tx_core.queued;
            end
            always @(posedge clk)if(!reset && raw_mv && mr && msp==161)begin
                if(ms)begin
                    snmp_position=0;
                    if(mdp!=50010 || mvl!=127 || msi!=32'h0a000001 || mdi!=32'h0a000002)$fatal(1,"JOINT SNMP descriptor");
                end
                snmp_packet[snmp_position]=raw_md;snmp_position++;
                if(me)begin
                    integer p;
                    if(snmp_position!=ml || ber_next(0)!=ml)$fatal(1,"JOINT SNMP response length");
                    p=ber_next(ber_value(0));p=ber_next(p);
                    if(snmp_packet[p]!=8'ha2)$fatal(1,"JOINT SNMP response PDU");p=ber_value(p);
                    if(ber_size(p)!=1 || snmp_packet[ber_value(p)]!=55)$fatal(1,"JOINT SNMP request ID");p=ber_next(p);
                    if(snmp_packet[ber_value(p)]!=0)$fatal(1,"JOINT SNMP error status");p=ber_next(p);
                    if(snmp_packet[ber_value(p)]!=0)$fatal(1,"JOINT SNMP error index");p=ber_next(p);
                    p=ber_value(p);p=ber_value(p);
                    if(snmp_packet[p]!=6 || ber_size(p)!=8)$fatal(1,"JOINT SNMP sysName OID");
                    for(integer b=0;b<8;b++)if(snmp_packet[ber_value(p)+b]!==((SYSNAME_OID>>((7-b)*8))&255))$fatal(1,"JOINT SNMP OID content");
                    p=ber_next(p);
                    if(snmp_packet[p]!=4 || ber_size(p)!=15)$fatal(1,"JOINT SNMP sysName value");
                    for(integer b=0;b<15;b++)if(snmp_packet[ber_value(p)+b]!==((SYSNAME_TEXT>>((14-b)*8))&255))$fatal(1,"JOINT SNMP sysName content");
                    snmp_replies++;
                end
            end
        end else begin:g_no_joint
            assign business_data=0;assign business_valid=0;assign business_sop=0;assign business_eop=0;
            assign business_length=0;assign business_vlid=0;
            assign probe_active=0;assign probe_valid=0;assign probe_data=0;
        end
        assign busy=target.dl_busy;assign status=target.dl_status;assign cr=mib_rdata;
        assign completed=target.dl_complete;assign failed=target.dl_failed;
        assign retries=target.dl_retries;assign ce=target.dl_cfg_errors;assign owns=1'b1;
        assign debug_state=target.g_hw_615a.downloader.state;
        assign debug_master=target.g_hw_615a.downloader.master_outstanding;
        assign debug_dirty=target.g_hw_615a.downloader.status_dirty;
        assign debug_list=target.g_hw_615a.downloader.list_pending;
        assign debug_committed=target.g_hw_615a.downloader.selection_committed;
        assign debug_initialized=target.g_hw_615a.downloader.initialized;
        always @(posedge clk)if(!reset && host_leak)$fatal(1,"615A packet leaked into business host stream");
    end endgenerate
    always @(posedge clk)begin
        cycle++;
        if(!reset)begin
            if(held && (!mv || {md,ms,me,ml,msp,mdp,msi,mdi}!==held_bus))$fatal(1,"615A output changed while stalled");
            held=mv&&!mr;held_bus={md,ms,me,ml,msp,mdp,msi,mdi};
            if(mv&&mr)begin
                if(ms)begin
                    if(packets!=consumed)$fatal(1,"loader did not consume previous packet");
                    output_length=0;output_source=msp;output_destination=mdp;
                    if(INTEGRATED)$display("615A RESPONSE START time_ns=%0t src=%0d dst=%0d vl=%0d", $time,msp,mdp,mvl);
                    if(msi!==32'h0a000001 || mdi!==32'h0a000002 || mvl!==(INTEGRATED?MANAGEMENT_VL:16'd0))$fatal(1,"615A reply descriptor");
                end
                output_packet[output_length]=md;output_length++;
                if(me)begin
                    if(output_length!=ml)$fatal(1,"615A output length mismatch");
                    packets++;
                    if(INTEGRATED)$display("615A RESPONSE END time_ns=%0t packets=%0d consumed=%0d length=%0d",$time,packets,consumed,ml);
                end
            end
        end
    end
    task check(input bit good,input string message);
        if(!good)begin fail++;$display("615A FAIL: %s status=%h state=%0d",message,status,debug_state);end
    endtask
    function string file_name(input integer id);
        string text;
        if(LIMITS)begin text="abcdefghijklmnopqrstuvwxyzABCDE0";text.putc(31,"0"+id);end
        else if(id==0)text="a.bin";else if(id==1)text="b.bin";else text="c.bin";
        return text;
    endfunction
    task write_config(input [7:0] address,input [31:0] value);
        @(negedge clk);ca=address;cd=value;cw=1;
        @(negedge clk);cw=0;
    endtask
    task configure_joint;
        if(JOINT)begin
            // RX RAM initialization completes before the first request.
            repeat(5000)@(negedge clk);
            for(integer v=0;v<127;v++)begin
                write_config(8'h40,v);write_config(8'h45,8000000);
                write_config(8'h46,12500000+v*20000);write_config(8'h47,1);
            end
            write_config(8'h40,MANAGEMENT_VL);write_config(8'h45,125000);
            write_config(8'h46,25000);write_config(8'h47,1);
        end
    endtask
    generate if(JOINT)begin:g_joint_api
    task controls;
        reg [319:0] message;
        reg [31:0] before_tick;
        if(JOINT && !joint_controls_tested)begin
            @(negedge clk);before_tick=g_system.target.tx_scheduler_tick;g_system.rtc_sync=1;
            @(negedge clk);g_system.rtc_sync=0;
            check(g_system.rtc_locked && g_system.rtc_value==32'h12345678,"RTC synchronization during live 615A operation");
            check(g_system.target.tx_scheduler_tick==before_tick+1,"RTC correction does not move scheduler tick");
            message=320'h302602010104067075626c6963a019020137020100020100300e300c06082b060102010105000500;
            for(integer b=0;b<40;b++)request[b]=message>>((39-b)*8);
            send(40,50010,161);
            wait(g_system.g_joint.snmp_replies==1);
            check(busy,"SNMP and RTC tested while 615A operation is active");
            joint_controls_tested=1;
        end
    endtask
    task finish_check;
        if(JOINT)begin
            g_system.g_joint.traffic.wait_business();
            wait(!g_system.tav && !g_system.tbv && !g_system.pav && !g_system.pbv);
            repeat(2000)@(negedge clk);
            g_system.g_joint.probe.run();
            g_system.g_joint.traffic.finish_check();
            g_system.g_network.network.finish_check();
            check(g_system.g_joint.peak_queued>=127,"all 127 business VLs queued concurrently");
            check(&g_system.g_joint.concurrent_seen[126:0],"each business VL participated in concurrent traffic");
            check(g_system.g_joint.snmp_replies==1 && joint_controls_tested,"SNMP/RTC coverage");
            check(dally_checks>0,"Dally replay exercised over network");
            if(FAULT_MODE==2)check(retries>0,"both-copy DATA loss caused a target retry");
            $display("JOINT SUMMARY fail=%0d completed=%0d failed=%0d files=%0d bytes=%0d retransmissions=%0d dally_checks=%0d snmp_replies=%0d rtc_checks=2 peak_queued_vls=%0d tx_vls=128 rx_vls=4096",fail,completed,failed,delivered_files,delivered_bytes,retries,dally_checks,g_system.g_joint.snmp_replies,g_system.g_joint.peak_queued);
            if(fail)$fatal(1,"JOINT checks failed");
            $display("===== JOINT PASS =====");
        end
    endtask
    end else begin:g_joint_api
        task controls;endtask
        task finish_check;endtask
    end endgenerate
    task joint_controls;g_joint_api.controls();endtask
    task finish_test;g_joint_api.finish_check();$finish;endtask
    task send(input integer length,input integer source_port,input integer destination_port);
        integer timeout;
        @(negedge clk);sl=length;sp=source_port;dp=destination_port;
        for(integer b=0;b<length;b++)begin
            sd=request[b];ss=b==0;se=b==length-1;sv=1;
            timeout=0;@(posedge clk);
            while(!sr && timeout<200000)begin timeout++;@(posedge clk);end
            if(timeout==200000)$fatal(1,"615A request input timeout");
            @(negedge clk);
        end
        sv=0;ss=0;se=0;
    endtask
    task take;
        integer timeout,timeout_limit;
        timeout=0;
        timeout_limit=INTEGRATED?750000:500000;
        while(packets==consumed && timeout<timeout_limit)begin @(negedge clk);timeout++;end
        if(INTEGRATED)$display("615A TAKE time_ns=%0t packets=%0d consumed=%0d waited_cycles=%0d",$time,packets,consumed,timeout);
        if(packets==consumed)begin
            if(INTEGRATED)$display("615A DEBUG target_tx=%0d target_rx=%0d unknown=%0d bad_length=%0d tx_tick=%0d tx127_queued=%0b tx_busy=%0b tx_read_vl=%0d mgmt_enable=%0b mgmt_period=%0d mgmt_phase=%0d dl_tx_valid=%0b dl_tx_ready=%0b tx_route=%0b net_target_a=%0d net_loader_a=%0d",
                g_system.target.tx_frames,g_system.target.rx_frames,g_system.target.unknown_vl,
                g_system.target.bad_length,g_system.target.tx_scheduler_tick,
                g_system.target.u_afdx_tx_core.queued[127],g_system.target.u_afdx_tx_core.busy,
                g_system.target.u_afdx_tx_core.read_vl,g_system.target.sched_enable[127],
                g_system.target.sched_period[127*32+:32],g_system.target.sched_phase[127*32+:32],
                g_system.target.dl_tx_valid,g_system.target.dl_tx_ready,g_system.target.tx_is_615a,
                g_system.g_network.network.sent[0],g_system.g_network.network.sent[2]);
            $fatal(1,"615A response timeout state=%0d busy=%0d status=%h",debug_state,busy,status);
        end
        consumed++;
    endtask
    task ack(input integer block_id,input integer from_port,input integer to_port);
        request[0]=0;request[1]=4;request[2]=block_id>>8;request[3]=block_id;
        send(4,from_port,to_port);
    endtask
    task request_file(input bit writing,input string name,input integer source_port);
        integer p;
        request[0]=0;request[1]=writing?2:1;p=2;
        for(integer b=0;b<name.len();b++)begin request[p]=name.getc(b);p++;end
        request[p]=0;request[p+1]="o";request[p+2]="c";request[p+3]="t";request[p+4]="e";request[p+5]="t";request[p+6]=0;
        send(p+7,source_port,69);
    endtask
    task receive_push;
        string name;
        integer p,client,loader,block_id,last_block,total,n,id,reader;
        bit done,aborted;
        check(output_packet[0]==0 && output_packet[1]==2,"expected target WRQ");
        name="";p=2;
        while(p<output_length && output_packet[p]!=0)begin name={name,output_packet[p]};p++;end
        check(output_destination==69,"target starts TFTP at loader port 69");
        client=output_source;source_counter++;loader=source_counter;total=0;last_block=0;done=0;aborted=0;
        if(name=="TARGET.LNL" && !parallel_query_tested)begin
            // Hold the list's ACK0 while independently polling status. Also
            // lose the snapshot ACK to exercise both independent retry timers.
            request_file(0,"TARGET.LNS",50003);take();reader=output_source;
            check(output_packet[1]==3 && output_packet[8]=="A" && output_packet[9]=="3","status read while LNL push is pending");
            saved_snapshot_length=output_length;
            for(integer b=0;b<output_length;b++)saved_snapshot[b]=output_packet[b];
            request_file(0,"TARGET.LNS",50003);take();
            check(output_source==reader && output_packet[1]==3,"repeated status RRQ keeps snapshot TID");
            check(output_length==saved_snapshot_length,"repeated snapshot length stays fixed");
            for(integer b=0;b<saved_snapshot_length;b++)
                check(output_packet[b]===saved_snapshot[b],$sformatf("repeated snapshot byte %0d",b));
            take();
            while(output_source==client && output_packet[1]==2)take();
            check(output_source==reader && output_packet[1]==3,"snapshot retransmits after lost ACK");
            check(output_length==saved_snapshot_length,"retried snapshot length stays fixed");
            for(integer b=0;b<saved_snapshot_length;b++)
                check(output_packet[b]===saved_snapshot[b],$sformatf("retried snapshot byte %0d",b));
            ack(1,50003,reader);parallel_query_tested=1;
        end
        if(exhaust_next_file && name=="c.bin")begin
            exhaust_next_file=0;aborted=1;done=1;
            for(integer attempt=0;attempt<(INTEGRATED?5:2);attempt++)begin
                take();check(output_source==client && output_packet[1]==2,"WRQ retries before exhaustion");
            end
        end else if(abort_next_file && name=="c.bin")begin
            abort_next_file=0;aborted=1;done=1;
            request[0]=0;request[1]=5;request[2]=0;request[3]=0;
            request[4]="A";request[5]="B";request[6]="O";request[7]="R";request[8]="T";request[9]=":";
            request[10]="1";request[11]="0";request[12]="0";request[13]="5";request[14]=0;
            send(15,loader,client);
        end else ack(0,loader,client);
        while(!done)begin
            take();
            check(output_source==client && output_destination==loader,"TFTP transfer IDs");
            check(output_packet[0]==0 && output_packet[1]==3,"expected target DATA");
            block_id={output_packet[2],output_packet[3]};n=output_length-4;
            if(block_id!=last_block)begin
                check(block_id==(last_block==65535?1:last_block+1),"TFTP block order");
                for(integer b=0;b<n;b++)assembled[total+b]=output_packet[4+b];
                total+=n;last_block=block_id;
            end
            if(name=="c.bin" && block_id==drop_block && !dropped)begin
                dropped=1;
            end else begin ack(block_id,loader,client);if(n<512)done=1;end
        end
        if(!aborted)begin
            if(name=="TARGET.LNS")begin
                status_files++;final_status={assembled[6],assembled[7]};
                check({assembled[0],assembled[1],assembled[2],assembled[3]}==total && assembled[4]=="A" && assembled[5]=="3","LNS binary header");
                n=15+assembled[8];
                if(final_status==3)check({assembled[n],assembled[n+1],assembled[n+2]}==24'h313030,"completed load ratio 100");
                if(final_status>=16'h1000)check(assembled[8]>1,"failure status includes a reason");
                n=19+assembled[8];id=assembled[n];p=n+1;
                check(id<=(LIMITS?8:3),"status selected file count is bounded");
                for(integer f=0;f<id;f++)begin
                    n=assembled[p];p++;name="";
                    check(n>=2 && n<=33 && p+n+4<=total,"status filename bounds");
                    for(integer b=0;b<n-1;b++)begin name={name,assembled[p]};p++;end
                    check(name==file_name(f) && assembled[p]==0,"status selected filename and terminator");
                    p++;
                    check(assembled[p+2]==1 && assembled[p+3]==0,"status file description terminator");p+=4;
                end
                check(p==total,"status entries consume the complete file");
            end else if(name=="TARGET.LNL")begin
                list_files++;check({assembled[6],assembled[7]}==(LIMITS?8:3),"operator list export count");
                p=8;
                for(integer f=0;f<(LIMITS?8:3);f++)begin
                    n=assembled[p];p++;name="";
                    check(n>=2 && n<=33 && p+n+2<=total,"list filename bounds");
                    for(integer b=0;b<n-1;b++)begin name={name,assembled[p]};p++;end
                    check(name==file_name(f) && assembled[p]==0,"list export filename and terminator");
                    check(assembled[p+1]==1 && assembled[p+2]==0,"list file description terminator");p+=3;
                end
                check(p==total,"list entries consume the complete file");
            end else begin
                id=-1;for(integer f=0;f<(LIMITS?8:3);f++)if(name==file_name(f))id=f;
                if(id<0)$fatal(1,"615A unexpected export name %s",name);
                check(total==sizes[id],$sformatf("file %s size",name));
                for(integer b=0;b<total;b++)if(assembled[b]!==((id*53+b)&255))$fatal(1,"615A file data mismatch %s byte=%0d actual=%h",name,b,assembled[b]);
                delivered_files++;delivered_bytes+=total;
            end
        end
    endtask
    task pump;
        integer timeout;
        timeout=0;
        while(timeout<(INTEGRATED?750000:500000))begin
            if(packets!=consumed)begin take();receive_push();timeout=0;end
            else if(debug_state==0 && !debug_master && !debug_dirty && !debug_list &&
                (!debug_committed || !busy || status>=16'h1000))begin
                repeat(5)@(negedge clk);
                // Object assembly now spans several clocks. Recheck the
                // state after the settling interval before declaring idle.
                if(debug_state==0 && packets==consumed && !debug_master && !debug_dirty && !debug_list &&
                    (!debug_committed || !busy || status>=16'h1000))return;
            end
            @(negedge clk);timeout++;
        end
        $fatal(1,"615A pump did not settle");
    endtask
    task initialize(input bit operator_defined);
        request_file(0,operator_defined?"TARGET.LNO":"TARGET.LND",50000);
        take();init_tid=output_source;
        check(output_packet[1]==3 && output_packet[3]==1 && output_length==14,"initialization DATA1");
        request_file(0,operator_defined?"TARGET.LNO":"TARGET.LND",50000);
        take();check(output_source==init_tid && output_packet[1]==3,"lost initialization DATA retry keeps TID");
        if(!init_ack_loss_tested)begin
            take();check(output_source==init_tid && output_packet[1]==3,"lost initialization ACK triggers target DATA retry");
            init_ack_loss_tested=1;
        end
        ack(1,50000,init_tid);wait(debug_initialized);joint_controls();pump();
        check(busy && status==1,"initialized operation awaits selection");
        if(!status_query_tested)begin
            request_file(0,"TARGET.LNS",50002);take();
            check(output_packet[1]==3 && output_source!=69 && output_packet[8]=="A" && output_packet[9]=="3","status RRQ uses an independent TID");
            ack(1,50002,output_source);pump();status_query_tested=1;
        end
    endtask
    task selection(input bit operator_defined,input integer count,input bit malformed);
        integer p,n;
        reg [7:0] payload[0:1023];string name;
        request_file(1,operator_defined?"TARGET.LNA":"TARGET.LNR",50001);
        take();control_tid=output_source;
        check(output_packet[1]==4 && output_packet[3]==0,"selection WRQ ACK0");
        p=8;payload[4]="A";payload[5]="3";payload[6]=0;payload[7]=count;
        for(integer f=0;f<count;f++)begin
            if(malformed)name="missing.bin";
            else name=file_name(f);
            payload[p]=name.len()+1;p++;
            for(integer b=0;b<name.len();b++)begin payload[p]=name.getc(b);p++;end
            payload[p]=0;p++;
        end
        if(!operator_defined)begin
            // 8 maximum-length names plus 231 user bytes makes exactly
            // 512 bytes: TFTP must finish with a separate zero-length DATA2.
            n=LIMITS?((DALLY_TEST==1)?231:255):0;
            payload[p]=n;p++;
            for(integer b=0;b<n;b++)begin payload[p]=b;p++;end
        end
        payload[0]=p>>24;payload[1]=p>>16;payload[2]=p>>8;payload[3]=p;
        for(integer offset=0;offset<p || (offset==p && p%512==0);offset+=512)begin
            n=p-offset;if(n>512)n=512;
            request[0]=0;request[1]=3;request[2]=0;request[3]=offset/512+1;
            for(integer b=0;b<n;b++)request[b+4]=payload[offset+b];
            send(n+4,50001,control_tid);take();
            check(output_packet[1]==(malformed?5:4),"selection accepted or rejected");
            if((DALLY_TEST || JOINT) && n<512 && !malformed)begin
                saved_length=n+4;saved_tid=control_tid;saved_block=offset/512+1;
                for(integer b=0;b<saved_length;b++)saved_final[b]=request[b];
                // Retain a copy so the loader can retry its final DATA even
                // after the target has completed the requested file pushes.
            end
        end
        pump();
        if(JOINT && !DALLY_TEST && !malformed && final_status==3)begin
            replay_final();send(saved_length,50001,saved_tid);check_final_ack();
            check(!busy,"duplicate final DATA cannot restart a completed operation");
        end
    endtask
    task replay_final;
        for(integer b=0;b<saved_length;b++)request[b]=saved_final[b];
    endtask
    task expect_quiet;
        integer before_packets;
        before_packets=packets;
        repeat(INTEGRATED?1250000:100)@(negedge clk);
        check(packets==before_packets,"unrelated or malformed packet cannot trigger a final ACK");
        dally_checks++;
    endtask
    task check_final_ack;
        take();
        check(output_length==4 && output_source==saved_tid && output_destination==50001 &&
            output_packet[1]==4 && {output_packet[2],output_packet[3]}==saved_block,
            "retained final ACK preserves original transfer IDs and block");
        dally_checks++;
    endtask
    initial begin
        string name;
        sizes[0]=0;sizes[1]=512;sizes[2]=1700;
        if(LIMITS)for(integer f=0;f<8;f++)sizes[f]=0;
        if((JOINT && (!INTEGRATED || !NETWORK)) || FAULT_MODE<0 || FAULT_MODE>2)$fatal(1,"invalid joint topology parameters");
        repeat(5)@(negedge clk);reset=0;configure_joint();
        for(integer f=0;f<(LIMITS?8:3);f++)begin
            write_config(8'hb0,f);write_config(8'hb2,sizes[f]);
            name=file_name(f);
            for(integer b=0;b<name.len();b++)write_config(8'hb4,name.getc(b));
            if(name.len()<32)write_config(8'hb4,0);
            for(integer b=0;b<sizes[f];b++)write_config(8'hb5,(f*53+b)&255);
            write_config(8'hb6,1);
        end
        if(DALLY_TEST)begin
            initialize(0);selection(0,LIMITS?8:3,0);
            check(completed==1 && failed==0 && delivered_files==(LIMITS?8:3),"first dally operation completes once");
            replay_final();send(saved_length,50001,saved_tid);check_final_ack();
            replay_final();request[4]=request[4]^1;
            send(saved_length==4?5:saved_length,50001,saved_tid);expect_quiet();
            replay_final();request[3]=saved_block+1;send(saved_length,50001,saved_tid);expect_quiet();
            if(saved_block>1)begin
                replay_final();request[3]=saved_block-1;send(saved_length,50001,saved_tid);expect_quiet();
            end
            replay_final();send(saved_length,50004,saved_tid);expect_quiet();
            sip=32'h0a000003;replay_final();send(saved_length,50001,saved_tid);expect_quiet();sip=32'h0a000002;
            dip=32'h0a000004;replay_final();send(saved_length,50001,saved_tid);expect_quiet();dip=32'h0a000001;
            vl=1;replay_final();send(saved_length,50001,saved_tid);expect_quiet();vl=0;
            replay_final();send(saved_length-1,50001,saved_tid);expect_quiet();
            ack(saved_block,50001,saved_tid);expect_quiet();
            replay_final();request[1]=5;send(saved_length,50001,saved_tid);expect_quiet();
            check(completed==1 && failed==0 && status==3,"dally does not repeat or abort a completed operation");
            initialize(1);
            check(init_tid!=saved_tid,"new initialization does not reuse a retained TID");
            replay_final();send(saved_length,50001,saved_tid);check_final_ack();
            check(busy && status==1 && !debug_committed,"old final DATA does not select files in a new operation");
            // A single cache slot is deliberately exhausted. The old record
            // must survive admission of a new control write request.
            request_file(1,"TARGET.LNA",50001);take();
            check(output_packet[1]==5 && output_packet[4]=="W" && output_source==69,
                "full dally table returns WAIT without evicting the old transfer");
            dally_checks++;
            replay_final();send(saved_length,50001,saved_tid);check_final_ack();
            // Continue servicing periodic LNS while waiting for the old
            // receiver to expire; dally must not block independent traffic.
            for(integer step=0;step<(INTEGRATED?2500100:100100);step++)begin
                if(packets!=consumed)begin take();receive_push();end
                @(negedge clk);
            end
            // No ACK is generated after expiry; a later WRQ may use the slot.
            // Integrated old-port traffic is intentionally not sent here:
            // expired ports return to the ordinary business host demux.
            if(!INTEGRATED)begin
                dp=saved_tid;#1;check(!owns,"expired dally transfer releases UDP port");
                replay_final();send(saved_length,50001,saved_tid);expect_quiet();
            end
            selection(1,LIMITS?8:3,0);
            check(completed==2 && failed==0 && delivered_files==(LIMITS?16:6) && !busy,"new transfer succeeds after dally expiry");
            check(ce==0,"dally does not disturb local file configuration");
            $display("615A DALLY SUMMARY fail=%0d integrated=%0d checks=%0d completed=%0d failed=%0d files=%0d",fail,INTEGRATED,dally_checks,completed,failed,delivered_files);
            if(fail)$fatal(1,"615A dally tests failed");
            if(!JOINT)$display("===== 615A DALLY PASS =====");finish_test();
        end
        if(TIMEOUTS)begin
            initialize(0);
            for(integer step=0;step<5000 && busy;step++)begin pump();repeat(10)@(negedge clk);end
            check(!busy && final_status==16'h1003 && failed==1,"selection deadline terminates abandoned operation");
            initialize(0);selection(0,3,0);
            check(!busy && final_status==3 && completed==1,"recovery after selection deadline");
            $display("615A TIMEOUT SUMMARY fail=%0d completed=%0d failed=%0d",fail,completed,failed);
            if(fail)$fatal(1,"615A timeout tests failed");
            if(!JOINT)$display("===== 615A TIMEOUT PASS =====");finish_test();
        end
        if(LIMITS)begin
            initialize(0);selection(0,8,0);
            check(!busy && final_status==3 && completed==1 && delivered_files==8,"8 files, maximum name length and two-block selection");
            initialize(1);selection(1,8,0);
            check(!busy && final_status==3 && completed==2 && delivered_files==16,"maximum operator list and status");
            $display("615A LIMITS SUMMARY fail=%0d integrated=%0d completed=%0d files=%0d",fail,INTEGRATED,completed,delivered_files);
            if(fail)$fatal(1,"615A limits failed");
            if(!JOINT)$display("===== 615A LIMITS PASS =====");finish_test();
        end
        initialize(0);drop_block=2;selection(0,3,0);
        check(!busy && final_status==3 && completed==1 && delivered_files==3 && retries>=1,"media download and lost ACK recovery");
        initialize(1);drop_block=0;selection(1,3,0);
        check(!busy && final_status==3 && completed==2 && list_files==1 && delivered_files==6,"operator defined download");
        initialize(0);selection(0,1,1);
        check(!busy && final_status==16'h1000 && failed==1,"unknown file denies complete operation");
        initialize(0);abort_next_file=1;selection(0,3,0);
        check(!busy && final_status==16'h1005 && failed==2,"operator abort releases target");
        initialize(0);selection(0,3,0);
        check(!busy && final_status==3 && completed==3,"new operation after failure");
        initialize(0);write_config(8'hb5,8'hff);check(ce==1,"file RAM is immutable during operation");
        exhaust_next_file=1;selection(0,3,0);
        check(!busy && final_status==16'h1004 && failed==3,"retry exhaustion reports failure and releases target");
        initialize(0);selection(0,3,0);
        check(!busy && final_status==3 && completed==4,"new operation after retry exhaustion");
        $display("615A HARDWARE SUMMARY fail=%0d integrated=%0d completed=%0d failed=%0d files=%0d bytes=%0d retransmissions=%0d status_files=%0d list_files=%0d",fail,INTEGRATED,completed,failed,delivered_files,delivered_bytes,retries,status_files,list_files);
        if(fail)$fatal(1,"615A hardware tests failed");
        if(!JOINT)$display("===== 615A HARDWARE PASS =====");finish_test();
    end
    initial begin #(JOINT?1500000000:500000000);$fatal(1,"615A watchdog");end
endmodule
