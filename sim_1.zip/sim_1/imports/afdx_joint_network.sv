`timescale 1ns/1ps
// Simulation only. Independent source-wire checks plus passive SFD matching.
module afdx_joint_wire_check #(parameter VL_COUNT=4096,BYTE_NS=8)(
    input wire clk,reset,input wire [7:0] data,input wire valid,
    output integer frames=0,output integer wraps=0
);
    byte unsigned packet[0:1525];
    integer count=0,gap=0,vl,sn,sum,frame_bytes;
    integer previous_sn[0:VL_COUNT-1];
    reg [3:0] length_coverage[0:126];
    time started,last_start[0:VL_COUNT-1];
    reg [31:0] crc;reg feedback;
    always @(posedge clk)begin
        if(reset)begin
            count=0;gap=0;frames=0;wraps=0;started=0;
            for(integer v=0;v<VL_COUNT;v++)begin previous_sn[v]=0;last_start[v]=0;end
            for(integer v=0;v<127;v++)length_coverage[v]=0;
        end else if(valid)begin
            if(count==0)begin
                if(frames && gap<12)$fatal(1,"JOINT wire IFG below 12 bytes");
                started=$time;gap=0;
            end
            if(count>=1526)$fatal(1,"JOINT wire frame exceeds 1518 bytes");
            packet[count]=data;count++;
        end else begin
            gap++;
            if(count)begin
                frame_bytes=count-8;
                if(frame_bytes<64 || frame_bytes>1518 || $time-started!=count*BYTE_NS)
                    $fatal(1,"JOINT wire frame length or GMII serialization");
                for(integer b=0;b<7;b++)if(packet[b]!==8'h55)$fatal(1,"JOINT preamble");
                if(packet[7]!==8'hd5 || {packet[20],packet[21]}!==16'h0800 || packet[22]!==8'h45 || packet[31]!==17)
                    $fatal(1,"JOINT SFD/Ethernet/IPv4/UDP header");
                if({packet[24],packet[25]}!={packet[46],packet[47]}+20 || {packet[46],packet[47]}<9)
                    $fatal(1,"JOINT IP/UDP length");
                if(frame_bytes!=(({packet[46],packet[47]}-8)<17?64:({packet[46],packet[47]}-8)+47))
                    $fatal(1,"JOINT wire length does not match UDP payload");
                sum=0;for(integer b=22;b<42;b+=2)sum+={packet[b],packet[b+1]};
                sum=(sum&65535)+(sum>>16);sum=(sum&65535)+(sum>>16);
                if(sum!=65535)$fatal(1,"JOINT IPv4 checksum");
                crc=32'hffffffff;
                for(integer b=8;b<count-4;b++)for(integer k=0;k<8;k++)begin
                    feedback=crc[0]^packet[b][k];crc=crc>>1;if(feedback)crc^=32'hedb88320;
                end
                crc=~crc;
                for(integer b=0;b<4;b++)if(packet[count-4+b]!==((crc>>(b*8))&255))$fatal(1,"JOINT FCS");
                vl={packet[12],packet[13]};sn=packet[count-5];
                if(vl>=VL_COUNT || sn==0)$fatal(1,"JOINT wire VL/SN range");
                if(vl<127 && {packet[42],packet[43]}==60000)begin
                    case(frame_bytes)
                        64:length_coverage[vl][0]=1;128:length_coverage[vl][1]=1;
                        512:length_coverage[vl][2]=1;1518:length_coverage[vl][3]=1;
                        default:$fatal(1,"JOINT unexpected business frame length");
                    endcase
                end
                for(integer b=50+{packet[46],packet[47]}-8;b<count-5;b++)
                    if(packet[b]!=0)$fatal(1,"JOINT nonzero Ethernet padding");
                if(previous_sn[vl] && sn!=(previous_sn[vl]==255?1:previous_sn[vl]+1))$fatal(1,"JOINT SN progression VL=%0d",vl);
                if(!previous_sn[vl] && sn!=1)$fatal(1,"JOINT first SN must be 1");
                if(previous_sn[vl]==255)wraps++;
                if(previous_sn[vl] && started-last_start[vl]<1000000)$fatal(1,"JOINT BAG below 1ms VL=%0d",vl);
                previous_sn[vl]=sn;last_start[vl]=started;frames++;count=0;
            end
        end
    end
endmodule

module afdx_joint_network #(
    parameter FAULT_MODE=0,
    parameter A_BASE_NS=10000,A_SPREAD_NS=20000,
    parameter B_BASE_NS=20000,B_SPREAD_NS=10000,
    parameter BYTE_NS=8
)(
    input wire clk,reset,
    input wire [7:0] target_a,target_b,loader_a,loader_b,
    input wire target_av,target_bv,loader_av,loader_bv,
    output wire [7:0] to_loader_a,to_loader_b,to_target_a,to_target_b,
    output wire to_loader_av,to_loader_bv,to_target_av,to_target_bv
);
    wire [7:0] source_data[0:3],destination_data[0:3];
    wire [3:0] source_valid,destination_valid;
    wire [31:0] matched[0:3],pending[0:3],errors[0:3];
    wire [63:0] latency[0:3],jitter[0:3];
    wire [31:0] sent[0:3],wraps[0:3];
    initial $display("JOINT LINK MODEL A_base_ns=%0d A_spread_ns=%0d B_base_ns=%0d B_spread_ns=%0d",A_BASE_NS,A_SPREAD_NS,B_BASE_NS,B_SPREAD_NS);
    always @(posedge clk)if(!reset && (errors[0] || errors[1] || errors[2] || errors[3]))
        $fatal(1,"JOINT GMII monitor rejected traffic");
    assign source_data[0]=target_a;assign source_data[1]=target_b;
    assign source_data[2]=loader_a;assign source_data[3]=loader_b;
    assign source_valid={loader_bv,loader_av,target_bv,target_av};
    assign to_loader_a=destination_data[0];assign to_loader_b=destination_data[1];
    assign to_target_a=destination_data[2];assign to_target_b=destination_data[3];
    assign {to_target_bv,to_target_av,to_loader_bv,to_loader_av}=destination_valid;
    genvar lane;
    generate for(lane=0;lane<4;lane++)begin:g_lane
        // Mode 1: one redundant request copy lost. Mode 2: both copies of
        // the first target DATA lost, forcing an actual TFTP retransmission.
        localparam DROP=(FAULT_MODE==1 && lane==2)||(FAULT_MODE==2 && lane<2);
        afdx_test_link #(.BASE_NS(lane%2?B_BASE_NS:A_BASE_NS),
            .SPREAD_NS(lane%2?B_SPREAD_NS:A_SPREAD_NS),.COHORT(1),.BYTE_NS(BYTE_NS),.DROP_FRAME(DROP?0:-1)) channel(
            .reset(reset),.source_data(source_data[lane]),.source_valid(source_valid[lane]),
            .destination_data(destination_data[lane]),.destination_valid(destination_valid[lane]),.queue_adjustments());
        afdx_joint_wire_check #(.BYTE_NS(BYTE_NS)) wire_check(.clk(clk),.reset(reset),.data(source_data[lane]),.valid(source_valid[lane]),
            .frames(sent[lane]),.wraps(wraps[lane]));
        gmii_sfd_monitor #(.VL_COUNT(4096),.MAX_PENDING(256),.BYTE_NS(BYTE_NS),.LANE(lane)) monitor(
            .clk(clk),.reset(reset),.source_data(source_data[lane]),.source_valid(source_valid[lane]),
            .destination_data(destination_data[lane]),.destination_valid(destination_valid[lane]),
            .checked_frames(matched[lane]),.pending_frames(pending[lane]),.errors(errors[lane]),
            .worst_latency_ns(latency[lane]),.worst_jitter_ns(jitter[lane]));
    end endgenerate
    task finish_check;
        integer lost,covered;
        repeat(((A_BASE_NS+A_SPREAD_NS>B_BASE_NS+B_SPREAD_NS?A_BASE_NS+A_SPREAD_NS:B_BASE_NS+B_SPREAD_NS)+250000)/BYTE_NS+50)@(negedge clk);
        for(integer l=0;l<4;l++)begin
            lost=((FAULT_MODE==1 && l==2)||(FAULT_MODE==2 && l<2))?1:0;
            if(!sent[l] || errors[l] || pending[l]!=lost || matched[l]+lost!=sent[l])
                $fatal(1,"JOINT network mismatch lane=%0d sent=%0d matched=%0d pending=%0d expected_loss=%0d errors=%0d",l,sent[l],matched[l],pending[l],lost,errors[l]);
            if(latency[l]>2000000 || jitter[l]>50000)$fatal(1,"JOINT GMII latency/jitter limits");
            $display("JOINT GMII SUMMARY lane=%0d sent=%0d matched=%0d expected_loss=%0d pending=%0d errors=%0d max_latency_ns=%0d max_jitter_ns=%0d",l,sent[l],matched[l],lost,pending[l],errors[l],latency[l],jitter[l]);
        end
        // Each of 127 business VLs must cover all four rounds on BOTH paths.
        for(integer v=0;v<127;v++)begin
            if(g_lane[0].monitor.frames_by_vl[v]!=4 || g_lane[1].monitor.frames_by_vl[v]!=4)
                $fatal(1,"JOINT business SFD coverage VL=%0d",v);
            if(g_lane[0].wire_check.length_coverage[v]!=15 || g_lane[1].wire_check.length_coverage[v]!=15)
                $fatal(1,"JOINT missing wire length on VL=%0d",v);
        end
        covered=0;
        for(integer v=0;v<4096;v++)if(g_lane[0].monitor.frames_by_vl[v]>0 && g_lane[1].monitor.frames_by_vl[v]>0)covered++;
        if(covered!=4096)$fatal(1,"JOINT full RX VL coverage %0d",covered);
        $display("JOINT NETWORK SUMMARY fault_mode=%0d rx_vls=%0d",FAULT_MODE,covered);
    endtask
endmodule

// Independent physical generator exercises RX VL128..4095 after the live
// application phase. It does not pretend that a 128-TX-VL target emits 4096 VLs.
module afdx_joint_probe(input wire clk,output reg active=0,output reg [7:0] data=0,output reg valid=0);
    byte unsigned packet[0:71];
    task run;
        integer sum;reg [15:0] check;reg [31:0] crc;reg feedback;
        @(negedge clk);active=1;
        for(integer v=128;v<4096;v++)begin
            for(integer b=0;b<72;b++)packet[b]=0;
            for(integer b=0;b<7;b++)packet[b]=8'h55;
            packet[7]=8'hd5;packet[8]=3;packet[12]=v>>8;packet[13]=v;
            packet[14]=2;packet[19]=8'h20;packet[20]=8'h08;packet[22]=8'h45;
            packet[25]=29;packet[28]=8'h40;packet[30]=8'h40;packet[31]=17;
            packet[34]=10;packet[37]=1;packet[38]=10;packet[41]=2;
            packet[42]=8'hea;packet[43]=8'h60;packet[44]=8'hea;packet[45]=8'h61;packet[47]=9;
            packet[50]=(v^8'ha5)&255;packet[67]=1;
            sum=0;for(integer b=22;b<42;b+=2)sum+={packet[b],packet[b+1]};
            sum=(sum&65535)+(sum>>16);sum=(sum&65535)+(sum>>16);check=~sum[15:0];
            packet[32]=check[15:8];packet[33]=check[7:0];crc=32'hffffffff;
            for(integer b=8;b<68;b++)for(integer k=0;k<8;k++)begin
                feedback=crc[0]^packet[b][k];crc=crc>>1;if(feedback)crc^=32'hedb88320;
            end
            crc=~crc;for(integer b=0;b<4;b++)packet[68+b]=crc>>(b*8);
            for(integer b=0;b<72;b++)begin data=packet[b];valid=1;@(negedge clk);end
            valid=0;repeat(12)@(negedge clk);
        end
        active=0;
    endtask
endmodule
