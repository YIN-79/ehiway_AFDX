`timescale 1ns/1ps
module tb_ip_reassembly;
    reg clk=0;always #4 clk=~clk;
    reg reset=1,sv=0,ss=0,se=0,mr=1;
    reg [7:0] sd=0;reg [15:0] vl=0,n=0,id=0,flags=0;
    reg [31:0] now_ms=0;
    wire sr,mv,ms,me;wire [7:0] md;wire [15:0] ml,mvl,msp,mdp;
    wire [31:0] completed,rejected,timeouts;
    afdx_ip_reassembly #(.MAX_MESSAGE(128),.CONTEXTS(2),.TIMEOUT_TICKS(10)) dut(
        .clk(clk),.reset(reset),.now_ms(now_ms),.s_data(sd),.s_valid(sv),.s_ready(sr),
        .s_sop(ss),.s_eop(se),.s_fragment(1'b1),.s_vlid(vl),.s_length(n),.s_sport(id),.s_dport(flags),
        .s_sip(32'h0a000001),.s_dip(32'h0a000002),
        .m_data(md),.m_valid(mv),.m_ready(mr),.m_sop(ms),.m_eop(me),.m_vlid(mvl),.m_length(ml),
        .m_sport(msp),.m_dport(mdp),.m_sip(),.m_dip(),.stat_completed(completed),.stat_rejected(rejected),.stat_timeout(timeouts));
    integer exp_tag[0:31],exp_len[0:31],exp_vl[0:31],queued=0,got=0,pos=0,cycle=0;
    function [7:0] value(input integer tag,input integer j);return (tag*19+j*7)&255;endfunction
    function [15:0] checksum(input integer tag,input integer length);
        integer sum;sum=16'h0a00+1+16'h0a00+2+17+length+8+3000+3002+length+8;
        for(integer j=0;j<length;j+=2)sum+=value(tag,j)*256+(j+1<length?value(tag,j+1):0);
        sum=(sum&65535)+(sum>>16);sum=(sum&65535)+(sum>>16);return ~sum[15:0];
    endfunction
    function [7:0] byte_at(input integer tag,input integer length,input integer index,input bit bad_checksum);
        reg [15:0] c;c=checksum(tag,length)^(bad_checksum?16'h0001:16'h0000);
        case(index)
            0:return 11;1:return 184;2:return 11;3:return 186;
            4:return (length+8)>>8;5:return (length+8)&255;
            6:return c[15:8];7:return c[7:0];default:return value(tag,index-8);
        endcase
    endfunction
    task expect_message(input integer tag,input integer length,input integer v);
        exp_tag[queued]=tag;exp_len[queued]=length;exp_vl[queued]=v;queued++;
    endtask
    task fragment(input integer tag,input integer length,input integer v,input integer ident,
                  input integer offset,input integer count,input bit more,input bit corrupt=0);
        for(integer j=0;j<count;j++)begin
            @(negedge clk);sv=1;ss=j==0;se=j+1==count;sd=byte_at(tag,length,offset+j,corrupt);
            vl=v;id=ident;n=count;flags=(more?16'h2000:0)|(offset>>3);
            @(posedge clk);while(sr!==1)@(posedge clk);
        end
        @(negedge clk);sv=0;ss=0;se=0;
        repeat(3)@(negedge clk);
    endtask
    task drain;
        wait(got==queued);repeat(8)@(negedge clk);
    endtask
    task settle;
        repeat(500)@(negedge clk);
        if(got!=queued)$fatal(1,"missing output got=%0d expected=%0d",got,queued);
    endtask
    always @(posedge clk)if(!reset)begin
        cycle++;
        if(mv&&mr)begin
            if(got>=queued)$fatal(1,"partial/corrupt message leaked");
            if(md!==value(exp_tag[got],pos) || ml!==16'(exp_len[got]) || mvl!==16'(exp_vl[got]) || msp!==16'd3000 || mdp!==16'd3002 ||
               ms!==(pos==0) || me!==(pos+1==exp_len[got]))$fatal(1,"reassembly unit mismatch msg=%0d pos=%0d",got,pos);
            if(me)begin got++;pos=0;end else pos++;
        end
    end
    always @(negedge clk)if(!reset)mr=cycle%7<4;
    initial begin
        repeat(5)@(negedge clk);reset=0;
        // Final fragment arrives first, with a nonzero UDP checksum.
        expect_message(1,41,0);
        fragment(1,41,0,10,32,17,0);fragment(1,41,0,10,0,16,1);fragment(1,41,0,10,16,16,1);drain();
        // Same identification on two different VLs must remain isolated.
        expect_message(3,40,1);expect_message(2,40,0);
        fragment(2,40,0,11,0,16,1);fragment(3,40,1,11,0,16,1);
        fragment(3,40,1,11,16,32,0);fragment(2,40,0,11,16,32,0);drain();
        // Overlap invalidates the entire message; no partial output.
        fragment(4,40,0,12,0,16,1);fragment(4,40,0,12,8,16,1);settle();
        // A bad nonzero UDP checksum must not produce output.
        fragment(5,40,0,13,0,16,1,1);fragment(5,40,0,13,16,32,0,1);settle();
        // Missing middle fragment expires; late terminal fragment cannot finish.
        fragment(6,40,0,14,0,16,1);fragment(6,40,0,14,32,16,0);settle();
        now_ms=20;repeat(4)@(negedge clk);fragment(6,40,0,14,16,16,1);settle();
        now_ms=40;repeat(4)@(negedge clk);
        // Context exhaustion rejects a third key without corrupting the first two.
        fragment(7,40,0,15,0,16,1);fragment(8,40,1,16,0,16,1);fragment(9,40,2,17,0,16,1);settle();
        expect_message(7,40,0);fragment(7,40,0,15,16,32,0);drain();
        expect_message(8,40,1);fragment(8,40,1,16,16,32,0);drain();
        // Invalid non-final alignment, out-of-range end, then valid recovery.
        fragment(10,40,0,18,0,15,1);fragment(10,40,0,19,128,16,0);settle();
        // Reject an early EOP immediately, rather than swallowing the next SOP.
        @(negedge clk);sv=1;ss=1;se=1;n=16;vl=0;id=21;flags=16'h2000;sd=0;
        @(posedge clk);while(sr!==1)@(posedge clk);
        @(negedge clk);sv=0;ss=0;se=0;repeat(4)@(negedge clk);
        expect_message(11,40,0);fragment(11,40,0,20,0,16,1);fragment(11,40,0,20,16,32,0);drain();
        if(completed!=6 || rejected<6 || timeouts<1)$fatal(1,"unit counters completed=%0d rejected=%0d timeouts=%0d",completed,rejected,timeouts);
        $display("IP REASSEMBLY PASS messages=%0d rejected=%0d timeouts=%0d reorder=1 checksum=1 overlap=1 context_isolation=1 recovery=1",got,rejected,timeouts);$finish;
    end
    initial begin #1000000;$fatal(1,"unit watchdog got=%0d queued=%0d",got,queued);end
endmodule
